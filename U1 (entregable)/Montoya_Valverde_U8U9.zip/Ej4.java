import java.util.Scanner;

public class Ej4 {
    public static void main (String args []) {
        Scanner sc = new Scanner(System.in);

        int n;
        System.out.println("Introduzca un número entero positivo y que sea par:");
            n = sc.nextInt();




    }
}
