import java.util.Scanner;

public class Ej1 {
    public static void main (String args []) {
        Scanner sc = new Scanner(System.in);

        int alt = 0;
        int restAlt = alt % 2;

        System.out.println("Introduzca la altura de las Zs; debe ser impar o mayor a 3:");
        alt = sc.nextInt();
    }
}
