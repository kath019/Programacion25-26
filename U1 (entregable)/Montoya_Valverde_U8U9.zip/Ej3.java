import java.util.Scanner;

public class Ej3 {
    public static void main (String args []) {
        Scanner sc = new Scanner(System.in);


        int precio = 0;

        System.out.println("Venta de entradas CineCampa");

        //Introducción de datos
        System.out.print("Número de entradas: ");
        int nEntradas = sc.nextInt();

        System.out.print("Día de la semana: ");
        String dia = sc.next().toLowerCase();

        //Condicionales para los días miércoles y jueves
        int especial = 0;
        especial = nEntradas % 2;

        if (dia.equals("miércoles")) {

            precio = nEntradas * 5;

        }
        if (dia.equals("jueves")) {

            if (especial == 0) {
                precio = (nEntradas / 2) * 11;
            } else {
                precio = ((nEntradas / 2) * 11) + 8;
            }
        }
        if (dia.equals("lunes")){
            precio = nEntradas * 8;
        }
        if (dia.equals("martes")) {
            precio = nEntradas * 8;
        }
        if (dia.equals("viernes")) {
            precio = nEntradas * 8;
        }
        if (dia.equals("sábado")) {
            precio = nEntradas * 8;
        }
        if (dia.equals("domingo")) {
            precio = nEntradas * 8;
        }

        //Condicional para la tarjeta de descuento
        System.out.println("¿Tiene tarjeta CineCampa (s/n)?: ");
        String tarjeta = sc.next();

        double descuento = 0;

        if (tarjeta.equals("s")) {
            descuento = (double) (precio * 0.1);

        } else {
            descuento = 0;
        }

        //Mostrar resultados
        System.out.println("Aquí tiene sus entradas; gracias por su compra.");
        System.out.println("Número de entradas: " + nEntradas);
        System.out.println("Precio total: " + precio);
        System.out.println("Descuento: " + descuento);

        int pago = (int) (precio - descuento);
        System.out.println("A pagar: " + pago);

    }
}
