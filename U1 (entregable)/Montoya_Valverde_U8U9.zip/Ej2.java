import java.util.Scanner;

public class Ej2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce un número entero positivo:");
        long n = sc.nextLong();
        System.out.println("Introduce una cifra entre 0 y 9 (ambos incluidos): ");
        char m = sc.nextLine().charAt(0);

    }
}
