public class Ej3 {
    public static void main(String[] args) {
        //Posición del rey
        String posRey = "e1";

        //Posición de la reyna
        String posReina = "d8";

        // Llamar a la función
        boolean jaque = jaque(posRey, posReina);
        if (jaque) {
            System.out.println("¡El rey está en jaque!");
        } else {
            System.out.println("El rey no está en jaque.");
        }
    }

    public static boolean jaque(String posRey, String posReina) {
        // Convertir las posiciones a coordenadas

        // Columna del rey (letras a-h)
        int reyX = posRey.charAt(0) - 'a';

        // Fila del rey (1-8)
        int reyY = 8 - Character.getNumericValue(posRey.charAt(1));

        // Columna de la reina
        int reinaX = posReina.charAt(0) - 'a';

        // Fila de la reina
        int reinaY = 8 - Character.getNumericValue(posReina.charAt(1));

        // Comprobar posicion de la reina
        if (reyX == reinaX || reyY == reinaY || Math.abs(reyX - reinaX) == Math.abs(reyY - reinaY)) {
            return true;
        }

        return false;
    }
}
