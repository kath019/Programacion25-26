import java.util.Random;

public class Ej4 {
    public static void main(String[] args) {

        Random random = new Random();

        //Array bidimensional
        int filas = 4;
        int columnas = 6;
        int[][] array = new int[filas][columnas];

        //Rellenar el array con números aleatorios
        llenarArrayAleatorio(array);

        //Mostrar el array
        System.out.println("Array generado:");
        imprimirArray(array);

        //codigo de ejemplo de uso
        // Devuelve 35
        System.out.println("nEsimo(a, 0): " + nEsimo(array, 0));

        // Devuelve 24
        System.out.println("nEsimo(a, 2): " + nEsimo(array, 2));

        // Devuelve 60
        System.out.println("nEsimo(a, 5): " + nEsimo(array, 5));

        // Devuelve 32
        System.out.println("nEsimo(a, 6): " + nEsimo(array, 6));

        // Devuelve 78
        System.out.println("nEsimo(a, 21): " + nEsimo(array, 21));

        // Devuelven -1
        System.out.println("nEsimo(a, 24): " + nEsimo(array, 24));
        System.out.println("nEsimo(a, 100): " + nEsimo(array, 100));
    }

    public static int nEsimo(int[][] n, int posicion) {
        // Número total de elementos en el array
        int totalElementos = n.length * n[0].length;

        // Si la posición está fuera del rango, devuelve -1
        if (posicion < 0 || posicion >= totalElementos) {
            return -1;
        }

        // Convertir 'n-ésima' en índices de fila y columna
        int fila = posicion / n[0].length;
        int columna = posicion % n[0].length;

        return n[fila][columna];
    }

    // Función para llenar con números aleatorios el array
    public static void llenarArrayAleatorio(int[][] array) {
        Random rand = new Random();

        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                array[i][j] = rand.nextInt(91) + 10;
            }
        }
    }

    // Función para imprimir el array bidimensional
    public static void imprimirArray(int[][] array) {
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                System.out.print(array[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
