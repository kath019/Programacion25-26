import java.util.Arrays;
import java.util.Scanner;

public class Ej2 {
    public static void main (String [] args ) {
        Scanner sc = new Scanner(System.in);
        int [] v = {1, 2, 3, 4,5};

        System.out.println("Elementos del vector: "+ Arrays.toString(v));

        System.out.println("Introduzca un valor:");
        int valor =sc.nextInt();

        System.out.println("Introduzca una posición que no supere la longitud del vector:");
        int posicion = sc.nextInt();

        if (posicion > v.length) {
            System.out.println("Error");
            System.out.println("Elementos del vector: "+ Arrays.toString(v));
        }
        System.out.println("Nuevo vector: "+ Arrays.toString(insertarValor(v, valor, posicion)));

    }

    public static int[] insertarValor(int [] v, int valor, int posicion){

        // Se crea un nuevo vector con un contenido más
        int[] v1 = new int[v.length + 1];

        // Bucle para insertar el valor en la posición
        for (int i = 0; i < posicion; i++) {
            v1[i] = v[i];
        }

        // Insertar el nuevo valor
        v1[posicion] = valor;

        // Copiar el resto de los elementos, desplazándolos una posición
        for (int i = posicion; i < v.length; i++) {
            v1[i + 1] = v[i];
        }
        return v1;
    }
}
