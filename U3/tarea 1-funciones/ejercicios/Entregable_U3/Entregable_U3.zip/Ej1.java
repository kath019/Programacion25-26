import java.util.Arrays;
import java.util.Random;

public class Ej1 {
    public static void main (String [] args ) {

        //Definición del Array
        int [] a = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        //Mostrar los elementos del Array
        System.out.println("Elementos del Array: "+ Arrays.toString(a));

        //Traer la función
        System.out.println("Un número aleatorio del array es: "+aleatorioArray(a));
    }

    //Función para sacar un número aleatorio del Array
    public static int aleatorioArray(int[] a) {
        Random random = new Random();
        int b = random.nextInt(a.length);
        return b;
    }
}
