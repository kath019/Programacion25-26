import java.util.Scanner;

public class IntrNyMedia {
    public static void main (String[] args ) {
        Scanner sc = new Scanner(System.in);

        int contNegativos = 0;
        int negativo = 0;
        int contPositivos = 0;
        int positivo = 0;
        int contCero = 0;
        System.out.println("Introduzca un número:");
        int n = sc.nextInt();
        int [] numeros = new int [n];

        System.out.println("Introduzca "+n+" números:");
        for ( int i = 0; i < n; i++) {
            numeros [i] = sc.nextInt();
        }
        for (int recorre : numeros) {
            if (recorre < 0) {
                negativo = negativo + recorre;
                contNegativos++;

            } else if (recorre > 0) {
                contPositivos++;
                positivo = positivo +recorre;
            } else {
                contCero++;

            }
        }
        System.out.print("La media de los números negativos es: "+(negativo/contNegativos));
        System.out.print("La media de los números positivos es: "+(positivo/contNegativos));
        System.out.print("La cantidad de 0 introducidos es:"+contCero);

    }
}
