import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class F2Tablas {
    // Función que devuelve el número de aciertos
    public static int contarAciertos(int[] apuesta, int[] ganadora) {
        int aciertos = 0;

        // Comparamos cada número de la apuesta con los números de la combinación ganadora
        for (int i = 0; i < apuesta.length; i++) {
            for (int j = 0; j < ganadora.length; j++) {
                if (apuesta[i] == ganadora[j]) {
                    aciertos++;  // Si hay coincidencia, incrementamos el contador de aciertos
                    break;  // Salimos del segundo bucle para evitar contar el mismo número varias veces
                }
            }
        }
        return aciertos;  // Devolvemos el número de aciertos
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        int[] apuesta = {1, 2, 3, 4, 5, 6};  // Números de la apuesta
        int[] ganadora = {6, 5, 4, 3, 2, 1};  // Números de la combinación ganadora

        int aciertos = contarAciertos(apuesta, ganadora);  // Llamamos a la función

        System.out.println("Número de aciertos: " + aciertos);  // Mostramos el número de aciertos
    }
}
