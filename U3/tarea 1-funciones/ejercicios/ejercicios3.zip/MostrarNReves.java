import java.util.Scanner;

public class MostrarNReves {
    public  static void main (String[] args ) {
        Scanner sc = new Scanner(System.in);

        System.out.println("¿Cuántos números desea introducir?");
        int n = sc.nextInt();
        int [] cantidad = new int[n];

        for (int i = 0; i < cantidad.length; i++) {
            System.out.println("Número"+(i + 1)+":");
            cantidad [i] = sc.nextInt();
        }

        System.out.println("Los números introducidos, al revés son:");
        for (int i = n -1; i >= 0; i--){
            System.out.println(cantidad[i]+" ");
        }
    }
}
