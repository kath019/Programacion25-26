import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Tablas3Orden {
    public  static void main (String [] args) {
        Scanner sc = new Scanner(System.in);

        int [] numeros1 = new int[6];

        System.out.println("Introduzca 6 números, irán en la primera tabla:");
        for (int i = 0; i < 6; i++) {
            numeros1 [i] = sc.nextInt();
        }
        Arrays.sort(numeros1);
        System.out.println("Primera tabla ordenada:");
        for (int i = 0; i < 6; i++) {
            System.out.println("--|");
         System.out.println(numeros1 [i]+" |");
        }

        int[] numeros2 = new int[6];
        System.out.println("Introduzca otros 6 números, irán en la segunda tabla:");
        for (int i = 0; i < 6; i++) {
            numeros2 [i] = sc.nextInt();
        }
        Arrays.sort(numeros2);
        System.out.println("Segunda tabla ordenada:");
        for (int i = 0; i < 6; i++) {
            System.out.println("--|");
            System.out.println(numeros2 [i]+" |");
        }

        // FUSIONAR SIN REORDENAR
        int [] tabla3 = new int[12];
        int i = 0, j = 0, k = 0;

        while (i < 6 && j < 6) {
            if (numeros1[i] <= numeros2[j]) {
                tabla3[k++] = numeros1[i++];
            } else {
                tabla3[k++] = numeros2[j++];
            }
        }

        // copiar el resto si queda alguno
        while (i < 6) {
            tabla3[k++] = numeros1[i++];
        }
        while (j < 6) {
            tabla3[k++] = numeros2[j++];
        }

        // MOSTRAR TABLA FUSIONADA
        System.out.println("Tabla fusionada ordenada:");
        for (int n : tabla3) {
            System.out.print(n + " ");
        }

    }
}
