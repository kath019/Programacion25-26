import java.util.Scanner;

public class NotaMedia {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca las 5 notas del primer trimestre:");
        int[] trimestre1 = new int[5];
        for ( int i = 0 ; i < trimestre1.length ; i ++) {
            System.out.print("Nota "+(i+1)+":");
            trimestre1 [i] = sc.nextInt();
        }


        System.out.println("Introduzca las 5 notas del segundo trimestre:");
        int[] trimestre2 = new int[5];
        for ( int i = 0 ; i < trimestre2.length ; i ++) {
            System.out.print("Nota "+(i+1)+":");
            trimestre2 [i] = sc.nextInt();
        }

        System.out.println("Introduzca las 5 notas del tercer trimestre:");
        int[] trimestre3 = new int[5];
        for ( int i = 0 ; i < trimestre3.length ; i ++) {
            System.out.print("Nota "+(i+1)+":");
            trimestre3 [i] = sc.nextInt();
        }

        double media1 = calcularMedia(trimestre1);
        double media2 = calcularMedia(trimestre2);
        double media3 = calcularMedia(trimestre3);

        // Mostrar medias
        System.out.println("\nNota media del grupo durante el 1º trimestre: " + media1);
        System.out.println("Nota media del grupo durante el 2º trimestre: " + media2);
        System.out.println("Nota media del grupo durante el 3º trimestre: " + media3);

        // MEDIA DE UN ALUMNO (pos)
        System.out.print("\nIntroduzca la posición del alumno (1 a 5): ");
        int pos = sc.nextInt() - 1;

        if (pos < 0 || pos >= 5) {
            System.out.println("Posición no válida.");
        } else {
            double mediaAlumno = (trimestre1[pos] + trimestre2[pos] + trimestre3[pos]) / 3.0;
            System.out.println("La nota media del alumno en la posición " + (pos + 1) + " es: " + mediaAlumno);
        }
        
    }

    // Función para calcular la media de un array
    public static double calcularMedia(int[] notas) {
        int suma = 0;
        for (int nota : notas) {
            suma += nota;
        }
        return suma / 5.0;
    }
}
