import java.util.Random;
import java.util.Scanner;

public class CamaraSecreta {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Random random = new Random();

        System.out.print("Introduzca la cantidad de dígitos que desea que tenga la clave:");
        int n = sc.nextInt();

        System.out.println("Generando clave...");
        String claveSecreta = generarClaveSecreta(n, random);
        System.out.println(claveSecreta);
        
        // Bucle principal del juego
        boolean haGanado = false;
        while (!haGanado) {
            System.out.print("Intenta adivinar la combinación:");
            String combinacionPrueba = sc.next();

            // 4. Validar la longitud de la combinación de prueba
            if (combinacionPrueba.length() != n) {
                System.out.println("La combinación debe tener " + n + " dígitos. Inténtalo de nuevo.");
            }

            // 5. Comparar la combinación de prueba con la secreta y dar pistas
            StringBuilder pistas = new StringBuilder();
            for (int i = 0; i < n; i++) {
                char secreto = claveSecreta.charAt(i);
                char prueba = combinacionPrueba.charAt(i);

                if (prueba < secreto) {
                    pistas.append("mayor ");
                } else if (prueba > secreto) {
                    pistas.append("menor ");
                } else {
                    pistas.append("igual ");
                }
            }
            System.out.println("Pistas: " + pistas.toString());

            // 6. Comprobar si el usuario ha ganado
            if (combinacionPrueba.equals(claveSecreta)) {
                haGanado = true;
                System.out.println("¡¡¡Felicidades!!! ¡Has adivinado la clave secreta!");
            }
        }
    }

    public static String generarClaveSecreta(int n, Random random) {
        StringBuilder clave = new StringBuilder();
        for (int i = 0; i < n; i++) {

            // Genera un número aleatorio entre 1 y 5 (incluidos)
            int digito = random.nextInt(5) + 1;
            clave.append(digito);
        }
        return clave.toString();
    }
}