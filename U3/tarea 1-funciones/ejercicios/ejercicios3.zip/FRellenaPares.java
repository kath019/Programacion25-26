import java.util.Scanner;

public class FRellenaPares {

    // Función que rellena la tabla con los números pares y devuelve la cantidad de impares desechados
    public static int rellenaPares(int[] tabla) {
        Scanner scanner = new Scanner(System.in);
        int imparesDescontados = 0;
        int index = 0;

        // Mientras no se haya llenado la tabla
        while (index < tabla.length) {
            System.out.print("Introduce un número: ");
            int numero = scanner.nextInt();

            // Si el número es par
            if (numero % 2 == 0) {

                // Lo agregamos a la tabla
                tabla[index] = numero;

                // Avanzamos al siguiente espacio de la tabla
                index++;
            } else {

                // Si el número es impar, lo ignoramos
                imparesDescontados++;
            }
        }

        // Devolvemos la cantidad de impares que se han desechado
        return imparesDescontados;
    }


    public static void main (String [] args) {


        // La tabla tendrá 6 elementos
        int[] tabla = new int[6];

        // Llamamos a la función rellenaPares
        int impares = rellenaPares(tabla);

        System.out.println("Los números pares que se han guardado en la tabla son:");
        for (int num : tabla) {
            System.out.print(num + " ");
        }
        System.out.println("\nCantidad de números impares desechados: " + impares);
    }


}
