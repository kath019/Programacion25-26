import java.util.ArrayList;
public class fsinRepetidos {

    // Ejemplo de uso
    public static void main(String[] args) {
        int[] datos = {3, 5, 3, 8, 5, 10, 8};
        int[] sinRep = sinRepetidos(datos);

        for (int n : sinRep) {
            System.out.print(n + " ");
        }
    }


    public static int[] sinRepetidos(int t[]) {
        ArrayList<Integer> lista = new ArrayList<>();

        for (int i = 0; i < t.length; i++) {
            if (!lista.contains(t[i])) {
                lista.add(t[i]);
            }
        }

        // Convertimos la lista a array int[]
        int[] resultado = new int[lista.size()];
        for (int i = 0; i < lista.size(); i++) {
            resultado[i] = lista.get(i);
        }

        return resultado;
    }

}

