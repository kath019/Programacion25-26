public class TablaBidimensional {
    public static void main (String []args) {

        int [][] tabla = new  int [5] [5];

        for (int n = 0; n < 5; n++) {
            for (int m = 0; m < 5; m++) {
                tabla[n][m] = n + m;
            }
        }
        // 3. Mostrar el contenido de la tabla
        System.out.println("Contenido de la tabla 5x5:");
        for (int n = 0; n < 5; n++) {
            for (int m = 0; m < 5; m++) {
                // Añadir formato para alinear los números
                System.out.printf("%4d", tabla[n][m]);
            }
            System.out.println(); // Nueva línea al final de cada fila
        }
    }
}
