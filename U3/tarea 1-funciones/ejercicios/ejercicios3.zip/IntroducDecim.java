import java.util.Scanner;

public class IntroducDecim {
    public static void main (String args []) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca 5 números decimales:");
        double [] numeros = new double[5];

        for (int i = 0; i < 5; i++) {
        System.out.print("Número "+(i + 1)+" :");
        numeros [i] = sc.nextDouble();
        }

        System.out.println("Los números introducidos en orden son:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros [i]);
        }














        /*double [] numeros = new double[5];

        System.out.println("Introduzca 5 números decimales:");
        for (int i = 0; i < numeros.length; i++) {
            System.out.print("Número "+(i + 1)+":");
            numeros [i] = sc.nextDouble();
        }

        System.out.print("Los números introducidos son: ");
        for (int i = 0; i < numeros.length; i++) {
            System.out.println(numeros[i]);
        }*/
    }
}
