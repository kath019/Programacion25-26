import java.util.Scanner;
public class alfil {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduzca la posición del alfil: ");
        String posicion = sc.nextLine().toLowerCase();

        // Extraer columna (letra) y fila (número)
        char col = posicion.charAt(0);
        int fila = Character.getNumericValue(posicion.charAt(1));

        // Convertir columna a número: 'a' = 1, 'b' = 2, ..., 'h' = 8
        int colNum = col - 'a' + 1;

        System.out.print("\nEl alfil puede moverse a las siguientes posiciones:");

        // DIRECCIÓN 1: diagonal arriba-derecha
        for (int c = colNum + 1, f = fila + 1; c <= 8 && f <= 8; c++, f++) {
            System.out.print(convertir(c, f) + " ");
        }

        // DIRECCIÓN 2: diagonal arriba-izquierda
        for (int c = colNum - 1, f = fila + 1; c >= 1 && f <= 8; c--, f++) {
            System.out.print(convertir(c, f) + " ");
        }

        // DIRECCIÓN 3: diagonal abajo-derecha
        for (int c = colNum + 1, f = fila - 1; c <= 8 && f >= 1; c++, f--) {
            System.out.print(convertir(c, f) + " ");
        }

        // DIRECCIÓN 4: diagonal abajo-izquierda
        for (int c = colNum - 1, f = fila - 1; c >= 1 && f >= 1; c--, f--) {
            System.out.print(convertir(c, f) + " ");
        }
    }

    // Convierte coordenadas numéricas en notación como "d5"
    public static String convertir(int col, int fila) {
        char letra = (char) ('a' + col - 1);
        return "" + letra + fila;
    }
}
