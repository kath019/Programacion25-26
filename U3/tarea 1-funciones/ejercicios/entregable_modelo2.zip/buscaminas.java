import java.util.Scanner;
public class buscaminas {


    public class Buscaminas {

        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            System.out.print("Introduce la dimensión del tablero: ");
            int N = sc.nextInt();

            char[][] tablero = new char[N][N];

            // Rellenamos el tablero
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    tablero[i][j] = Math.random() < 0.3 ? 'X' : '-';
                }
            }

            boolean vivo = true;

            while (vivo) {
                mostrarTablero(tablero);

                System.out.print("Introduzca una posición (fila columna): ");
                int fila = sc.nextInt();
                int col = sc.nextInt();

                // Comprobamos límites
                if (fila < 0 || fila >= N || col < 0 || col >= N) {
                    System.out.println("Posición fuera del tablero.");
                    continue;
                }

                // Si es bomba → fin
                if (tablero[fila][col] == 'X') {
                    System.out.println("La posición " + fila + "," + col + " tiene una bomba, ¡estás muerto!");
                    vivo = false;
                } else {
                    int bombas = contarBombasAlrededor(tablero, fila, col);
                    System.out.println("La posición " + fila + "," + col + " tiene " + bombas + " bombas alrededor");
                }
            }
        }

        // Mostrar tablero con marco bonito
        public static void mostrarTablero(char[][] t) {
            int N = t.length;

            System.out.println();
            System.out.print("┌");
            for (int i = 0; i < N; i++) System.out.print("─────" + (i == N - 1 ? "┐" : "┬"));
            System.out.println();

            for (int i = 0; i < N; i++) {
                System.out.print("│");
                for (int j = 0; j < N; j++) {
                    System.out.print("  " + t[i][j] + "  │");
                }
                System.out.println();

                if (i < N - 1) {
                    System.out.print("├");
                    for (int j = 0; j < N; j++) {
                        System.out.print("─────" + (j == N - 1 ? "┤" : "┼"));
                    }
                    System.out.println();
                }
            }

            System.out.print("└");
            for (int i = 0; i < N; i++) System.out.print("─────" + (i == N - 1 ? "┘" : "┴"));
            System.out.println("\n");
        }

        // Contar bombas alrededor
        public static int contarBombasAlrededor(char[][] t, int fila, int col) {
            int N = t.length;
            int bombas = 0;

            for (int i = fila - 1; i <= fila + 1; i++) {
                for (int j = col - 1; j <= col + 1; j++) {
                    if (i >= 0 && i < N && j >= 0 && j < N) {
                        if (t[i][j] == 'X') {
                            bombas++;
                        }
                    }
                }
            }

            return bombas;
        }
    }

}
