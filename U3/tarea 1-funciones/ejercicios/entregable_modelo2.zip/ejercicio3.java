import java.util.Scanner;
public class ejercicio3 {


    public class Matriz90Grados {
        public static void main(String[] args) {

            Scanner sc = new Scanner(System.in);

            System.out.print("Introduce la dimensión del Array: ");
            int N = sc.nextInt();

            int[][] matriz = new int[N][N];

            // Rellenar con aleatorios entre 100 y 200
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    matriz[i][j] = (int)(Math.random() * 101) + 100;
                }
            }

            // Mostrar matriz original
            System.out.println("\nMatriz original:");
            mostrarMatriz(matriz);

            // Rotar 90 grados
            int[][] rotada = rotar90(matriz);

            // Mostrar matriz rotada
            System.out.println("\nMatriz rotada 90 grados:");
            mostrarMatriz(rotada);
        }

        // Función para mostrar matriz
        public static void mostrarMatriz(int[][] m) {
            for (int[] fila : m) {
                for (int valor : fila) {
                    System.out.print(valor + " ");
                }
                System.out.println();
            }
        }

        // Función que rota 90 grados a la derecha
        public static int[][] rotar90(int[][] m) {
            int N = m.length;
            int[][] resultado = new int[N][N];

            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    resultado[j][N - 1 - i] = m[i][j];
                }
            }

            return resultado;
        }
    }

}
