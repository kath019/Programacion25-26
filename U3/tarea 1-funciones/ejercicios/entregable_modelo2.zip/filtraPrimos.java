public class filtraPrimos {
    public static int[] filtraPrimos(int[] numeros) {
        // Primero contamos cuántos números primos hay
        int contador = 0;

        for (int n : numeros) {
            if (esPrimo(n)) {
                contador++;
            }
        }

        // Si no hay primos, devolvemos [-1]
        if (contador == 0) {
            return new int[]{-1};
        }

        // Creamos el array resultado con el tamaño exacto
        int[] resultado = new int[contador];
        int indice = 0;

        // Rellenamos el array con los primos
        for (int n : numeros) {
            if (esPrimo(n)) {
                resultado[indice] = n;
                indice++;
            }
        }

        return resultado;
    }
    public static boolean esPrimo(int n) {
        if (n <= 1) return false;

        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }

        return true;
    }

}
