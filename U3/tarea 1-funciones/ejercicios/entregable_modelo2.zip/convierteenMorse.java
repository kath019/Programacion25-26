public class convierteenMorse {
    public static String convierteEnMorse(int n) {
        // Tabla de morse para los números 0-9
        String[] morse = {
                "_ _ _ _ _", // 0
                ". _ _ _ _", // 1
                ". . _ _ _", // 2
                ". . . _ _", // 3
                ". . . . _", // 4
                ". . . . .", // 5
                "_ . . . .", // 6
                "_ _ . . .", // 7
                "_ _ _ . .", // 8
                "_ _ _ _ .", // 9
        };
        // Convertimos el número a cadena
        String numero = String.valueOf(n);
        StringBuilder resultado = new StringBuilder();

        // Recorremos cada dígito
        for (int i = 0; i < numero.length(); i++) {
            int digito = numero.charAt(i) - '0';  // Convertimos el char a número real
            resultado.append(morse[digito]);

            // Añadimos espacio entre dígitos
            if (i < numero.length() - 1) {
                resultado.append("   ");  // 3 espacios para separar dígitos
            }
        }

        return resultado.toString();
    }
    public static void main(String[] args) {
        int n = 213;
        String morse = convierteEnMorse(n);

        System.out.println("Número: " + n);
        System.out.println("Morse: " + morse);
    }

}
