import java.util.Scanner;

public class act5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Declaración de variables
        String cadena;
        int n, m, i, j;

        //Asignación de un valor para 'cadena'
        System.out.println("Digite una cadena: ");
        cadena=sc.nextLine();

        //Limitación de dígitos por cadena
        if (cadena.length() > 10) {
            cadena=cadena.substring(0, 10);
        }

        //Número de caracteres
        n=cadena.length();

        //punto central
        m = n - 1;

        //Parte superior
        for (i = 0; i < n;i++) {
            for (j = 0; j < n - i - 1; j++) {
                System.out.print(" ");
            }
            //Izquierda desde el inicio hasta i
            for (j = 0; j <= i - 1; j++) {
                System.out.print(cadena.charAt(j));
            }
            System.out.println();
        }

        //Parte inferior
        for ( i = n-2; i >= 0; i--) {
            //Espacios antes de la palabra
            for (j = 0; j < n - i -1; j++) {
                System.out.print(" ");
            }
            //Derecha desde i-1 hasta 0
            for (j = i - 1; j >= 0; j--) {
                System.out.print(cadena.charAt(j));
            }
            System.out.println();
        }
    }
}
