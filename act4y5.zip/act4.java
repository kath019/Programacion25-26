import java.util.Scanner;

public class act4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Declaración de variables
        int a, i, j, k, mitad;

        System.out.print("Ingresa un número impar mayor o igual a 3: ");
        a=sc.nextInt();

        if (a >= 3 && a % 2 != 0 ) {
            mitad = a / 2;

            //Parte superior
            for (i = 0; i <= mitad; i++) {
                for (j = 0; j < mitad - i; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");

                //Espacio entre flechas
                for (k = 0; k < 5; k++) {
                    System.out.print(" ");
                }
                System.out.println("*");
            }

            //Parte inferior
            for (i = mitad - 1; i >= 0; i--) {
                for (j = 0; j < mitad - i; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
                for (k = 0; k < 5; k++) {
                    System.out.print(" ");
                }
                System.out.println("*");
            }

        } else {
            System.out.println("Error");
        }
    }
}
