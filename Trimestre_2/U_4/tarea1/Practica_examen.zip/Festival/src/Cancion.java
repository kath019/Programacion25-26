public class Cancion {
    private String titulo;
    private double duracion;
    private Genero genero;
    private Cantante cantante;

    public Cancion(String titulo, double duracion, Genero genero, Cantante cantante) {
        this.titulo = titulo;
        this.duracion = duracion;
        this.genero = genero;
        this.cantante = cantante;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getDuracion() {
        return duracion;
    }

    public void setDuracion(double duracion) {
        this.duracion = duracion;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public Cantante getCantante() {
        return cantante;
    }

    public void setCantante(Cantante cantante) {
        this.cantante = cantante;
    }

    @Override
    public String toString() {
        return "Cancion{" +
                "titulo='" + titulo + '\'' +
                ", duracion=" + duracion +
                ", genero=" + genero +
                ", cantante=" + cantante +
                '}';
    }
    public void mostrar_informacion() {
        System.out.println(toString());
    }
}
