public enum Genero {
    TRAP,
    NEOPERREO,
    EMORAP,
}
