import java.util.Arrays;
import java.util.Calendar;

public class Concierto {
    private String nombre;
    private Calendar fecha;
    private static String organizador = "Luis Fuentes";
    private Escenario[] listEscenarios;
    private int contadorEscenarios;

    public Concierto(String nombre) {
        this.nombre = nombre;
        this.listEscenarios = new Escenario[8];
        this.contadorEscenarios = 0;
    }

    public void addEscenario(Escenario escenario) {
        if(this.contadorEscenarios < this.listEscenarios.length) {
            this.listEscenarios[this.contadorEscenarios] = escenario;
            contadorEscenarios++;
        } else {
            System.out.println("Los escenarios están llenos");
        }
    }

    public void programarConcierto(Calendar fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Concierto{" +
                "nombre='" + nombre + '\'' +
                ", fecha=" + fecha +
                ", listEscenarios=" + Arrays.toString(listEscenarios) +
                ", contadorEscenarios=" + contadorEscenarios +
                '}';
    }

    public void mostrar_informacion() {
        System.out.println(toString());
    }
}
