public class Cantante {
    private String nombreReal;
    private String nombreArt;
    private int edad;
    private String origen;
    private Cancion [] listCancion;
    private int contCanciones;

    public Cantante(String nombreReal, String nombreArt, int edad, String origen, int capacCanciones) {
        this.nombreReal = nombreReal;
        this.nombreArt = nombreArt;
        this.edad = edad;
        this.origen = origen;
        this.contCanciones = 0;
        this.listCancion = new Cancion[capacCanciones];
    }

    public void addCancion(Cancion cancion){
        if (contCanciones < listCancion.length) {
            this.listCancion[contCanciones] = cancion;
        } else {
            System.out.println("No hay más espacio en la playlist");
        }

        for(int i = 0; i < contCanciones; i++){
            if(listCancion[i].getTitulo().equalsIgnoreCase(cancion.getTitulo())){
                System.out.println("Ya existe una canción con ese título");
            }
        }
        listCancion[contCanciones] = cancion;
        contCanciones++;
    }

    public void mostrarLista(){
        System.out.println("Lista de canciones:");
        for(Cancion cancion: listCancion){
            System.out.println(cancion);
        }
    }

    public void eliminarCancion(String titulo){
        int indice = -1;
        //Buscar cancion
        for (int i = 0; i < contCanciones; i++) {
            if (listCancion[i].getTitulo().equalsIgnoreCase(titulo)) {
                indice = i;
                break;
            }
        }
        if (indice == -1) {
            System.out.println("No existe esa canción");
            return;
        }
        //Dezplazar posicion a la izquierda
        for (int i = indice; i < contCanciones - 1; i++) {
            listCancion[i] = listCancion[i + 1];
        }
        listCancion[contCanciones - 1] = null;
        contCanciones--;
    }

    // Mostrar datos personales
    public void mostrarDatos() {
        System.out.println("Nombre real: " + nombreReal);
        System.out.println("Nombre artístico: " + nombreArt);
        System.out.println("Edad: " + edad);
        System.out.println("Ciudad de origen: " + origen);
    }
}
