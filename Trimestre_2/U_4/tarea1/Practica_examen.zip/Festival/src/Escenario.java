import java.util.Arrays;

public class Escenario {
    private String nombre;
    private String ubicacion;
    private int capacidad;
    private Cantante[] listCantantes;
    private int contCantantes;

    public Escenario(String nombre,  String ubicacion, int capacidad) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.capacidad = capacidad;
        this.contCantantes = 0;
        this.listCantantes = new Cantante[5];
    }

    public void addCantante(Cantante cantante) {
        if(this.contCantantes < listCantantes.length) {
            this.listCantantes[this.contCantantes] = cantante;
            contCantantes++;
        } else {
            System.out.println("El escenario está lleno");
        }
    }

    public void mostrarCantante() {
        for (Cantante cantante : this.listCantantes) {
            System.out.println(cantante);
        }
    }

    @Override
    public String toString() {
        return "Escenario{" +
                "nombre='" + nombre + '\'' +
                ", ubicacion='" + ubicacion + '\'' +
                ", capacidad=" + capacidad +
                ", listCantantes=" + Arrays.toString(listCantantes) +
                ", contCantantes=" + contCantantes +
                '}';
    }

    public void mostrar_informacion(){
        System.out.println(toString());
    }
}
