import java.util.Calendar;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Calendar;
public class Main {
    public static void main(String[] args) {

        Concierto concierto1 = new Concierto("Concierto Primavera");
        Concierto concierto2 = new Concierto("Concierto de Otoño");
        Concierto concierto3 = new Concierto("Concierto de Verano");

        Escenario escenario1 = new Escenario("Escenario A", "Plaza Mayor", 3);
        Escenario escenario2 = new Escenario("Escenario B", "Plaza Menor", 3);
        Escenario escenario3 = new Escenario("Escenario C", "Plaza Central", 3);
        Escenario escenario4 = new Escenario("Escenario D", "Esquina Sur", 4);
        Escenario escenario5 = new Escenario("Escenario E", "Esquina Este", 5);
        Escenario escenario6 = new Escenario("Escenario F", "Río Azuk", 4);
        Escenario escenario7 = new Escenario("Escenario G", "Río Brillante", 4);
        Escenario escenario8 = new Escenario("Escenario H", "Cuidad Jardín", 5);
        Escenario escenario9 = new Escenario("Escenario I", "Parque Soledo", 3);

        concierto1.addEscenario(escenario1);
        concierto1.addEscenario(escenario2);
        concierto1.addEscenario(escenario3);
        concierto2.addEscenario(escenario4);
        concierto2.addEscenario(escenario5);
        concierto2.addEscenario(escenario6);
        concierto3.addEscenario(escenario7);
        concierto3.addEscenario(escenario8);
        concierto3.addEscenario(escenario9);

        concierto1.programarConcierto(Calendar.getInstance());
        concierto2.programarConcierto(Calendar.getInstance());
        concierto3.programarConcierto(Calendar.getInstance());

        concierto1.mostrar_informacion();
        concierto2.mostrar_informacion();
        concierto3.mostrar_informacion();


        Cantante c1 = new Cantante("Ana López", "Luna", 25, "Madrid", 5);
        Cantante c2 = new Cantante("Carlos Ruiz", "CRock", 30, "Barcelona", 5);
        Cantante c3 = new Cantante("Lucía Pérez", "LuciPop", 22, "Sevilla", 5);
        Cantante c4 = new Cantante("Mario Díaz", "DJ Fire", 28, "Valencia", 5);
        Cantante c5 = new Cantante("Sofía Torres", "JazzSoul", 35, "Bilbao", 5);
        Cantante c6 = new Cantante("Raúl Gómez", "ReggaetonBoy", 27, "Málaga", 5);

        escenario1.addCantante(c1);
        escenario1.mostrarCantante();
        escenario1.mostrar_informacion();


        escenario2.addCantante(c4);
        escenario2.mostrarCantante();
        escenario2.mostrar_informacion();
    }
}
