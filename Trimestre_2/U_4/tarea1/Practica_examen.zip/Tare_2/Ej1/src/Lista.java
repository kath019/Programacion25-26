import java.util.Arrays;

public class Lista {
    private Integer[] tabla;
    private int contElementos;

    public Lista() {
        this.tabla = new Integer[10];
        this.contElementos = 0;
    }

    public Lista(int valor) {
        this.tabla = new Integer[valor];
        this.contElementos = 0;
    }

    public int getContElementos() {
        return contElementos;
    }

    public void modificArray(){
        Integer [] nueva = new Integer [tabla.length * 2];
        for (int i = 0; i < contElementos; i++) {
            nueva [i] = tabla[i];
        }
        this.tabla = nueva;
    }

    public void insertFinal(Integer num){
        if (this.contElementos == tabla.length){
            modificArray();
        }
        tabla[contElementos] = num;
        this.contElementos++;
    }

    public void insertIni(Integer num){
        if (this.contElementos == tabla.length){
            modificArray();
        }
        for (int i = contElementos; i > 0; i++){
            tabla[i] = tabla[contElementos - 1];
        }
        tabla[0] = num;
        contElementos++;
    }

    public void insertIndice(int indice, Integer num){
        if (indice < 0 || indice > contElementos){
            System.out.println("Indice invalido");
        }
        if (contElementos == tabla.length){
            modificArray();
        }
        for(int i = contElementos; i < indice; i++){
            tabla[i] = tabla[contElementos - 1];
        }
        tabla[indice] = num;
        contElementos++;
    }

    public void insertTabla (Lista lista2){
        if (contElementos == tabla.length){
            modificArray();
        }
        for (int i = 0; i < lista2.getContElementos(); i++) {
            insertFinal(lista2.get(i));
        }
    }
    public void eliminar (int indice){
        if (indice < 0 || indice >= contElementos) {
            System.out.println("Índice no válido");
        }
        for (int i = indice; i < contElementos - 1; i++){
            tabla[i] = tabla[i + 1];
        }
        tabla[contElementos - 1] = null;
    }

    public Integer get (int indice) {
        if (indice < 0 || indice >= contElementos) {
            System.out.println("Índice no válido");
        }
        return tabla[indice];
    }

    public int buscar (Integer numero) {
        for ( int i = 0; i < contElementos; i++){
            if (tabla[i].equals(numero)){
                return i;
            };

        }
        return -1;
    }

    @Override
    public String toString() {
        return "Lista{" +
                "tabla=" + Arrays.toString(tabla) +
                ", contElementos=" + contElementos +
                '}';
    }
}
