public class PilaTabla {
    private int contElementos;
    private Integer [] pila;

    public PilaTabla() {

    }

    public void apilar() {

    }

    public void desapilar() {}
}
