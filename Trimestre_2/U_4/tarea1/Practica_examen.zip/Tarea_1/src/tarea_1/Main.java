package tarea_1;

public class Main {
    public static void main(String[] args) {
        HoraExacta h1 = new HoraExacta(80,59, 58);
        HoraExacta h2 = new HoraExacta(80,59, 58);
        System.out.println(h1.equals(h2));
    }
}
