package tarea_1;
//Actividad 1: Diseñar la clase Hora que representa un instante de tiempo compuesto por una hora (de 0 a 23) y los minutos.
//
//Dispone del constructor:
//
//Hora (hora,minuto), que construye un objeto con los datos pasados como parámetro
//y de los métodos:
//
//inc(), que incrementa la hora en un minuto
//setMinutos(valor), que da valor a los minutos, siempre y cuando sea un valor con sentido
//setHora(valor),que da valor a la hora, siempre y cuando sea un valor con sentido
//toString(), que devuelve un String con la representación del reloj.
public class Hora {
    protected int hora;
    protected int minuto;

    public Hora(int hora, int minuto) {
        if (minuto > 0 && minuto < 59){
            this.minuto = minuto;
        }
        if (hora > 0 && hora < 23){
            this.hora = hora;
        }

    }
    public void inc() {
        this.minuto++;
        if (this.minuto == 60){
            this.minuto = 0;
        this.hora++;
        }
    }
    public void setMinuto(int minuto) {
        if (minuto > 0 || minuto < 59){
            this.minuto = minuto;
        }
    }
    public void setHora(int hora){
        if (hora > 0 || hora < 23){
            this.hora = hora;
        }
    }

    @Override
    public String toString() {
        return "Hora{" +
                "hora=" + hora +
                ", minuto=" + minuto +
                '}';
    }
}
