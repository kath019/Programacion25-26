package tarea_1;

import java.util.Objects;

//Actividad 3: A partir de la clase Hora, implementar la clase HoraExacta, que incluye en la hora los segundos.
// Además de los métodos visibles de Hora, dispondrá de:
//HoraExacta(hora, minuto, segundo)
//setSegundo(valor), que da valor a los segundos, siempre y cuando sea un valor con sentido
//inc(), que incrementa la hora en un segundo
public class HoraExacta extends Hora{
    private int segundo;

    public HoraExacta(int hora, int minuto, int segundo) {
        super(hora, minuto);
        this.segundo = segundo;
    }
    public void setSegundo(int valor) {
        if ( valor > 0 && valor < 60) {
            this.segundo = valor;
        }
    }
    @Override
    public void inc (){
        this.segundo++;
        if (segundo > 60) {
            this.segundo = 0;
            this.minuto++;
            if (this.minuto == 60){
                this.minuto = 0;
                this.hora++;
            };
        }
    }

    @Override
    public String toString() {
        return "HoraExacta{" + super.hora + ":" + this.segundo +
                "segundo=" + segundo +
                '}';
    }

    //Actividad 4: Añadir a la clase HoraExacta un método que compare si dos horas (la invocante y la otra pasada como parámetro
    // de entrada al método) son iguales o distintas.

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        HoraExacta that = (HoraExacta) o;
        return segundo == that.segundo && minuto == that.minuto && hora == that.hora;
    }

}

//En primer lugar, diseña la clase Yogur sabiendo que un yogur siempre tiene 120.5 calorías.
// Se requiere implementar un método consultor para obtener sus calorías. A continuación, diseña la clase YogurDesnatado sabiendo
//  que siempre tiene la mitad de calorías que un Yogur normal. Finalmente, construye una clase Main con un método principal que
//   cree un objeto Yogur y un YogurDesnatado y muestre sus calorías.
