package tarea_1;
//Actividad 2: Escribir la clase Hora12, que funciona de forma similar a la clase Hora, con la diferencia de que las horas solo
// pueden tomar un valor entre 1 y 12; y se distingue la mañana de la tarde mediante "am" y "pm".
public class Hora12 extends Hora {
    public Hora12(int hora, int minuto) {
        super(hora, minuto);
    }
}
