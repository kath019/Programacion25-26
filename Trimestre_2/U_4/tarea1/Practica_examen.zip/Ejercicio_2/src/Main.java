//Escribe una clase Multimedia para almacenar información de los objetos de tipo multimedia (películas, discos, mp3,mp4…).
// Esta clase contiene título, autor, formato, y duración como atributos.
// El formato puede ser uno de los siguientes: wav, mp3, midi, avi, mov, mpg, cdAudio y dvd.
// El valor de todos los atributos se pasa por parámetro en el momento de crear el objeto.
// Esta clase tiene además, un método para devolver cada uno de los atributos y un método toString()
//  que devuelve la información del objeto. Por último, un método equals() que recibe
//   un objeto de tipo Multimedia y devuelve true en caso de que el título y el autor sean iguales y false en caso contrario.


//Escribe una clase Película que herede de la clase Multimedia anterior.
// La clase Película tiene, además de los atributos heredados, un actor principal y una actriz principal.
// Se permite que uno de los dos sea nulo, pero no los dos. La clase debe tener dos métodos para obtener los nuevos
// atributos y debe sobreescribir el método toString() para reflejar la nueva información.
void main() {
    Multimedia multimedia1 = new Multimedia("La Macarena", "Los del Río", Formato.mp3, 3.3);
    Pelicula pelicula1 = new Pelicula("Los juegos del hambre", "Susanne Collins",Formato.dvd, 144.30, "Josh", "Jennifer"  );

    System.out.println(multimedia1.toString());
    System.out.println(pelicula1.toString());

}
