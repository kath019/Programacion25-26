//El máximo de dos números con Math.max(_,_)
import java.util.Scanner;

public class practica_funcion4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un numero: ");
        int a = sc.nextInt();
        System.out.println("Ingrese otro numero: ");
        int b = sc.nextInt();

        System.out.println("El valor máximo es:");
        maximo(a, b);
    }
    static void maximo (int a, int b){
        int max;
        max = Math.max(a,b);
        System.out.println(max);
    }
}
