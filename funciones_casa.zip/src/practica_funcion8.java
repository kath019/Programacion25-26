import java.util.Scanner;

public class practica_funcion8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un número:");
        int n = sc.nextInt();
        System.out.println("Ingrese otro número:");
        int m = sc.nextInt();

    }
    static int sonAmigos (int n, int m){
        for (int i = 1; i < n; i++) {
            if (n % i == 0)
        }
    }
}
