// boolean para saber si n1 es primo
import java.util.Scanner;

public class practica_funcion7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un número:");
        int n1 = sc.nextInt();
        esPrimo(n1);
    }

    static boolean esPrimo(int n1){
        boolean esPrimo;
        int i = 2;
        if (n1 < i || n1 % 2 == 0 && n1 != 2){
            System.out.println(n1 + " No es primo");
            esPrimo = false;
        } else {
            System.out.println(n1 + " Es primo");
            esPrimo = true;
        }
        return esPrimo;
    }
}
