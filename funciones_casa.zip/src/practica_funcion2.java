//rango entre dos números
import java.util.Scanner;

public class practica_funcion2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el primer número:");
        int n1 = sc.nextInt();
        System.out.println("Ingrese el segundo número:");
        int n2 = sc.nextInt();

        rango(n1, n2);
    }
    static void rango(int n1, int n2) {
        int i;
        for (i = n1; i <= n2; i++) {
            System.out.print(i + " ");
        }
    }
}
