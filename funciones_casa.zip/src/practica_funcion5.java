//Máximo de 3 números con Math.max(_, math.max(_,_))
import java.util.Scanner;

public class practica_funcion5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el primer número:");
        int n1 = sc.nextInt();
        System.out.println("Ingrese el segundo número:");
        int n2 = sc.nextInt();
        System.out.println("Ingrese el tercer número:");
        int n3 = sc.nextInt();

        maximo(n1, n2,n3);
    }
    static void maximo (int n1, int n2, int n3){
        int max = Math.max(n1, Math.max(n2, n3));
        System.out.print("El número máximo es: " + max);

    }
}
