//calculo del area o volumen usando if en una función
import java.util.Scanner;

public class practica_funcion3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa el radio de la base:");
        double radio = sc.nextDouble();
        System.out.println("Ingresa la altura:");
        double altura = sc.nextDouble();
        System.out.println("Ingrese 1 para calcular el área, o 2 para el volumen:");
        int calculo = sc.nextInt();
        area(radio, altura, calculo);

    }
    static void area (double radio, double altura, int calculo ){
       double area;
       double volumen;
        if (calculo == 1){
            area = 2 * Math.PI * radio * (altura + radio);
            System.out.println("El area es: " + area);
        } else if (calculo == 2) {
            volumen = Math.PI * (radio * radio) * altura;
            System.out.println("El volumen es: " + volumen);
        } else {
            System.out.println("Error");
        }
        return;
    }
}
