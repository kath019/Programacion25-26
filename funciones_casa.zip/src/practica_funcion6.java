//uso de boolean en una funcion
import java.util.Scanner;

public class practica_funcion6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un caracter:");
        char caracter =sc.next().charAt(0);

        esVocal(caracter);
    }
    static boolean esVocal (char caracter){
        boolean resultado;
        if (caracter == 'a'|| caracter == 'e' ||caracter == 'i' || caracter =='o' || caracter == 'u') {
           System.out.println(caracter + " Es una vocal");
           resultado = true;
        } else {
            System.out.println(caracter + " No es una vocal");
            resultado = false;
        }
        return resultado;
    }
}
