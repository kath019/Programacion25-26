//Eco...
import java.util.Scanner;

public class practica_funcion1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese un número: ");
        int n = sc.nextInt();
        eco(n);
    }
    static void eco(int n) {
        for (int i = 1; i<= n; i++) {
            System.out.print("Eco...");
        }
    }

}
