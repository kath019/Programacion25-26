import java.util.Arrays;

class main{
    public static void main(String[] args) {
        Cliente [] clientes = new Cliente[5];

        clientes[0] = new Cliente("123A", "Laura", 30, 1500);
        clientes[1] = new Cliente("456B", "Carlos", 25, 2000);
        clientes[2] = new Cliente("789C", "Ana", 40, 3000);
        clientes[3] = new Cliente("111D", "Pedro", 22, 1200);
        clientes[4] = new Cliente("222E", "Marta", 35, 1800);


        //para el comparable
        Arrays.sort(clientes);
        System.out.println("---- Ordenados por DNI ----");
        for (Cliente c : clientes) {
            System.out.println(c);
        }

        //para el comparator de nombre
        Arrays.sort(clientes, new ComparadorNombre());
        System.out.println("\n---- Ordenados por Nombre ----");
        for (Cliente c : clientes) {
            System.out.println(c);
        }

        //para el comparator de edad
        Arrays.sort(clientes, new ComparadorEdad());
        System.out.println("\n---- Ordenados por Edad ----");
        for(Cliente c : clientes) {
            System.out.println(c);
        }
    }
}