public enum Color {
    AZUL,
    ROJO,
    VERDE,
    AMARILLO,
}
