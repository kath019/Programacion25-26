public class Circulo implements Figura{
    private double radio;
    private Color color;

    public Circulo(double radio, Color color) {
        this.radio = radio;
        this.color = color;
    }

    public Circulo() {
        this.radio = 10;
        this.color= Color.AZUL;
    }

    @Override
    public double getArea() {
        return Math.PI * radio * radio;
    }

    @Override
    public String toString() {
        return "Circulo{" +
                "radio=" + radio +
                ", color=" + color +
                "Area=" + getArea() +
                '}';
    }
}
