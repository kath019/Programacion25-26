import java.util.Comparator;

public class ComparadorColor implements Comparator<Triangulo> {


    @Override
    public int compare(Triangulo o1, Triangulo o2) {
        return o1.color.ordinal() - o2.color.ordinal(); //orden según enum
    }
}
