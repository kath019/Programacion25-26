import java.util.Arrays;
 public class Main {
     public static void main(String[] args) {

         // Array de Figuras
         Figura[] figuras = new Figura[5];
         figuras[0] = new Cuadrado(5, Color.ROJO);
         figuras[1] = new Triangulo(4, 6, Color.AMARILLO);
         figuras[2] = new Cuadrado(10, Color.VERDE);
         figuras[3] = new Circulo(7, Color.AZUL);
         figuras[4] = new Triangulo(8, 5, Color.ROJO);

         System.out.println("---- Figuras ----");
         for (Figura f : figuras) {
             System.out.println(f);
         }

         System.out.println("\nTotal de polígonos creados: " + PoligonoRegular.getContPoligonos());

         // Array de Triangulos
         Triangulo[] triangulos = new Triangulo[2];
         triangulos[0] = new Triangulo(4, 6, Color.AMARILLO);
         triangulos[1] = new Triangulo(8, 5, Color.ROJO);

         // Orden por lado (natural)
         Arrays.sort(triangulos);
         System.out.println("\n---- Triángulos ordenados por lado ----");
         for (Triangulo t : triangulos) System.out.println(t);

         // Orden por color
         Arrays.sort(triangulos, new ComparadorColor());
         System.out.println("\n---- Triángulos ordenados por color ----");
         for (Triangulo t : triangulos) System.out.println(t);
     }
 }
