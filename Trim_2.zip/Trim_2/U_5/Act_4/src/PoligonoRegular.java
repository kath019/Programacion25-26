abstract class PoligonoRegular implements Figura{
    protected double lado;
    public Color color;
    protected static int contPoligonos = 0;

    public PoligonoRegular(double lado, Color color) {
        this.lado = lado;
        this.color = color;
    }

    public PoligonoRegular() {
        this.lado = 10;
        this.color = Color.AZUL;
        contPoligonos++;
    }

    public static int getContPoligonos() {
        return contPoligonos;
    }

    @Override
    public abstract double getArea();
}
