public class Cuadrado extends PoligonoRegular{
    public Cuadrado(double lado, Color color) {
        super(lado, color);
    }

    public Cuadrado() {
        super();
    }

    @Override
    public double getArea() {
        return (double) (super.lado * super.lado);
    }

    @Override
    public String toString() {
        return "Cuadrado{" +
                "lado=" + lado +
                ", color=" + color +
                "area= " + getArea() +
                '}';
    }
}
