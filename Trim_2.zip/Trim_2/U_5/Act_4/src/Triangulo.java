//COMPARABLE POR LADO DEL TRIANGULO

import java.util.Comparator;
public class Triangulo extends PoligonoRegular implements Comparable<Triangulo> {
    private double altura;
    private double base;

    public Triangulo(double base, double altura, Color color) {
        super(base, color);//lado = base para orden natural
        this.lado = base;
        this.altura = altura;
    }

    public Triangulo() {
        super();
        this.base = 10;
        this.altura = 10;
    }

    public double getAltura() {
        return altura;
    }

    public double getBase() {
        return base;
    }

    @Override
    public double getArea() {
        return (base*altura) / 2;
    }

    @Override
    public int compareTo(Triangulo o) {
        return Double.compare(this.lado, o.lado);
    }

    @Override
    public String toString() {
        return "Triangulo{" +
                "altura=" + altura +
                ", base=" + base +
                "color=" + color +
                "area=" + getArea() +
                '}';
    }
}
