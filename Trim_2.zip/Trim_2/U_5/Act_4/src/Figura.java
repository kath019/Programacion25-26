public interface Figura {
    double getArea();
}
