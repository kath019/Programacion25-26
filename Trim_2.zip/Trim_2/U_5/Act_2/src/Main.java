import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // 🔹 Aquí elegimos la implementación
        // Pila p = new PilaTabla(10);
        Pila p = new PilaLista();

        //para acceder a un método que está en la clase y no en la interfaz
        ((PilaLista) p).tamaño();

        System.out.println("Introduce 10 números:");

        for (int i = 0; i < 10; i++) {
            int numero = sc.nextInt();
            p.apilar(numero);
        }

        System.out.println("\nNúmeros en orden inverso:");

        while (!p.estaVacia()) {
            System.out.println(p.desapilar());
        }

        sc.close();
    }
}
