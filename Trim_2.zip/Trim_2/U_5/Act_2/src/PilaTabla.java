import java.util.Arrays;

public class PilaTabla implements Pila {
    private int cima;
    private Integer [] cantDatos;

    public PilaTabla(int capacidad) {
        this.cima = -1;
        this.cantDatos = new Integer[capacidad];
    }

    @Override
    public void apilar(int elemento) {
        if (cima < cantDatos.length - 1) {
            cima++;
            cantDatos[cima] = elemento;
        } else {
            System.out.println("La pila está llena");
        }
    }

    @Override
    public int desapilar() {
        if (!estaVacia()) {
            int valor = cantDatos[cima];
            cima--;
            return valor;
        } else {
            System.out.println("La pila está vacía");
            return -1;
        }
    }

    @Override
    public boolean estaVacia() {
        return cima == -1;
    }

    @Override
    public String toString() {
        return "PilaTabla{" +
                "cima=" + cima +
                ", cantDatos=" + Arrays.toString(cantDatos) +
                '}';
    }


}

