public class PilaLista implements Pila{
    private int[] cantDatos;
    private int cima;

    public PilaLista() {
        this.cantDatos = new int[0];
        this.cima = -1;
    }

    @Override
    public void apilar(int elemento) {
        // Aumentamos tamaño del array
        int[] nuevo = new int[cantDatos.length + 1];

        for (int i = 0; i < cantDatos.length; i++) {
            nuevo[i] = cantDatos[i];
        }
        nuevo[cantDatos.length] = elemento;
        cantDatos = nuevo;
        cima++;
    }

    @Override
    public int desapilar() {
        if (!estaVacia()) {
            int valor = cantDatos[cima];
            int[] nuevo = new int[cantDatos.length - 1];
            for (int i = 0; i < nuevo.length; i++) {
                nuevo[i] = cantDatos[i];
            }
            cantDatos = nuevo;
            cima--;
            return valor;
        }
        System.out.println("La pila está vacía");
        return -1;
    }

    @Override
    public boolean estaVacia() {
        return cantDatos.length == 0;
    }

    // 🔥 MÉTODO EXTRA (no está en la interfaz)
    public void tamaño() {
        int tamanio = cima + 1;
        System.out.println(tamanio);
    }
}
