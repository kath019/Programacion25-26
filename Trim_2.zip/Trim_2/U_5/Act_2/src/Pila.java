public interface  Pila {
    void apilar(int elemento);

    int desapilar();

    boolean estaVacia();
}
