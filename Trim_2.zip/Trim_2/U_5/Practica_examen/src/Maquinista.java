public class Maquinista extends Empleado{
    private String DNI;
    private double sueldo;
    private String rango;

    public Maquinista(String nombre, double sueldo, String rango, String DNI) {
        super(nombre);
        this.DNI = DNI;
        this.sueldo = sueldo;
        this.rango = rango;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getRango() {
        return rango;
    }

    public void setRango(String rango) {
        this.rango = rango;
    }
}
