public class Mecanico extends Empleado{
    private float telefono;
    private Especialidad especialidad;

    public Mecanico(String nombre,  float telefono, Especialidad especialidad) {
        super(nombre);
        this.telefono = telefono;
        this.especialidad = especialidad;
    }

    public float getTelefono() {
        return telefono;
    }

    public void setTelefono(float telefono) {
        this.telefono = telefono;
    }

    public Especialidad getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(Especialidad especialidad) {
        this.especialidad = especialidad;
    }
}
