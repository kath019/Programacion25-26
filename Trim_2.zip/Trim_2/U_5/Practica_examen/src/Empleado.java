public class Empleado implements Comparable<Empleado>{
    @Override
    public int compareTo(Empleado o) {
        return this.nombre.compareTo(o.nombre);

    }

    protected String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
