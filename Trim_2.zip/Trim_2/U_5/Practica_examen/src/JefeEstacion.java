import java.util.Calendar;

public class JefeEstacion extends Empleado{
    private String DNI;
    private Calendar fecha;

    public JefeEstacion(String nombre, String DNI, Calendar fecha) {
        super(nombre);
        this.DNI = DNI;
        this.fecha = fecha;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }
}
