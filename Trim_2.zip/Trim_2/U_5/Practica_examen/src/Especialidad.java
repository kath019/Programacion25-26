public enum Especialidad {
    Frenos,
    Hidraulica,
    Electricidad,
    Motor,
}
