public class VehiculoFerroviario implements Comparable<VehiculoFerroviario> {
    protected String codigoId;

    public VehiculoFerroviario(String codigoId) {
        this.codigoId = codigoId;
    }

    public String getCodigoId() {
        return codigoId;
    }

    public void setCodigoId(String codigoId) {
        this.codigoId = codigoId;
    }

    @Override
    public int compareTo(VehiculoFerroviario o) {
        return this.codigoId.compareTo(o.codigoId);
    }
}
