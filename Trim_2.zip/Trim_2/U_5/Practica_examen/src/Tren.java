public class Tren extends VehiculoFerroviario{
    private Locomotora locomotora;
    private Vagon[] listvagones;
    private Maquinista maquinista;


    public Tren(String codigoId, Locomotora locomotora, Vagon[] listvagones, Maquinista maquinista) {
        super(codigoId);
        this.locomotora = locomotora;
        if(listvagones.length < 5){
        this.listvagones = listvagones;
        }
        this.maquinista = maquinista;
    }

    public Locomotora getLocomotora() {
        return locomotora;
    }

    public void setLocomotora(Locomotora locomotora) {
        this.locomotora = locomotora;
    }

    public Vagon[] getListvagones() {
        return listvagones;
    }

    public void setListvagones(Vagon[] listvagones) {
        this.listvagones = listvagones;
    }

    public Maquinista getMaquinista() {
        return maquinista;
    }

    public void setMaquinista(Maquinista maquinista) {
        this.maquinista = maquinista;
    }
}
