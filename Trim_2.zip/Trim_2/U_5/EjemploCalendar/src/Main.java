import java.util.Calendar;

// Clase con el Main
public class Main {
    public static void main(String[] args) {
        // Crear un objeto Obra con fecha inicial
        EjemploCalendar obra1 = new EjemploCalendar(2026, 2, 24);

        // Mostrar la fecha usando el método de la clase
        obra1.mostrarFecha();

        // Acceder directamente al Calendar desde el main
        Calendar fechaObra = obra1.getFecha();
        System.out.println("Año desde main: " + fechaObra.get(Calendar.YEAR));

        // Modificar la fecha desde el main usando el setter
        obra1.setFecha(2026, 12, 31);
        obra1.mostrarFecha();
    }
}