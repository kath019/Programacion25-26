import java.util.Calendar;

// Clase que tiene un atributo Calendar
public class EjemploCalendar {
    private Calendar fecha;

    // Constructor que recibe año, mes y día
    public EjemploCalendar(int año, int mes, int dia) {
        this.fecha = Calendar.getInstance();
        this.fecha.set(año, mes - 1, dia); // Los meses van de 0 a 11
    }

    // Método para mostrar la fecha
    public void mostrarFecha() {
        int año = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) + 1; // Ajustamos porque enero = 0
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        System.out.println("Fecha de la obra: " + dia + "/" + mes + "/" + año);
    }

    // Getter si quieres acceder a la fecha desde el main
    public Calendar getFecha() {
        return fecha;
    }

    // Setter si quieres modificar la fecha
    public void setFecha(int año, int mes, int dia) {
        this.fecha.set(año, mes - 1, dia);
    }
}
