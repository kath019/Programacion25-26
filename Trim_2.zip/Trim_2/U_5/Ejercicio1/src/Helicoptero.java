public class Helicoptero extends Avioneta{

    public Helicoptero(int cantPersonas, String nombre, double alt, String codigo) {
        super(cantPersonas, nombre, alt, codigo);
    }

}
