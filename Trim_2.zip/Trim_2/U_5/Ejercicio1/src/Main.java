//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
   Coche coche1 = new Coche(3, "SRV", "AAA-Y75", 2007, Color.AMARILLO);
   Coche coche2 = new Coche(4, "COROLA", "AAA-7RT", 2009, Color.AZUL);
   Coche coche3 = new Coche(5, "TOYOTA", "HIB-98Y", 1989, Color.ROJO);

   Motocicleta motocicleta1 = new Motocicleta(2, "HONDA", "OKH-7T6", 1999, Color.AMARILLO);
   Motocicleta motocicleta2 = new Motocicleta(2, "KAWASAKI", "DLW-72G", 1992, Color.AZUL);
   Motocicleta motocicleta3 = new Motocicleta(2, "HARLEY", "OKS-35R", 19994, Color.VERDE);

   Helicoptero helicoptero1 = new Helicoptero(4,"VEL206", 300, "SDHFB");
   Avioneta avioneta1 = new Avioneta(3, "Avioneta", 232, "LSNFAJ");

    System.out.println(helicoptero1.toString());
   helicoptero1.transportarPersonas(9);
   helicoptero1.volar();


}
