import java.util.Comparator;

public class ComparadorDesc implements Comparator<Terrestre> {

    @Override
    public int compare(Terrestre o1, Terrestre o2) {
        return Integer.compare( o2.getAnio(), o1.getAnio()); //Se cambia el método get

    }
}
