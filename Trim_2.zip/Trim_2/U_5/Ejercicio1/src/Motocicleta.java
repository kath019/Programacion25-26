public class Motocicleta extends Terrestre{
    public Motocicleta(int cantPersonas, String nombre, String matricula, int anio, Color color) {
        super(cantPersonas, nombre, matricula, anio, color);
    }
}
