public class Coche extends Terrestre{
    public Coche(int cantPersonas, String nombre, String matricula, int anio, Color color) {
        super(cantPersonas, nombre, matricula, anio, color);
    }
}
