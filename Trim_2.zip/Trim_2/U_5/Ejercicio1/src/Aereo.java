public class Aereo extends Vehículo{
    private double alt;
    private String codigo;


    public Aereo(int cantPersonas, String nombre, double alt, String codigo) {
        super(cantPersonas, nombre);
        this.alt = alt;
        this.codigo = codigo;
    }


    public double getAlt() {
        return alt;
    }

    public void setAlt(double alt) {
        this.alt = alt;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void volar(){
        System.out.println(getClass().getSimpleName() + " volando a " + alt);
    }

    @Override
    public String toString() {
        return "Aereo{" +
                "alt=" + alt +
                ", codigo='" + codigo + '\'' +
                '}';
    }
}
