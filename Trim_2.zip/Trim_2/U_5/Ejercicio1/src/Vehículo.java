import java.util.Objects;

public class Vehículo {
    private String nombre;
    private int capacidad;

    public Vehículo(int cantPersonas, String nombre) {
        this.capacidad = cantPersonas;
        this.nombre = nombre;
    }

    public void transportarPersonas(int cantPersonas) {
        if(cantPersonas > 0 && cantPersonas < capacidad) {
            this.capacidad = cantPersonas;
        } else {
            System.out.println("No es posible hacer el transporte");
        }
    }

    @Override
    public String toString() {
        return "Vehículo{" +
                "nombre='" + nombre + '\'' +
                ", capacidad=" + capacidad +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Vehículo vehículo = (Vehículo) o;
        return capacidad == vehículo.capacidad && Objects.equals(nombre, vehículo.nombre);
    }

}
