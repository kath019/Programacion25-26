import java.util.Objects;

public class Terrestre extends Vehículo implements Comparable<Terrestre>{
    @Override
    public int compareTo(Terrestre o) {
        return this.matricula.compareTo(o.matricula);
    }

    private String matricula;
    private int anio;
    private Color color;

    public Terrestre(int cantPersonas, String nombre, String matricula, int anio, Color color) {
        super(cantPersonas, nombre);
        this.matricula = matricula;
        this.anio = anio;
        this.color = color;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return "Terrestre{" +
                "matricula='" + matricula + '\'' +
                ", anio=" + anio +
                ", color=" + color +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Terrestre terrestre = (Terrestre) o;
        return Objects.equals(matricula, terrestre.matricula);
    }


}
