import java.util.Comparator;

public class Comparador implements Comparator <Terrestre> {

    @Override
    public int compare(Terrestre o1, Terrestre o2) {
        return Integer.compare(o1.getAnio(), o2.getAnio()); //Se cambia el método get
    }
}
