public enum Color {
    AZUL,
    AMARILLO,
    ROJO,
    VERDE,
}
