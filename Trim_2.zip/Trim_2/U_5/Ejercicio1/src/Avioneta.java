public class Avioneta extends Aereo{

    public Avioneta(int cantPersonas, String nombre, double alt, String codigo) {
        super(cantPersonas, nombre, alt, codigo);
    }
}
