import java.util.Comparator;

public class Lavadora extends Electrodomestico implements Comparable<Lavadora>{

    private double carga;

    @Override
    public int compareTo(Lavadora o) {
        return Double.compare(this.carga, o.carga);
    }

    public Lavadora() {
        super();
        this.carga = 5.0;
    }

    public Lavadora(double precio, double peso) {
        super(precio, peso);
        this.carga = 5.0;
    }

    public Lavadora(double precio, double peso, Color color, ConsumoEnergetico consumo, double carga) {
        super(precio, peso, color, consumo);
        this.carga = carga;
    }

    public double getCarga() {
        return carga;
    }

    @Override
    public double getPrecioFinal() {
        double precioFinal = super.getPrecioFinal();
        if (carga > 30){
            precioFinal += 50;
        }
        return precioFinal;
    }

    @Override
    public String toString() {
        return "Lavadora{" +
                "carga=" + carga +
                ", color=" + color +
                ", consumo=" + consumo +
                ", peso=" + peso +
                "precio final=" + getPrecioFinal() +
                '}';
    }
}
