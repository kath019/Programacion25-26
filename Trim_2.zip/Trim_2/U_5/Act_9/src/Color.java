public enum Color {
    BLANCO,
    NEGRO,
    ROJO,
    AZUL,
    GRIS,
}
