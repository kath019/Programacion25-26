import java.util.Comparator;

public class Comparador implements Comparator<Lavadora> {

    @Override
    public int compare(Lavadora l1, Lavadora l2) {
        return Double.compare(l1.getPrecioFinal(), l2.getPrecioFinal());
    }
}
