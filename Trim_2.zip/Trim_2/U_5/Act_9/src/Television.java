public class Television extends Electrodomestico{
    private double resolucion;
    private boolean sintonizadorTDT;

    public Television() {
        super();
        this.resolucion = 20;
        this.sintonizadorTDT = false;
    }

    public Television(double precio, double peso) {
        super(precio, peso);
        this.resolucion = 20;
        this.sintonizadorTDT = false;
    }

    public Television(double precio, double peso, Color color, ConsumoEnergetico consumo, double resolucion,  boolean sintonizadorTDT) {
        super(precio, peso, color, consumo);
        this.resolucion = resolucion;
        this.sintonizadorTDT = sintonizadorTDT;
    }

    public double getResolucion() {
        return resolucion;
    }

    public boolean isSintonizadorTDT() {
        return sintonizadorTDT;
    }

    @Override
    public double getPrecioFinal() {
        double precioFinal = super.getPrecioFinal();
        if(resolucion > 40){
            precioFinal += precioFinal * 0.3;
        }
        if (sintonizadorTDT) {
            precioFinal += 50;
        }
        return precioFinal;
    }

    @Override
    public String toString() {
        return "Television{" +
                "resolucion=" + resolucion +
                ", sintonizador TDT=" + sintonizadorTDT +
                ", precio final=" + getPrecioFinal() +
                ", color=" + color +
                ", consumo=" + consumo +
                ", peso=" + peso +
                '}';
    }
}
