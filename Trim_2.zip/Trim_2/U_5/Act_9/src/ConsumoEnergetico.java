public enum ConsumoEnergetico {
    A,
    B,
    C,
    D,
    E,
    F,
}
