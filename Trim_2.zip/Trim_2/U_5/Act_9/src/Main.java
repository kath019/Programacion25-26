//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import java.util.Arrays;

    public class Main {

        public static void main(String[] args) {

            Electrodomestico[] electrodomesticos = new Electrodomestico[10];

            electrodomesticos[0] = new Electrodomestico();
            electrodomesticos[1] = new Lavadora(300, 40, Color.AZUL, ConsumoEnergetico.A, 35);
            electrodomesticos[2] = new Television(500, 20, Color.NEGRO, ConsumoEnergetico.B, 50, true);
            electrodomesticos[3] = new Lavadora(200, 25);
            electrodomesticos[4] = new Television();
            electrodomesticos[5] = new Lavadora();
            electrodomesticos[6] = new Television(700, 60, Color.GRIS, ConsumoEnergetico.C, 45, false);
            electrodomesticos[7] = new Electrodomestico(150, 10);
            electrodomesticos[8] = new Lavadora(450, 55, Color.ROJO, ConsumoEnergetico.A, 40);
            electrodomesticos[9] = new Television(600, 30);

            System.out.println("---- LISTA ELECTRODOMESTICOS ----");
            for (Electrodomestico e : electrodomesticos) {
                System.out.println(e);
            }

            // ARRAY LAVADORAS
            Lavadora[] lavadoras = {
                    new Lavadora(300, 40, Color.AZUL, ConsumoEnergetico.A, 35),
                    new Lavadora(200, 20),
                    new Lavadora(450, 55, Color.ROJO, ConsumoEnergetico.B, 50)
            };

            Arrays.sort(lavadoras);

            System.out.println("\n---- ORDENADAS POR CARGA ----");
            for (Lavadora l : lavadoras) {
                System.out.println(l);
            }

            Arrays.sort(lavadoras, new Comparador());

            System.out.println("\n---- ORDENADAS POR PRECIO FINAL ----");
            for (Lavadora l : lavadoras) {
                System.out.println(l);
            }
        }
    }
