public class Electrodomestico {
    protected double precio;
    protected Color color;
    protected ConsumoEnergetico consumo;
    protected double peso;

    public Electrodomestico() {
        this.precio = 100.0;
        this.color = Color.BLANCO;
        this.consumo = ConsumoEnergetico.F;
        this.peso = 5.0;
    }

    public Electrodomestico(double precio, double peso) {
        this.precio = precio;
        this.peso = peso;
        this.color = Color.BLANCO;
        this.consumo = ConsumoEnergetico.F;
    }

    public Electrodomestico(double precio, double peso, Color color, ConsumoEnergetico consumo) {
        this.precio = precio;
        this.peso = peso;
        this.color = color;
        this.consumo = consumo;
    }

    public double getPrecio() {
        return precio;
    }

    public Color getColor() {
        return color;
    }

    public ConsumoEnergetico getConsumo() {
        return consumo;
    }

    public double getPeso() {
        return peso;
    }

    public double getPrecioFinal() {
        double precioFinal = 0;

        switch (consumo) {
            case A: precioFinal += 100;
            break;
            case B: precioFinal += 80;
            break;
            case C: precioFinal += 60;
            break;
            case D: precioFinal += 50;
            break;
            case E: precioFinal += 30;
            break;
            case F: precioFinal += 10;
        }

        if(peso < 30 && peso > 0) {
            precioFinal += 10;
        } else if(peso < 50 && peso > 29){
            precioFinal += 60;
        } else if (peso < 80 && peso > 49){
            precioFinal += 80;
        } else {
            precioFinal += 100;
        }
        return precioFinal;
    }

    @Override
    public String toString() {
        return "Electrodomestico{" +
                "precio inicial=" + precio +
                ", precio final=" + getPrecioFinal() +
                ", color=" + color +
                ", consumo=" + consumo +
                ", peso=" + peso +
                '}';
    }
}
