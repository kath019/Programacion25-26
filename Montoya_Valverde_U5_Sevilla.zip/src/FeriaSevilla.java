import java.util.Arrays;
import java.util.Calendar;

public class FeriaSevilla extends Evento implements Comparable<FeriaSevilla>{
    private Caseta[] listCasetas;
    private int contCasetas;
    private ActuacionesArtisticas[] listActuaciones;
    private int contActuaciones;

    public FeriaSevilla(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        super(id, fecha, nombre, coordinador);
        this.listCasetas = new Caseta[10];
        this.contCasetas = 0;
        this.listActuaciones = new ActuacionesArtisticas[4];
        this.contActuaciones = 0;
    }

    public Caseta[] getListCasetas() {
        return listCasetas;
    }

    public void setListCasetas(Caseta[] listCasetas) {
        this.listCasetas = listCasetas;
    }

    public ActuacionesArtisticas[] getListActuaciones() {
        return listActuaciones;
    }

    public void setListActuaciones(ActuacionesArtisticas[] listActuaciones) {
        this.listActuaciones = listActuaciones;
    }

    public void addCaseta(Caseta nuevaCaseta){
        if (contCasetas < listCasetas.length) {
            this.listCasetas[contCasetas] = nuevaCaseta;
        } else {
            System.out.println("No hay espacio para más casetas");
        }

        listCasetas[contCasetas] = nuevaCaseta;
        contCasetas++;
    }

    public void eliminarActuacion(){
        int indice = -1;
        if (contActuaciones < 1) {
            System.out.println("No hay casetas apara eliminar");
        } else {
            for (int i = indice; i < contActuaciones - 1; i++) {
                listActuaciones[i] = listActuaciones[i + 1];
            }
            listActuaciones[contActuaciones - 1] = null;
            contActuaciones--;
        }
    }

    public void addActArtisticas(ActuacionesArtisticas nuevaActuacion) {
        if (contActuaciones < listActuaciones.length) {
            this.listActuaciones[contActuaciones] = nuevaActuacion;
        } else {
            System.out.println("No hay espacio para más actuaciones");
        }
        listActuaciones[contActuaciones] = nuevaActuacion;
        contActuaciones++;
    }

    public void eliminarCaseta(){
        int indice = -1;
        if (contCasetas < 1) {
            System.out.println("No hay casetas apara eliminar");
        } else {
            for (int i = indice; i < contCasetas - 1; i++) {
                listCasetas[i] = listCasetas[i + 1];
            }
            listCasetas[contCasetas - 1] = null;
            contCasetas--;
        }
    }

    @Override
    void celebrar() {
        System.out.println("Celebrando Feria con" + contCasetas + " casetas y " + contActuaciones + " actuaciones artísticas");
    }

    @Override
    public String toString() {
        return "FeriaSevilla{" +
                "listCasetas=" + Arrays.toString(listCasetas) +
                ", contCasetas=" + contCasetas +
                ", listActuaciones=" + Arrays.toString(listActuaciones) +
                ", contActuaciones=" + contActuaciones +
                '}';
    }

    @Override
    public int compareTo(FeriaSevilla o) {
        return Double.compare(this.contCasetas, o.contCasetas);
    }
}
