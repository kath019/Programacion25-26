import java.util.Arrays;
import java.util.Calendar;

public class SemanaSanta extends Evento implements Comparable<SemanaSanta>{
    private PasosProvisionales[] listpasos;
    private int contPasos;
    private String nombreHermandad;
    private int cantCostaleros;

    public SemanaSanta(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        super(id, fecha, nombre, coordinador);
        this.listpasos = new PasosProvisionales[15];
        this.contPasos = 0;
    }

    public PasosProvisionales[] getListpasos() {
        return listpasos;
    }

    public void setListpasos(PasosProvisionales[] listpasos) {
        this.listpasos = listpasos;
    }

    public int getContPasos() {
        return contPasos;
    }

    public void setContPasos(int contPasos) {
        this.contPasos = contPasos;
    }

    public String getNombreHermandad() {
        return nombreHermandad;
    }

    public void setNombreHermandad(String nombreHermandad) {
        this.nombreHermandad = nombreHermandad;
    }

    public int getCantCostaleros() {
        return cantCostaleros;
    }

    public void setCantCostaleros(int cantCostaleros) {
        this.cantCostaleros = cantCostaleros;
    }

    public void addPaso(PasosProvisionales nuevoPaso){
        if (contPasos < listpasos.length) {
            this.listpasos[contPasos] = nuevoPaso;
        } else {
            System.out.println("No hay espacio para más Pasos Provisionales");
        }

        listpasos[contPasos] = nuevoPaso;
        contPasos++;
    }

    public void eliminarPaso(){
        int indice = -1;
        if (contPasos < 1) {
            System.out.println("No hay casetas apara eliminar");
        } else {
            for (int i = indice; i < contPasos - 1; i++) {
                listpasos[i] = listpasos[i + 1];
            }
            listpasos[contPasos - 1] = null;
            contPasos--;
        }
    }

    @Override
    void celebrar() {
        System.out.println("Celebrando Semana Santa con" + contPasos + " pasos procesionales");
    }

    @Override
    public String toString() {
        return "SemanaSanta{" +
                "listpasos=" + Arrays.toString(listpasos) +
                ", contPasos=" + contPasos +
                ", nombreHermandad='" + nombreHermandad + '\'' +
                ", cantCostaleros=" + cantCostaleros +
                '}';
    }

    @Override
    public int compareTo(SemanaSanta o) {
        return Double.compare(this.contPasos, o.contPasos);
    }
}
