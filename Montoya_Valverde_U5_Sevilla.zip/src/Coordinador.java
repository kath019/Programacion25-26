import java.util.Calendar;

public class Coordinador extends Evento{
    private String apellidos;
    private String nombre;
    private int numEmpleado;

    public Coordinador(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        super(id, fecha, nombre, coordinador);
    }


    @Override
    void celebrar() {

    }
}
