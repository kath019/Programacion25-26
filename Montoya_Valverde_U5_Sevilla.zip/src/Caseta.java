import java.util.Calendar;

public class Caseta extends FeriaSevilla{
    private String idunico;


    public Caseta(String id, Calendar fecha, String nombre, Coordinador coordinador, String nuevoId) {
        super(id, fecha, nombre, coordinador);
        this.idunico = nuevoId;
    }

    @Override
    void celebrar() {
        super.celebrar();
    }
}
