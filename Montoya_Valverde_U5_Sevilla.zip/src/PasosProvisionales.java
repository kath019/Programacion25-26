import java.util.Calendar;

public class PasosProvisionales  extends SemanaSanta{
    public PasosProvisionales(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        super(id, fecha, nombre, coordinador);
    }

}
