import java.util.Calendar;

public class ActuacionesArtisticas extends Evento implements Interfaces{
    private String nombreArtista;
    private int duracion;
    private String generoMusical;
    private double precioArtista;
    private Evento FeriaSevilla;
    private Evento SemanaSanta;
    private Evento PasosProvisionales;

    public ActuacionesArtisticas(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        super(id, fecha, nombre, coordinador);
    }


    @Override
    public void ensayar(Evento evento, int duracion) {
        if (evento == FeriaSevilla) {
            System.out.println("Ensayando actuación de " + FeriaSevilla + " con duración " + duracion + " minutos");
        } else if (evento == SemanaSanta) {
            System.out.println("Ensayando actuación de" + SemanaSanta + " con duración " + duracion + " minutos");
        } else {
            System.out.println("Ensayando actuación de" + evento + " con duración " + duracion + " minutos");
        }
    }
    @Override
    public void programar(Evento evento) {
        if(evento == FeriaSevilla){
            System.out.println("La actuación de" + FeriaSevilla + " se puede programar libremente");
        } else if (evento == SemanaSanta) {
            System.out.println("La actuación de" + SemanaSanta + " se puede programar libremente");
        } else if (evento == PasosProvisionales) {
            System.out.println("La actuación de" +PasosProvisionales + " tiene horario fijo de procesión");
        } else {
            System.out.println("La actuación de" + evento + " se puede programar libremente");
        }
    }

    @Override
    public void procesionar(PasosProvisionales pasos) {
        System.out.println("El paso de la hermandad " + pasos.getNombreHermandad() + " está procesionando con " + pasos.getCantCostaleros() + " costaleros");
    }


    @Override
    void celebrar() {

    }
}
