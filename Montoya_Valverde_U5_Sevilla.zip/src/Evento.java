import java.util.Calendar;

abstract class Evento {
    protected String id;
    protected Calendar fecha;
    protected String nombre;
    protected Coordinador coordinador;
    protected static int contActArtisticas = 0;

    public Evento(String id, Calendar fecha, String nombre, Coordinador coordinador) {
        this.id = id;
        this.fecha = fecha;
        this.nombre = nombre;
        this.coordinador = coordinador;
    }

    public static int getContActArtisticas() {
        return contActArtisticas;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Calendar getFecha() {
        return fecha;
    }

    public void setFecha(Calendar fecha) {
        this.fecha = fecha;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Coordinador getCoordinador() {
        return coordinador;
    }

    public void setCoordinador(Coordinador coordinador) {
        this.coordinador = coordinador;
    }

    abstract void celebrar();
}


