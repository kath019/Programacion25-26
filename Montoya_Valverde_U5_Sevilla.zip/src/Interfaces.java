public interface Interfaces {
    void ensayar(Evento evento, int duracion);
    void programar(Evento evento);
    void procesionar(PasosProvisionales pasos);
}
