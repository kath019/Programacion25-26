//funcion  convierteArrayEnString
public class Array_30_2 {
    public static String convierteArrayEnString(int[] a) {

        String resultado = "";

        // Recorremos el array
        for (int i = 0; i < a.length; i++) {
            resultado += a[i];
        }

        return resultado;
    }

    public static void main(String[] args) {
        // Ejemplo 1: array vacío
        int[] a1 = {};
        System.out.println("Resultado 1: \"" + convierteArrayEnString(a1) + "\"");

        // Ejemplo 2: un solo elemento
        int[] a2 = {8};
        System.out.println("Resultado 2: \"" + convierteArrayEnString(a2) + "\"");

        // Ejemplo 3: varios elementos
        int[] a3 = {6, 2, 5, 0, 1};
        System.out.println("Resultado 3: \"" + convierteArrayEnString(a3) + "\"");
    }
}
