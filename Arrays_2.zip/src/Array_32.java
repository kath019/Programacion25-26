//funcion interseccionVectores()
import java.util.Arrays;
import java.util.Scanner;
public class Array_32 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el tamaño del primer vector: ");
        int n1 = sc.nextInt();
        int[] v1 = new int[n1];

        System.out.println("Introduce los elementos del primer vector:");
        for (int i = 0; i < n1; i++) {
            v1[i] = sc.nextInt();
        }

        // Leer tamaño del segundo vector
        System.out.print("Introduce el tamaño del segundo vector: ");
        int n2 = sc.nextInt();
        int[] v2 = new int[n2];

        // Leer elementos del segundo vector
        System.out.println("Introduce los elementos del segundo vector:");
        for (int i = 0; i < n2; i++) {
            v2[i] = sc.nextInt();
        }

        // Llamar a la función
        int[] interseccion = interseccionVectores(v1, v2);

        // Mostrar resultado
        System.out.println("Intersección de los vectores:");
        System.out.println(Arrays.toString(interseccion));
    }
    public static int[] interseccionVectores(int[] v1, int[] v2) {
        // Array auxiliar con tamaño máximo posible
        int[] aux = new int[Math.min(v1.length, v2.length)];
        int contador = 0;

        // Buscar elementos comunes
        for (int i = 0; i < v1.length; i++) {
            for (int j = 0; j < v2.length; j++) {
                if (v1[i] == v2[j]) {

                    // Evitar duplicados en el resultado
                    boolean repetido = false;
                    for (int k = 0; k < contador; k++) {
                        if (aux[k] == v1[i]) {
                            repetido = true;
                            break;
                        }
                    }
                    if (!repetido) {
                        aux[contador] = v1[i];
                        contador++;
                    }
                }
            }
        }
        // Crear el array final con el tamaño exacto
        int[] resultado = Arrays.copyOf(aux, contador);
        // Ordenar el vector resultado
        Arrays.sort(resultado);
        return resultado;
    }
}
