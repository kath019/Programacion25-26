//matriz 4 x 4 matriz mágica
//la suma de los elementos de cualquier fila o columna vale lo mismo
//se usa como patron la suma de la primera fila o columna

import java.util.Scanner;

public class Arrays_11 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //suma de la primera fila, se usará como patrón
        int patron = 0;

        //el tamaño se define como una constante, si queremos utilizar otro
        //tamaño, basta con con redefinir la constante.
        final int TAM = 4;
        int [][] matriz = new int [TAM][TAM];

        for (int i = 0; i < TAM; i++) {
            for (int j = 0; j < TAM; j++) {
                System.out.print("Elemento [" + i + "][" + j + "]: ");
                matriz[i][j] = sc.nextInt();
            }
        }

        //suponemos que la matriz es mágica,
        // cuando sea falso modificamos la variable a false.
        boolean esMagica = true;

        //obtenemos la suma (patrón) para comparar con el resto.
        for (int c = 0; c < TAM; c++) {
            patron += matriz[0][c];//calculamos la suma de la primera fila
        }

        //sumamos las columnas
        for (int c = 0; c < TAM; c++) {//utilizamos c para las columnas
            int sumaColumna = 0;
            for (int f = 0; f < TAM; f++){//f para las filas
                sumaColumna += matriz[f][c];
            }
            if (sumaColumna != patron) {
                esMagica = false;
            }
        }

        //sumamos todos los elementos que forman parte de una fila
        for (int f = 0; f < TAM; f++) {//f para las filas
            int sumaFila = 0;
            for (int c = 0; c <TAM; c++){
                sumaFila +=  matriz[f][c];
            }
            if (sumaFila != patron) {
                esMagica = false;
            }
        }

        if (esMagica) {//si es true
            System.out.println("La matriz es mágica");
        } else {//si es false
            System.out.println("La matriz no es mágica");
        }
    }
}
