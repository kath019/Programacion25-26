// función convierteStringEnArray, toma como parámetro un String
//que solo tiene números y devuelve un array con las cifras que contiene el número

public class Array_30 {
    public static void main(String[] args) {
        String numero = "62501";
        int[] resultado = convierteArrayEnString(numero);

        // Mostrar array resultado
        System.out.print("Array resultado: ");
        for (int i = 0; i < resultado.length; i++) {
            System.out.print(resultado[i] + " ");
        }
    }

    //Convierte un String numérico en un array de enteros
    public static int[] convierteArrayEnString(String a) {

        // Si el string está vacío, devolver array vacío
        if (a.length() == 0) {
            return new int[0];
        }

        int[] resultado = new int[a.length()];

        // Convertir cada carácter en número
        for (int i = 0; i < a.length(); i++) {
            resultado[i] = Character.getNumericValue(a.charAt(i));
        }
        return resultado;
    }
}
