//Desarrollar una aplicación para gestionar 5 notas de cada trimestre,
// de un centro y la media del alumno que se encuentra en 'pos'

import java.util.Scanner;

public class Arrays_9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final int NUM_ALUM = 5; //número de alumnos por grupo
        double medialumno;

        //declaramos y creamos las tablas necesarias
        int [] primer = new int[NUM_ALUM];//notas de cada trimestre
        int [] segundo = new int [NUM_ALUM];
        int [] tercer = new int [NUM_ALUM];

        System.out.println("Notas del primer trimestre: ");
        leerNotas(primer);//leemos las notas del primer trimestre
        System.out.println("Notas del segundo trimestre: ");
        leerNotas(segundo);//leemos las notas del segundo trimestre
        System.out.println("Notas del tercero trimestre: ");
        leerNotas(tercer);//leemos las notas del tercer trimestre

        //calculamos las medias
        int sumaPrimer = 0;//ponemos a 0 los contadores de cada trimestre
        int sumaSegundo = 0;
        int sumaTercero = 0;

        //recorremos las tres tablas, a la vez acumulamos las notas
        //para calcular las medias
        for (int i = 0; i < NUM_ALUM; i++) {
            sumaPrimer += primer[i];
            sumaSegundo += segundo[i];
            sumaTercero += tercer[i];
        }

        //Mostrar datos
        System.out.println("Media primer trimestre: " + sumaPrimer / NUM_ALUM);
        System.out.println("Media segundo trimestre: " + sumaSegundo / NUM_ALUM);
        System.out.println("Media tercer trimestre: " + sumaTercero / NUM_ALUM);
        System.out.println();

        //leemos la posición del alumno que nos interesa, suponemos que el
        // usuario introduce un índice que no se sale de la tabla
        System.out.println("Introduzca posición del alumno: ");
        int pos = sc.nextInt();

        //la media del alumno es la suma de sus notas entre 3
        medialumno = ((double) (primer[pos] + segundo[pos] + tercer[pos]) / 3);
        System.out.println("Media del alumno: " + medialumno);
    }

    //esta funcion lee las notas de un grupo en la tabla t
    static void leerNotas(int[] t) {
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < t.length; i++) {
            System.out.print("Alumno " + i +": ");
            t [i] = sc.nextInt();
        }
    }
}
/*
//esta versión es como el anterior pero con una tabla bidimensional
public static void main (Sring [] args) {
Scanner sc = new Scanner(System.in);
final int NUM_ALUM = 5;//número de alumnos por grupo
//declaramos y creamos el array bidimensional
int notas [] [] = new int [3][NUM_ALUM]

for (int trimestre = 0; trimestre < 3; trimestre++) {
System.out.println("Notas para el trimestre " + (trimestre + 1));
leerNotas(notas, trimestre);
}
//calculamos las medias, utilizamos una tabla de 3 elementos, donde
//acumulamos las notas de cada trimestre
int suma [] = new int [3];
for (int alumn = 0; alumn < NUM_ALUM; alumn++){
for (int trim = 0; trim < 3; trim++){
suma[trim] += notas[trim][alumn];
}
}
//mostramos los datos
System.out.println("Media primer trimestre: " + (double) suma[0] /NUM_alum);
System.out.println("Media segundo trimestre: " + (double) suma[1] /NUM_alum);
System.out.println("Media tercer trimestre: " + (double) suma[2] /NUM_alum);

//leemos la posición del alumno que nos interesa
System.out.println("Introduzca la posición del alumno: ");
int pos = sc.nextInt();
//la media es la suma de sus notas entre 3
double mediaAlumno =(double) (notas[0] [pos] + notas[1][pos] + notas[2][pos])/3;
System.out.println("La media del alumno: " + mediaAlumno);

}
static void leerNotas(int t [],int trimestre) {
Scanner sc = new Scanner(System.in);
for ( int i = 0; i < t[trimestre].lenght; i++){
System.out.print("Alumno (" + i + "): ");
t[trimestre][i] = sc.next.Int();
}
}
 */
