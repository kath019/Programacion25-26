//algoritmo que solicite al usuario una cifra N y rellene un array
// bidimensional de N filas y N columnas con números aleatorios
// entre 100 y 200. Mostrar dicho array y a continuación rotarlo 90 grados.

import java.util.Random;
import java.util.Scanner;

public class Array_27 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        // Pedimos la dimensión del array
        System.out.print("Introduce la dimensión del array: ");
        int n = sc.nextInt();

        // Creamos el array original NxN
        int[][] matriz = new int[n][n];

        // Rellenamos la matriz con números aleatorios entre 100 y 200
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = rand.nextInt(101) + 100; // 100 a 200
            }
        }

        // Mostramos la matriz original
        System.out.println("\nMatriz original:");
        mostrarMatriz(matriz);

        // Rotamos la matriz 90 grados
        int[][] matrizRotada = rotar90(matriz);

        // Mostramos la matriz rotada
        System.out.println("\nMatriz rotada 90 grados:");
        mostrarMatriz(matrizRotada);
    }

    //Muestra una matriz por pantalla
    public static void mostrarMatriz(int[][] matriz) {

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println();
        }
    }

    //Rotar la matriz
    public static int[][] rotar90(int[][] matriz) {

        int n = matriz.length;
        int[][] rotada = new int[n][n];

        // Fórmula de rotación 90º
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                rotada[j][n - 1 - i] = matriz[i][j];
            }
        }
        return rotada;
    }
}
