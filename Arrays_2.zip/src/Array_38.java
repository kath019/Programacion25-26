// funcion mezcla()
// devuelve un array que es el resultado de mezclar los números
// de ambos de forma alterna, se coge un número de a, luego de b

import java.util.Arrays;

public class Array_38 {
    public static void main(String[] args) {

        // Ejemplos de prueba
        int[] a1 = {8, 9, 0};
        int[] b1 = {1, 2, 3};

        int[] a2 = {4, 3};
        int[] b2 = {7, 8, 9, 10};

        int[] a3 = {8, 9, 0, 3};
        int[] b3 = {1};

        int[] a4 = {};
        int[] b4 = {1, 2, 3};

        // Mostrar resultados
        System.out.println(Arrays.toString(mezcla(a1, b1)));
        System.out.println(Arrays.toString(mezcla(a2, b2)));
        System.out.println(Arrays.toString(mezcla(a3, b3)));
        System.out.println(Arrays.toString(mezcla(a4, b4)));
    }

    //Mezcla dos arrays alternando sus elementos.
     //Si uno se queda sin elementos, se añaden los restantes del otro.
    public static int[] mezcla(int[] a, int[] b) {
        // Array resultado con el tamaño total de ambos
        int[] resultado = new int[a.length + b.length];

        int i = 0; // índice para a
        int j = 0; // índice para b
        int k = 0; // índice para resultado

        // Mientras queden elementos en ambos arrays
        while (i < a.length && j < b.length) {
            resultado[k++] = a[i++];
            resultado[k++] = b[j++];
        }

        // Copiar los elementos restantes de a (si los hay)
        while (i < a.length) {
            resultado[k++] = a[i++];
        }

        // Copiar los elementos restantes de b (si los hay)
        while (j < b.length) {
            resultado[k++] = b[j++];
        }
        return resultado;
    }
}
