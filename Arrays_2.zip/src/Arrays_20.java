//Escribe un programa que pida 8 palabras y las almacene en un array.
//las palabras correspondientes a colores se deben almacenar al comienzo.
// Los colores que conoce el programa deben estar en otro array y son:
// verde, rojo, azul, amarillo, naranja, rosa, negro, blanco y morado.

import java.util.Scanner;

public class Arrays_20 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Array para guardar las 8 palabras
        String[] palabras = new String[8];

        // Array con los colores conocidos
        String[] colores = {
                "verde", "rojo", "azul", "amarillo",
                "naranja", "rosa", "negro", "blanco", "morado"
        };

        // Pedir las palabras al usuario
        System.out.println("Introduce 8 palabras:");
        for (int i = 0; i < palabras.length; i++) {
            System.out.print((i + 1) + ": ");
            palabras[i] = sc.next().toLowerCase(); // pasamos a minúsculas
        }

        // Mostrar array original
        System.out.println("\nArray original:");
        mostrarArray(palabras);

        // Array resultado
        String[] resultado = new String[8];
        int indice = 0;

        // 1. Colocar primero los colores
        for (int i = 0; i < palabras.length; i++) {
            if (esColor(palabras[i], colores)) {
                resultado[indice++] = palabras[i];
            }
        }

        // 2. Colocar después las palabras que no son colores
        for (int i = 0; i < palabras.length; i++) {
            if (!esColor(palabras[i], colores)) {
                resultado[indice++] = palabras[i];
            }
        }

        // Mostrar array resultado
        System.out.println("\nArray resultado:");
        mostrarArray(resultado);
    }

    // Método que comprueba si una palabra es un color
    static boolean esColor(String palabra, String[] colores) {
        for (String color : colores) {
            if (palabra.equals(color)) {
                return true;
            }
        }
        return false;
    }

    // Método para mostrar un array
    static void mostrarArray(String[] array) {
        for (int i = 0; i < array.length; i++) {
            System.out.println(i + ": " + array[i]);
        }
    }
}
