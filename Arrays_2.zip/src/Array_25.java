// función filtraPrimos()
//Recibe un array de enteros
//Devuelve un array de enteros con todos los primos


public class Array_25 {
    public static void main(String[] args) {

        // Array de ejemplo
        int[] numeros = {3, 4, 7, 8, 10, 13, 13, 2};

        // Llamamos a la función filtraPrimos
        int[] resultado = filtraPrimos(numeros);

        // Mostramos el array resultante
        System.out.print("Números primos: ");
        for (int num : resultado) {
            System.out.print(num + " ");
        }
    }

    //Función que recibe un array de enteros y devuelve
    //otro  con los números primos encontrados.
    //Si no hay primos, devuelve un array con -1.
    public static int[] filtraPrimos(int[] array) {

        int contadorPrimos = 0;

        // Contamos cuántos primos hay
        for (int num : array) {
            if (esPrimo(num)) {
                contadorPrimos++;
            }
        }

        // Si no hay primos, devolvemos {-1}
        if (contadorPrimos == 0) {
            return new int[]{-1};
        }

        // Creamos el array con el tamaño exacto
        int[] primos = new int[contadorPrimos];
        int indice = 0;

        // Guardamos los primos en el nuevo array
        for (int num : array) {
            if (esPrimo(num)) {
                primos[indice] = num;
                indice++;
            }
        }
        return primos;
    }

    //Comprueba si un número es primo

    private static boolean esPrimo(int num) {
        if (num <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
