//Pide al usuario el tamaño del array cuadrado
//Rellena el array con números aleatorios entre 18 y 65
//Muestra el array y su diagonal, max, minn y media

import java.util.Random;
import java.util.Scanner;

public class Array_34 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        // Pedir tamaño del array
        System.out.print("Introduce el tamaño del array cuadrado: ");
        int n = sc.nextInt();

        int[][] matriz = new int[n][n];

        // Rellenar la matriz con valores entre 18 y 65
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                matriz[i][j] = random.nextInt(65 - 18 + 1) + 18;
            }
        }

        // Mostrar la matriz
        System.out.println("\nMatriz:");
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("%4d", matriz[i][j]);
            }
            System.out.println();
        }

        // Inicializar valores de la diagonal
        int max = matriz[0][0];
        int min = matriz[0][0];
        int suma = 0;

        System.out.println("\nDiagonal principal:");

        // Recorrido único de la diagonal principal
        for (int i = 0; i < n; i++) {
            int valor = matriz[i][i];
            System.out.print(valor + " ");
            suma += valor;

            if (valor > max) {
                max = valor;
            }
            if (valor < min) {
                min = valor;
            }
        }
        double media = (double) suma / n;

        // Mostrar resultados
        System.out.println("\n\nMáximo: " + max);
        System.out.println("Mínimo: " + min);
        System.out.println("Media: " + media);
    }
}
