// Array 10 x 10 relleno d números entre 200 y 300
// el programa muestra los números de la diagonal...
//max, min y media de la diagonal

import java.util.Random;

public class Arrays_23 {
    public static void main(String[] args) {

        final int FILAS = 10;
        final int COLUMNAS = 10;

        int[][] numeros = new int[FILAS][COLUMNAS];
        Random random = new Random();

        // Rellenar el array con valores aleatorios entre 200 y 300
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                numeros[i][j] = random.nextInt(101) + 200; // 200 a 300
            }
        }

        // Mostrar el array completo
        System.out.println("Array 10x10:");
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.printf("%4d ", numeros[i][j]);
            }
            System.out.println();
        }

        // Variables para la diagonal
        int max = numeros[0][0];
        int min = numeros[0][0];
        int suma = 0;

        System.out.println("\nDiagonal principal:");

        // Recorrer la diagonal principal (i == j)
        for (int i = 0; i < FILAS; i++) {
            int valor = numeros[i][i];
            System.out.print(valor + " ");

            suma += valor;

            if (valor > max) {
                max = valor;
            }

            if (valor < min) {
                min = valor;
            }
        }

        double media = (double) suma / FILAS;

        // Mostrar resultados
        System.out.println("\n\nMáximo: " + max);
        System.out.println("Mínimo: " + min);
        System.out.println("Media: " + media);
    }
}
