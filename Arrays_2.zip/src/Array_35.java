//funcion desplazaMatriz()

public class Array_35 {
    public static void main(String[] args) {
        // Matriz de ejemplo
        int[][] matriz = {
                {4, 5, 6, 7},
                {8, 9, 10, 11},
                {12, 13, 15, 15}
        };
        int desplazamiento = 2;

        System.out.println("Matriz original:");
        mostrarMatriz(matriz);

        // Llamada a la función de desplazamiento
        int[][] matrizDesplazada = desplazarMatriz(matriz, desplazamiento);

        System.out.println("\nMatriz desplazada " + desplazamiento + " posiciones a la derecha:");
        mostrarMatriz(matrizDesplazada);
    }
    public static int[][] desplazarMatriz(int[][] matriz, int desplazamiento) {

        int filas = matriz.length;
        int columnas = matriz[0].length;

        // Ajustamos el desplazamiento si es mayor que el número de columnas
        desplazamiento = desplazamiento % columnas;

        int[][] resultado = new int[filas][columnas];

        // Recorremos la matriz original
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {

                // Calculamos la nueva posición de la columna
                int nuevaColumna = (j + desplazamiento) % columnas;

                // Asignamos el valor en la nueva posición
                resultado[i][nuevaColumna] = matriz[i][j];
            }
        }
        return resultado;
    }

    //Muestra una matriz por pantalla
    public static void mostrarMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
