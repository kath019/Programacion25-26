//se piden 20 números,  introducir en un array de 4 filas por 5 columnas.
// El programa mostrará las sumas parciales de filas y columnas

import java.util.Scanner;

public class Array_37 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Matriz de 4 filas y 5 columnas
        int[][] numeros = new int[4][5];

        // Variables para almacenar sumas
        int[] sumaFilas = new int[4];
        int[] sumaColumnas = new int[5];
        int sumaTotal = 0;

        // Pedir los 20 números al usuario
        System.out.println("Introduce 20 números enteros:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.print("Fila " + i + ", Columna " + j + ": ");
                numeros[i][j] = sc.nextInt();

                // Acumular sumas
                sumaFilas[i] += numeros[i][j];
                sumaColumnas[j] += numeros[i][j];
                sumaTotal += numeros[i][j];
            }
        }
        System.out.println("\nTabla con sumas parciales:\n");

        // Mostrar la matriz con la suma de cada fila
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 5; j++) {
                System.out.printf("%5d", numeros[i][j]);
            }
            // Suma de la fila al final
            System.out.printf(" | %5d%n", sumaFilas[i]);
        }
        // Línea separadora
        System.out.println("-------------------------------------");

        // Mostrar la suma de las columnas
        for (int j = 0; j < 5; j++) {
            System.out.printf("%5d", sumaColumnas[j]);
        }
        // Mostrar la suma total en la esquina inferior derecha
        System.out.printf(" | %5d%n", sumaTotal);
    }
}
