//A partir de un array construido,
// construir otros dos con números pares e impares respectivamente
import java.util.Arrays;
import java.util.Scanner;

public class Arrays_10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int [] t;//tabla para los datos iniciales

        System.out.println("Inserte el número de datos a leer:");
        int n = sc.nextInt();
        //creamos la tabla de tamaño n
        t = new int [n];

        //leemos los valores de la tabla
        for(int i = 0; i <t.length; i++){
            t[i] = sc.nextInt();
        }

        //contamos la cantidad de elementos pares e impares
        int contPar = 0;
        int contImpar = 0;

        //consideramos 0 como un número par
        for(int i = 0; i < t.length; i++){
            if (t[i] % 2 == 0) {//si t es par
                contPar++;
            } else {
                contImpar++;
            }
        }

        //contadp el número de elementos pares e impares,
        //declaramos y creamos las tablas
        int [] par = new int [contPar];//albergará conPar elementos
        int [] impar = new int [contImpar];//almacenará contImpar elementos

        //volvemos a procesar para copiar cada elemento en la tabla adecuada
        contPar = 0;//se usarán estas variables como indices de sus respectivas tablas
        contImpar = 0;

        for (int i = 0; i < t.length; i++) {
            if (t[i] % 2 == 0) {
                par[contPar] = t[i];//asignamos el elemnto, que es par
                contPar++;
            } else {
                impar[contImpar] = t[i];
                contImpar++;
            }
        }
        System.out.println("Tabla par: " + Arrays.toString(par));
        System.out.println("Tabla impar: " + Arrays.toString(impar));
    }
}
