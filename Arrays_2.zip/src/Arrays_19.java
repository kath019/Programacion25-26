//Escribe un programa que rellene un array de 100 elementos
// con números enteros aleatorios comprendidos entre 0 y 500 (ambos incluidos).
// A continuación el programa mostrará el array y
// preguntará si el usuario quiere destacar el máximo o el mínimo.

//uso de Math.random...

import java.util.Scanner;

public class Arrays_19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] numeros = new int[100];

        // 1. Rellenar el array con números aleatorios entre 0 y 500
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = (int)(Math.random() * 501);
        }

        // 2. Mostrar el array original
        mostrarArray(numeros, -1);

        // 3. Preguntar qué quiere destacar el usuario
        System.out.print("\n¿Qué quiere destacar? (1 - mínimo, 2 - máximo): ");
        int opcion = sc.nextInt();

        // 4. Calcular mínimo o máximo
        int destacado = numeros[0];

        for (int i = 1; i < numeros.length; i++) {
            if (opcion == 1 && numeros[i] < destacado) {
                destacado = numeros[i];
            }
            if (opcion == 2 && numeros[i] > destacado) {
                destacado = numeros[i];
            }
        }

        // 5. Mostrar el array destacando el valor elegido
        System.out.println();
        mostrarArray(numeros, destacado);
    }

    // Método para mostrar el array
    // Si "destacado" es -1, no se destaca nada
    static void mostrarArray(int[] array, int destacado) {
        boolean yaDestacado = false;

        for (int i = 0; i < array.length; i++) {

            if (array[i] == destacado && !yaDestacado) {
                System.out.print("**" + array[i] + "** ");
                yaDestacado = true;
            } else {
                System.out.print(array[i] + " ");
            }

            // Salto de línea cada 16 números (solo para estética)
            if ((i + 1) % 16 == 0) {
                System.out.println();
            }
        }
        System.out.println();
    }
}
