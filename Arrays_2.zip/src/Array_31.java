// función arrayDeAleatorios
//devolver un array de números aleatorios en el intervalo [a, b]
// ambos inclusive con el tamaño que indique el parámetro cantidad.

import java.util.Random;

public class Array_31 {
    public static void main(String[] args) {

        int a = 10;
        int b = 30;
        int cantidad = 7;

        // Llamada al método
        int[] resultado = aleatorioDeArray(a, b, cantidad);

        // Mostrar el contenido del array
        System.out.println("Array generado:");
        for (int i = 0; i < resultado.length; i++) {
            System.out.print(resultado[i] + " ");
        }
    }
    public static int[] aleatorioDeArray(int a, int b, int cantidad) {

        // Crear el array con el tamaño indicado
        int[] array = new int[cantidad];

        // Crear el objeto Random
        Random random = new Random();

        // Rellenar el array con números aleatorios
        for (int i = 0; i < array.length; i++) {
            // Genera números entre a y b (inclusive)
            array[i] = random.nextInt(b - a + 1) + a;
        }

        // Devolver el array generado
        return array;
    }
}
