//Array 6 x 10
// números aleatorios entre 0 y 1000
// encontrar la posición del max y min

import java.util.Random;

public class Array_24 {
    public static void main(String[] args) {

        final int FILAS = 6;
        final int COLUMNAS = 10;

        int[][] numeros = new int[FILAS][COLUMNAS];
        Random random = new Random();

        // Rellenar el array con números entre 0 y 1000
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                numeros[i][j] = random.nextInt(1001); // 0 a 1000
            }
        }

        // Mostrar el array
        System.out.println("Array 6x10:");
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {
                System.out.printf("%4d ", numeros[i][j]);
            }
            System.out.println();
        }

        // Inicializar máximo y mínimo
        int max = numeros[0][0];
        int min = numeros[0][0];
        int filaMax = 0, colMax = 0;
        int filaMin = 0, colMin = 0;

        // Recorrer el array para buscar máximo y mínimo
        for (int i = 0; i < FILAS; i++) {
            for (int j = 0; j < COLUMNAS; j++) {

                if (numeros[i][j] > max) {
                    max = numeros[i][j];
                    filaMax = i;
                    colMax = j;
                }
                if (numeros[i][j] < min) {
                    min = numeros[i][j];
                    filaMin = i;
                    colMin = j;
                }
            }
        }
        // Mostrar resultados
        System.out.println("\nMáximo: " + max +
                " (Fila " + filaMax + ", Columna " + colMax + ")");
        System.out.println("Mínimo: " + min +
                " (Fila " + filaMin + ", Columna " + colMin + ")");
    }
}
