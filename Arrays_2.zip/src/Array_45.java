//public static String[] invertir(String cadena)

import java.util.Scanner;

public class Array_45 {
    public static String[] invertir(String cadena) {
        int longitud = cadena.length();
        String[] resultado = new String[longitud];

        // Recorremos la cadena desde el final
        for (int i = 0; i < longitud; i++) {
            // Tomamos el carácter desde el final, lo pasamos a mayúscula
            resultado[i] = String.valueOf(
                    Character.toUpperCase(cadena.charAt(longitud - 1 - i))
            );
        }
        return resultado;
    }

    public static String[] desplazarVocales(String cadena) {
        int longitud = cadena.length();
        String[] resultado = new String[longitud];

        for (int i = 0; i < longitud; i++) {
            char c = cadena.charAt(i);

            switch (c) {
                case 'a':
                    resultado[i] = "e";
                    break;
                case 'e':
                    resultado[i] = "i";
                    break;
                case 'i':
                    resultado[i] = "o";
                    break;
                case 'o':
                    resultado[i] = "u";
                    break;
                case 'u':
                    resultado[i] = "a";
                    break;
                default:
                    // Si no es vocal, se deja igual
                    resultado[i] = String.valueOf(c);
            }
        }

        return resultado;
    }

    public static void mostrarArray(String[] array) {
        System.out.print("[ ");
        for (int i = 0; i < array.length; i++) {
            System.out.print("\"" + array[i] + "\"");
            if (i < array.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println(" ]");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce una cadena: ");
        String cadena = sc.nextLine();

        System.out.println("\nResultado de invertir:");
        String[] invertida = invertir(cadena);
        mostrarArray(invertida);

        System.out.println("\nResultado de desplazar vocales:");
        String[] desplazada = desplazarVocales(cadena);
        mostrarArray(desplazada);
    }
}
