//array bidimensional con tantas filas y columnas como indique el usuario.
// Deberá rellenarse la matriz con números aleatorios entre 14 y 78
//array pares y array impares

import java.util.Random;
import java.util.Scanner;

public class Array_41 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        // Pedir número de filas y columnas
        System.out.print("Introduce el número de filas: ");
        int filas = sc.nextInt();

        System.out.print("Introduce el número de columnas: ");
        int columnas = sc.nextInt();

        // Crear la matriz
        int[][] matriz = new int[filas][columnas];

        // Rellenar la matriz con números aleatorios entre 14 y 78
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz[i][j] = random.nextInt(78 - 14 + 1) + 14;
            }
        }

        // Arrays para pares e impares (tamaño máximo posible)
        int[] pares = new int[filas * columnas];
        int[] impares = new int[filas * columnas];

        int contPares = 0;
        int contImpares = 0;

        // Recorrer la matriz
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {

                // Fila par y columna par
                if (i % 2 == 0 && j % 2 == 0) {
                    pares[contPares++] = matriz[i][j];
                }

                // Fila impar y columna impar
                if (i % 2 != 0 && j % 2 != 0) {
                    impares[contImpares++] = matriz[i][j];
                }
            }
        }

        // Mostrar la matriz
        System.out.println("\nMatriz:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }

        // Mostrar array de pares
        System.out.println("\nPares:");
        mostrarArray(pares, contPares);

        // Mostrar array de impares
        System.out.println("\nImpares:");
        mostrarArray(impares, contImpares);

        // Estadísticas de pares
        if (contPares > 0) {
            System.out.println("\nSuma de pares: " + suma(pares, contPares));
            System.out.println("Media de pares: " + (suma(pares, contPares) / contPares));
            System.out.println("Máximo de pares: " + maximo(pares, contPares));
            System.out.println("Mínimo de pares: " + minimo(pares, contPares));
        }

        // Estadísticas de impares
        if (contImpares > 0) {
            System.out.println("\nSuma de impares: " + suma(impares, contImpares));
            System.out.println("Media de impares: " + (suma(impares, contImpares) / contImpares));
            System.out.println("Máximo de impares: " + maximo(impares, contImpares));
            System.out.println("Mínimo de impares: " + minimo(impares, contImpares));
        }
    }
    public static void mostrarArray(int[] v, int tam) {
        System.out.print("[");
        for (int i = 0; i < tam; i++) {
            System.out.print(v[i]);
            if (i < tam - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    }

    // Método para calcular la suma
    public static int suma(int[] v, int tam) {
        int suma = 0;
        for (int i = 0; i < tam; i++) {
            suma += v[i];
        }
        return suma;
    }
    // Método para calcular el máximo
    public static int maximo(int[] v, int tam) {
        int max = v[0];
        for (int i = 1; i < tam; i++) {
            if (v[i] > max) {
                max = v[i];
            }
        }
        return max;
    }

    // Método para calcular el mínimo
    public static int minimo(int[] v, int tam) {
        int min = v[0];
        for (int i = 1; i < tam; i++) {
            if (v[i] < min) {
                min = v[i];
            }
        }
        return min;
    }
}
