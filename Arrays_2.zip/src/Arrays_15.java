//aplicacion para conocer el poder adquisitivo de personas de un municipio
import java.util.Arrays;
import java.util.Scanner;

public class Arrays_15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Array inicial con tamaño pequeño
        double[] sueldos = new double[5];
        int contador = 0; // Número real de sueldos introducidos
        double sueldo;

        System.out.println("Introduce los sueldos (-1 para terminar):");

        while (true) {
            sueldo = sc.nextDouble();

            // Fin de la entrada de datos
            if (sueldo == -1) {
                break;
            }

            // Si el array está lleno, lo ampliamos
            if (contador == sueldos.length) {
                // Creamos un array nuevo con el doble de tamaño
                sueldos = Arrays.copyOf(sueldos, sueldos.length * 2);
            }

            // Guardamos el sueldo y aumentamos el contador
            sueldos[contador] = sueldo;
            contador++;
        }

        // Si no se introdujeron sueldos
        if (contador == 0) {
            System.out.println("No se han introducido sueldos.");
            return;
        }

        // Ordenamos solo la parte del array que contiene datos
        Arrays.sort(sueldos, 0, contador);

        // Mostrar sueldos en orden decreciente
        System.out.println("\nSueldos ordenados de forma decreciente:");
        for (int i = contador - 1; i >= 0; i--) {
            System.out.println(sueldos[i]);
        }

        // Sueldo mínimo y máximo
        double sueldoMinimo = sueldos[0];
        double sueldoMaximo = sueldos[contador - 1];

        // Calcular la media
        double suma = 0;
        for (int i = 0; i < contador; i++) {
            suma += sueldos[i];
        }
        double media = suma / contador;

        // Mostrar resultados
        System.out.println("\nSueldo máximo: " + sueldoMaximo);
        System.out.println("Sueldo mínimo: " + sueldoMinimo);
        System.out.println("Media de los sueldos: " + media);

    }
}
