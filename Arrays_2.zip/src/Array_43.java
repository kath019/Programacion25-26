//public static boolean esPuntoDeSilla(int x[][], int i, int j)
import java.util.Random;
import java.util.Scanner;

public class Array_43 {
    public static boolean esPuntoDeSilla(int x[][], int i, int j) {
        int valor = x[i][j];

        // Comprobar si es el mínimo de la fila
        for (int col = 0; col < x[i].length; col++) {
            if (x[i][col] < valor) {
                return false;
            }
        }

        // Comprobar si es el máximo de la columna
        for (int fila = 0; fila < x.length; fila++) {
            if (x[fila][j] > valor) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        System.out.print("Introduce número de filas: ");
        int filas = sc.nextInt();

        System.out.print("Introduce número de columnas: ");
        int columnas = sc.nextInt();

        int[][] matriz = new int[filas][columnas];

        // Rellenar la matriz con números aleatorios entre 11 y 1003
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                matriz[i][j] = rand.nextInt(993) + 11;
            }
        }

        // Mostrar matriz
        System.out.println("\nMatriz generada:");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }

        // Buscar puntos de silla
        System.out.println("\nPuntos de silla:");
        boolean hayPunto = false;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (esPuntoDeSilla(matriz, i, j)) {
                    System.out.println("Valor " + matriz[i][j] +
                            " en posición (" + i + ", " + j + ")");
                    hayPunto = true;
                }
            }
        }

        if (!hayPunto) {
            System.out.println("No se encontraron puntos de silla.");
        }
    }
}
