//funcion palabraAhorcado()

import java.util.Scanner;

public class Array_39 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Pedir la palabra a adivinar
        System.out.print("Introduce la palabra a adivinar: ");
        String palabra = sc.nextLine();

        // Crear el resultado parcial con guiones
        String resultado = "";
        for (int i = 0; i < palabra.length(); i++) {
            resultado += "-";
        }

        // Mientras no se haya adivinado la palabra completa
        while (!resultado.equals(palabra)) {

            System.out.println("Resultado actual: " + resultado);
            System.out.print("Introduce una letra: ");
            char letra = sc.next().charAt(0);

            // Actualizar el resultado usando la función
            resultado = palabraAhorcado(palabra, resultado, letra);
        }
        System.out.println("¡Enhorabuena! Has adivinado la palabra: " + palabra);
    }

    //Función que actualiza el resultado parcial del ahorcado
    public static String palabraAhorcado(String cadena_a_adivinar, String resultado_parcial, char letra) {

        String resultado = "";

        // Recorrer la palabra a adivinar
        for (int i = 0; i < cadena_a_adivinar.length(); i++) {

            // Si la letra coincide, se muestra
            if (cadena_a_adivinar.charAt(i) == letra) {
                resultado += letra;
            }
            // Si ya estaba descubierta, se mantiene
            else if (resultado_parcial.charAt(i) != '-') {
                resultado += resultado_parcial.charAt(i);
            }
            // Si no coincide, se deja el guión
            else {
                resultado += "-";
            }
        }

        return resultado;
    }
}
