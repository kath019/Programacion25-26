//funcion corteza()
//extrae en un array los números de la capa externa de un array bidimencional

public class Array_36 {
    public static void main(String[] args) {

        int[][] matriz = {
                {45, 92, 14, 20, 25, 78},
                {35, 72, 24, 45, 42, 60},
                {32, 42, 64, 23, 41, 39},
                {98, 45, 94, 11, 18, 48}
        };

        System.out.println("Matriz original:");
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }

        int[] corteza = corteza(matriz);

        System.out.println("\nCorteza de la matriz:");
        mostrarArray(corteza);
    }
    public static int[] corteza(int[][] n) {

        int filas = n.length;
        int columnas = n[0].length;

        // Número total de elementos de la corteza
        int tam = (columnas * 2) + (filas * 2) - 4;
        int[] resultado = new int[tam];

        int k = 0; // Índice para el array resultado

        // 1. Fila superior (izquierda → derecha)
        for (int j = 0; j < columnas; j++) {
            resultado[k++] = n[0][j];
        }

        // 2. Columna derecha (arriba → abajo, sin esquinas)
        for (int i = 1; i < filas - 1; i++) {
            resultado[k++] = n[i][columnas - 1];
        }

        // 3. Fila inferior (derecha → izquierda)
        for (int j = columnas - 1; j >= 0; j--) {
            resultado[k++] = n[filas - 1][j];
        }

        // 4. Columna izquierda (abajo → arriba, sin esquinas)
        for (int i = filas - 2; i > 0; i--) {
            resultado[k++] = n[i][0];
        }
        return resultado;
    }
    // Método auxiliar para mostrar arrays
    public static void mostrarArray(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }
}
