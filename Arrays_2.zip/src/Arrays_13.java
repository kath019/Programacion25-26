//función con dos arrays, el primero con 6 números de una apuesta
// y la segunda con 6 de la combinación ganadora, la funcion devuelve el número de aciertos
//uso de Arrays.binarySearch(_,_)
import java.util.Arrays;

public class Arrays_13 {
    public static void main(String[] args) {
        int [] combinacionGanadora = {3,13,25,33,41,48};
        int [] apuesta = {3,25,41,45,49};
        System.out.println("Aciertos: " + primitiva(combinacionGanadora, apuesta));
    }

    //devuelve el número de coincidencias
    static int primitiva (int[] apuesta, int [] premiado) {
        int aciertos = 0;//contador de aciertos

        for (int a: apuesta) {//recorremos la tabla apuesta
            //aprovechamos que la tabla con la combinación está ordenada
            if (Arrays.binarySearch(premiado, a) >= 0) {
                //si está en la tabla hemos acertado un numero más
                aciertos++;
            }
        }
        return (aciertos);
    }
}
