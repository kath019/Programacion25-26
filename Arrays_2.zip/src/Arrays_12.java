//tabla bidimensional 5 x 5 en la que [n,m] sea n+m

public class Arrays_12 {
    public static void main(String[] args) {
        //declaramos la tabla bidimensional
        int [] [] t;
        t = new int [5][5];//creamos la tabla de 5 x 5
        for (int i = 0; i < 5; i++) {//i para la primera dimensión
            for(int j = 0; j < 5; j++) {//j para la segunda dimension
                t[i][j] = i+j;
            }
        }
        System.out.println("Tabla: ");
        for (int i = 4; i >= 0; i--) {//mostramos las filas al reves, como las matrices
            System.out.println();
            for (int j = 0; j < 5; j++) {
                System.out.print(t[i][j] + " ");
            }
        }

    }
}
