//tablero de ajedrez,a qué casillas
// podría moverse el alfil que está en d5.

import java.util.Scanner;

public class Arrays_22 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Array con las columnas del tablero
        char[] columnas = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};

        System.out.print("Introduzca la posición del alfil: ");
        String posicion = sc.nextLine().toLowerCase();

        // Separar columna y fila
        char col = posicion.charAt(0);
        int fila = Character.getNumericValue(posicion.charAt(1));

        // Obtener índice de la columna
        int colIndex = 0;
        for (int i = 0; i < columnas.length; i++) {
            if (columnas[i] == col) {
                colIndex = i;
                break;
            }
        }

        System.out.print("\nEl alfil puede moverse a las siguientes posiciones: ");

        // Diagonal arriba-derecha
        mover(colIndex, fila, 1, 1, columnas);

        // Diagonal arriba-izquierda
        mover(colIndex, fila, -1, 1, columnas);

        // Diagonal abajo-derecha
        mover(colIndex, fila, 1, -1, columnas);

        // Diagonal abajo-izquierda
        mover(colIndex, fila, -1, -1, columnas);
    }

    //Muestra los movimientos del alfil en una dirección diagonal
    public static void mover(int col, int fila, int incCol, int incFila, char[] columnas) {

        int nuevaCol = col + incCol;
        int nuevaFila = fila + incFila;

        // Mientras esté dentro del tablero
        while (nuevaCol >= 0 && nuevaCol < 8 && nuevaFila >= 1 && nuevaFila <= 8) {
            System.out.print(columnas[nuevaCol] + "" + nuevaFila + " ");
            nuevaCol += incCol;
            nuevaFila += incFila;
        }
    }
}
