//Juego del buscaminas

import java.util.Random;
import java.util.Scanner;

public class Array_28 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        // Solicitar dimensión del tablero
        System.out.print("Introduce la dimensión N del tablero: ");
        int n = sc.nextInt();

        // Crear tablero NxN
        char[][] tablero = new char[n][n];

        // Rellenar tablero aleatoriamente con bombas (X) o vacío (-)
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                // 30% de probabilidad de bomba
                if (random.nextInt(100) < 30) {
                    tablero[i][j] = 'X';
                } else {
                    tablero[i][j] = '-';
                }
            }
        }
        boolean juegoActivo = true;

        // Bucle principal del juego
        while (juegoActivo) {

            // Mostrar tablero completo
            mostrarTablero(tablero);

            // Solicitar posición al usuario
            System.out.print("Introduce una posición (fila,columna): ");
            String entrada = sc.next();
            String[] partes = entrada.split(",");

            int fila = Integer.parseInt(partes[0]);
            int columna = Integer.parseInt(partes[1]);

            // Comprobar si la posición es una bomba
            if (tablero[fila][columna] == 'X') {
                System.out.println("La posición " + fila + "," + columna + " tiene una bomba. ¡Has perdido!");
                juegoActivo = false;
            } else {
                // Contar bombas alrededor
                int bombas = contarBombas(tablero, fila, columna);
                System.out.println("La posición " + fila + "," + columna +
                        " tiene " + bombas + " bombas en los alrededores");
            }
        }
    }

    //Muestra el tablero por pantalla
    public static void mostrarTablero(char[][] tablero) {
        System.out.println("\nTablero:");
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[i].length; j++) {
                System.out.print(tablero[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    //Cuenta las bombas alrededor de una posición dada
    public static int contarBombas(char[][] tablero, int fila, int columna) {
        int contador = 0;

        // Recorrer las 8 posiciones alrededor
        for (int i = fila - 1; i <= fila + 1; i++) {
            for (int j = columna - 1; j <= columna + 1; j++) {

                // Evitar salirse del tablero
                if (i >= 0 && i < tablero.length &&
                        j >= 0 && j < tablero[0].length) {

                    // Evitar contar la posición central
                    if (!(i == fila && j == columna)) {
                        if (tablero[i][j] == 'X') {
                            contador++;
                        }
                    }
                }
            }
        }
        return contador;
    }
}
