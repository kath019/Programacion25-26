//función rellenaPares() a la que se le pasa una tabla
import java.util.Arrays;
import java.util.Scanner;


public class Arrays_14 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int [] t = {2,5,5-3,0};
        int ignorados = rellenaPares(t);
        System.out.println("El número de impares ignorados es de: " + ignorados);
        System.out.println(Arrays.toString(t));
    }

    //los pares los guarda e ignora los impares
    static int rellenaPares(int[] pares) {
        Scanner sc = new Scanner(System.in);

        int i = 0; //indica con que elemento de la tabla estamos
        int imparesIgnorados = 0;

        //terminamos de rellenar la tabla cuando
        // el número de pares sea igual que el tamaño de la tabla
        while(i < pares.length) {
            System.out.println("Introduzca número: ");
            int num = sc.nextInt();
            if (num % 2 == 0) { //si es par
                pares[i] = num; //lo guardamos
                i++; //incrementar el indicador
            } else {
                imparesIgnorados++;
            }
        }
        return imparesIgnorados;
    }
}
