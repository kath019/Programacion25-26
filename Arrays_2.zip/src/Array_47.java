//función matrizLetras
public class Array_47 {
    public static char[][] matrizLetras(String texto) {
        // 1. Eliminar los espacios de la cadena
        String sinEspacios = texto.replace(" ", "");

        // 2. Calcular cuántas filas necesita la matriz
        int columnas = 5;
        int filas = (int) Math.ceil((double) sinEspacios.length() / columnas);

        // 3. Crear la matriz
        char[][] matriz = new char[filas][columnas];

        // 4. Llenar la matriz con los caracteres
        int indice = 0;

        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (indice < sinEspacios.length()) {
                    matriz[i][j] = sinEspacios.charAt(indice);
                    indice++;
                } else {
                    // Si no hay más letras, se deja vacío
                    matriz[i][j] = ' ';
                }
            }
        }
        return matriz;
    }

    public static void main(String[] args) {
        String frase = "Hola que tal estás hoy martes?";

        // Llamamos a la función
        char[][] resultado = matrizLetras(frase);

        // Mostramos la matriz por pantalla
        for (int i = 0; i < resultado.length; i++) {
            for (int j = 0; j < resultado[i].length; j++) {
                System.out.print(resultado[i][j] + " ");
            }
            System.out.println();
        }
    }
}
