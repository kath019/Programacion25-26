//juego africano wari
//El jugador elige uno de sus hoyos
//Toma todas las piedras y las reparte una por una en
// los hoyos siguientes (en sentido antihorario)
//No se salta ningún hoyo
import java.util.Scanner;

public class Arrays_18 {
    // 12 hoyos, 0–5 jugador 1, 6–11 jugador 2
    static int[] tablero = new int[12];
    static int capturasJ1 = 0;
    static int capturasJ2 = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Inicializar tablero con 4 piedras por hoyo
        for (int i = 0; i < 12; i++) {
            tablero[i] = 4;
        }

        int jugador = 1;

        while (true) {
            mostrarTablero();

            if (!puedeJugar(jugador)) {
                System.out.println("El jugador " + jugador + " no puede jugar.");
                break;
            }

            System.out.print("Jugador " + jugador + ", elige un hoyo (1-6): ");
            int hoyo = sc.nextInt() - 1;

            // Ajustar índice según jugador
            if (jugador == 2) {
                hoyo += 6;
            }

            // Validaciones
            if (!hoyoValido(jugador, hoyo)) {
                System.out.println("Hoyo inválido, intenta otra vez.");
                continue;
            }

            jugarTurno(jugador, hoyo);

            // Cambiar jugador
            jugador = (jugador == 1) ? 2 : 1;
        }

        // Mostrar resultado final
        System.out.println("\nJuego terminado");
        System.out.println("Capturas Jugador 1: " + capturasJ1);
        System.out.println("Capturas Jugador 2: " + capturasJ2);

        if (capturasJ1 > capturasJ2)
            System.out.println("Gana el Jugador 1");
        else if (capturasJ2 > capturasJ1)
            System.out.println("Gana el Jugador 2");
        else
            System.out.println("Empate");

        sc.close();
    }

    // Realiza un turno completo
    static void jugarTurno(int jugador, int hoyo) {
        int piedras = tablero[hoyo];
        tablero[hoyo] = 0;

        int posicion = hoyo;

        // Siembra
        while (piedras > 0) {
            posicion = (posicion + 1) % 12;
            tablero[posicion]++;
            piedras--;
        }

        // Capturas
        while (esHoyoRival(jugador, posicion) &&
                (tablero[posicion] == 2 || tablero[posicion] == 3)) {

            if (jugador == 1)
                capturasJ1 += tablero[posicion];
            else
                capturasJ2 += tablero[posicion];

            tablero[posicion] = 0;
            posicion = (posicion - 1 + 12) % 12;
        }
    }

    // Verifica si el hoyo pertenece al rival
    static boolean esHoyoRival(int jugador, int pos) {
        return (jugador == 1 && pos >= 6) ||
                (jugador == 2 && pos < 6);
    }

    // Verifica si el jugador puede jugar
    static boolean puedeJugar(int jugador) {
        int inicio = (jugador == 1) ? 0 : 6;
        int fin = inicio + 6;

        for (int i = inicio; i < fin; i++) {
            if (tablero[i] > 0)
                return true;
        }
        return false;
    }

    // Valida el hoyo elegido
    static boolean hoyoValido(int jugador, int hoyo) {
        if (jugador == 1 && (hoyo < 0 || hoyo > 5)) return false;
        if (jugador == 2 && (hoyo < 6 || hoyo > 11)) return false;
        return tablero[hoyo] > 0;
    }

    // Muestra el tablero en consola
    static void mostrarTablero() {
        System.out.println("\nTablero:");
        System.out.print("J2: ");
        for (int i = 11; i >= 6; i--) {
            System.out.print(tablero[i] + " ");
        }
        System.out.println();
        System.out.print("J1: ");
        for (int i = 0; i < 6; i++) {
            System.out.print(tablero[i] + " ");
        }
        System.out.println("\n");
    }
}
