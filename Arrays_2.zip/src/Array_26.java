//función convierteEnMorse(int n)
//Sin imprimir nada dentro de la función

public class Array_26 {
    public static void main(String[] args) {

        int numero = 213;

        // Llamamos a la función y mostramos el resultado
        String morse = convierteEnMorse(numero);
        System.out.println("Número en Morse: " + morse);
    }

    //Convierte un número entero al sistema Morse y lo devuelve
    //como una cadena de caracteres.
    public static String convierteEnMorse(int n) {

        String[] morse = {
                "-----", ".----", "..---", "...--", "....-",
                ".....", "-....", "--...", "---..", "----."
        };

        String resultado = "";
        String numeroStr = String.valueOf(n);

        for (int i = 0; i < numeroStr.length(); i++) {
            int digito = numeroStr.charAt(i) - '0';
            resultado += morse[digito];

            // Solo añadimos espacio si NO es el último dígito
            if (i < numeroStr.length() - 1) {
                resultado += " ";
            }
        }
        return resultado;
    }
}
