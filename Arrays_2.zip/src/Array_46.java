// public static String convierteEnPalabras(int n)
import java.util.Scanner;

public class Array_46 {
    public static String convierteEnPalabras(int n) {

        // Array con las palabras de los dígitos
        String[] palabras = {
                "cero", "uno", "dos", "tres", "cuatro",
                "cinco", "seis", "siete", "ocho", "nueve"
        };

        String numero = String.valueOf(n);
        String resultado = "";

        // Recorremos cada carácter del número
        for (int i = 0; i < numero.length(); i++) {
            int digito = Character.getNumericValue(numero.charAt(i));

            resultado += palabras[digito];

            // Añadir coma y espacio excepto al final
            if (i < numero.length() - 1) {
                resultado += ", ";
            }
        }
        return resultado;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce un número entero: ");
        int numero = sc.nextInt();

        // Llamada a la función (la función no imprime nada)
        String resultado = convierteEnPalabras(numero);

        // Mostrar el resultado SOLO desde el main
        System.out.println("Número en palabras:");
        System.out.println(resultado);
    }
}
