//Realiza un programa que genere 10 números aleatorios entre 12 y 89
// y que los almacene en un array. A continuación, se mostrará el contenido
// del array junto al índice (0 – 9) utilizando para ello otro array adicional

import java.util.Random;

public class Array_44 {
    public static int[] reordenarParesPrimero(int[] original) {
        int[] nuevo = new int[original.length];
        int indice = 0;

        // Añadir pares
        for (int num : original) {
            if (num % 2 == 0) {
                nuevo[indice++] = num;
            }
        }

        // Añadir impares
        for (int num : original) {
            if (num % 2 != 0) {
                nuevo[indice++] = num;
            }
        }
        return nuevo;
    }

    /**
     * Muestra el array junto con sus índices.
     */
    public static void mostrarArrayConIndice(int[] array) {
        // Índices
        for (int i = 0; i < array.length; i++) {
            System.out.print(i + "\t");
        }
        System.out.println();

        // Valores
        for (int num : array) {
            System.out.print(num + "\t");
        }
        System.out.println("\n");
    }

    public static void main(String[] args) {
        Random rand = new Random();
        int[] array = new int[10];

        // Generar números aleatorios entre 12 y 89
        for (int i = 0; i < array.length; i++) {
            array[i] = rand.nextInt(78) + 12;
        }

        System.out.println("Array original:");
        mostrarArrayConIndice(array);

        int[] arrayNuevo = reordenarParesPrimero(array);

        System.out.println("Array reordenado:");
        mostrarArrayConIndice(arrayNuevo);
    }
}
