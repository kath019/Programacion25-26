//tabla bidimencional de un mapa
//lugar0 → lugar2 → lugar1 → lugar3
//           ↓
//        lugar0
//funcion iterativa
import java.util.Scanner;

public class Arrays_17 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        // Número de lugares
        System.out.print("Ingrese el número de lugares: ");
        int n = sc.nextInt();

        // Matriz mapa
        // mapa[i][j] = true si hay paso de i a j
        boolean[][] mapa = new boolean[n][n];

        // Cargar los pasos
        System.out.println("Ingrese los pasos (i j).");
        System.out.println("Ingrese -1 -1 para terminar:");

        while (true) {
            int i = sc.nextInt();
            int j = sc.nextInt();

            if (i == -1 && j == -1) {
                break;
            }

            mapa[i][j] = true;
        }

        // Solicitar origen y destino
        System.out.print("Lugar de origen: ");
        int origen = sc.nextInt();

        System.out.print("Lugar de destino: ");
        int destino = sc.nextInt();

        // Array para marcar lugares visitados
        boolean[] visitado = new boolean[n];

        // Pila implementada con array
        int[] pila = new int[n];
        int tope = 0;

        // Apilar el origen
        pila[tope++] = origen;
        visitado[origen] = true;

        boolean encontrado = false;

        // Búsqueda en profundidad iterativa
        while (tope > 0 && !encontrado) {

            // Desapilar
            int actual = pila[--tope];

            // Si llegamos al destino
            if (actual == destino) {
                encontrado = true;
            } else {
                // Explorar vecinos
                for (int i = 0; i < n; i++) {
                    if (mapa[actual][i] && !visitado[i]) {
                        pila[tope++] = i;
                        visitado[i] = true;
                    }
                }
            }
        }

        // Resultado
        if (encontrado) {
            System.out.println("Existe un camino entre los lugares.");
        } else {
            System.out.println("NO existe un camino entre los lugares.");
        }
    }
}
