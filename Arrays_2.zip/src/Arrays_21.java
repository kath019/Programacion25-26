//Un restaurante nos ha encargado una aplicación para colocar a los clientes en sus mesas.
// En una mesa se pueden sentar de 0 (mesa vacía) a 4 comensales(mesa llena).
//Asumimos que son 10 mesas

import java.util.Random;
import java.util.Scanner;

public class Arrays_21 {
    public static void main(String[] args) {

        final int NUM_MESAS = 10;
        final int CAPACIDAD_MESA = 4;

        int[] mesas = new int[NUM_MESAS];
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        // Cargar ocupación inicial aleatoria (0 a 4)
        for (int i = 0; i < NUM_MESAS; i++) {
            mesas[i] = random.nextInt(CAPACIDAD_MESA + 1);
        }

        int grupo;

        do {
            mostrarMesas(mesas);

            System.out.print("\n¿Cuántos son? (Introduzca -1 para salir del programa): ");
            grupo = sc.nextInt();

            if (grupo == -1) {
                System.out.println("Gracias. Hasta pronto.");
                break;
            }

            // No se admiten grupos mayores de 4
            if (grupo > CAPACIDAD_MESA || grupo <= 0) {
                System.out.println("Lo siento, no admitimos grupos de " + grupo +
                        ", haga grupos de 4 personas como máximo e intente de nuevo.");
                continue;
            }

            boolean sentados = false;

            // 1️. Buscar mesa vacía
            for (int i = 0; i < NUM_MESAS; i++) {
                if (mesas[i] == 0) {
                    mesas[i] = grupo;
                    System.out.println("Por favor, siéntense en la mesa número " + (i + 1) + ".");
                    sentados = true;
                    break;
                }
            }

            // 2️. Si no hay mesa vacía, buscar hueco suficiente
            if (!sentados) {
                for (int i = 0; i < NUM_MESAS; i++) {
                    if (mesas[i] + grupo <= CAPACIDAD_MESA) {
                        mesas[i] += grupo;
                        System.out.println("Tendrán que compartir mesa. Por favor, siéntense en la mesa número " + (i + 1) + ".");
                        sentados = true;
                        break;
                    }
                }
            }

            // 3️. Si no hay sitio
            if (!sentados) {
                System.out.println("Lo siento, en estos momentos no queda sitio.");
            }

        } while (true);
    }

    // Muestra el estado actual de las mesas
    public static void mostrarMesas(int[] mesas) {
        System.out.println("\nMesa nº   | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |");
        System.out.print("Ocupación |");

        for (int ocupacion : mesas) {
            System.out.print(" " + ocupacion + " |");
        }
        System.out.println();
    }
}
