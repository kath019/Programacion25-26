// tres arrays de 20 números enteros: numero, cuadrado y cubo
//

import java.util.Random;

public class Array_33 {
    public static void main(String[] args) {
        // Tamaño de los arrays
        final int TAM = 20;

        // Declaración de arrays
        int[] numero = new int[TAM];
        int[] cuadrado = new int[TAM];
        int[] cubo = new int[TAM];

        Random random = new Random();

        // Rellenar los arrays
        for (int i = 0; i < TAM; i++) {
            numero[i] = random.nextInt(101); // números entre 0 y 100
            cuadrado[i] = numero[i] * numero[i];
            cubo[i] = numero[i] * numero[i] * numero[i];
        }

        // Mostrar resultados en tres columnas
        System.out.println("Numero  Cuadrado  Cubo");
        System.out.println("----------------------");

        for (int i = 0; i < TAM; i++) {
            System.out.printf("%6d %9d %7d%n", numero[i], cuadrado[i], cubo[i]);
        }
    }
}
