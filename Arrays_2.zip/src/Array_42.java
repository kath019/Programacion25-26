//funcion insertarFilaenMatriz()

public class Array_42 {
    public static void main(String[] args) {

        // Matriz original
        String[][] matriz = {
                {"a", "b", "c"},
                {"d", "e", "f"},
                {"g", "h", "i"}
        };

        // Fila a insertar
        String[] fila = {"j", "k", "l"};

        // Posición donde se insertará la fila
        int pos = 1;

        // Mostrar matriz original
        System.out.println("Matriz original:");
        mostrarMatriz(matriz);

        // Insertar la fila
        String[][] resultado = insertarFilaEnMatriz(matriz, fila, pos);

        // Mostrar matriz resultante
        System.out.println("\nMatriz después de insertar la fila:");
        mostrarMatriz(resultado);
    }
    public static String[][] insertarFilaEnMatriz(String[][] matriz, String[] fila, int pos) {

        int filas = matriz.length;
        int columnas = matriz[0].length;

        // Nueva matriz con una fila más
        String[][] nuevaMatriz = new String[filas + 1][columnas];

        int indice = 0;

        // Copiar filas antes de la posición
        for (int i = 0; i < pos; i++) {
            nuevaMatriz[indice++] = matriz[i];
        }

        // Insertar la nueva fila
        nuevaMatriz[indice++] = fila;

        // Copiar el resto de filas
        for (int i = pos; i < filas; i++) {
            nuevaMatriz[indice++] = matriz[i];
        }
        return nuevaMatriz;
    }

    //Muestra una matriz por pantalla
    public static void mostrarMatriz(String[][] matriz) {
        System.out.println("{");
        for (int i = 0; i < matriz.length; i++) {
            System.out.print("  { ");
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print("\"" + matriz[i][j] + "\"");
                if (j < matriz[i].length - 1) {
                    System.out.print(", ");
                }
            }
            System.out.println(" }");
        }
        System.out.println("}");
    }

}
