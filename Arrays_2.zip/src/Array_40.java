//funcion insertarVector()
public class Array_40 {
    public static void main(String[] args) {

        // Ejemplo 1
        int[] v1 = {1, 2, 3, 4, 5, 6};
        int[] v2 = {4, 9, 12, 5, 7};
        int pos = 2;

        int[] resultado1 = insertarEnVector(v1, v2, pos);

        System.out.println("Resultado Ejemplo 1:");
        mostrarVector(resultado1);

        // Ejemplo 2
        int[] v3 = {6, 12, 8, 9, 3, 13};
        int[] v4 = {13, 11, 4, 8, 6, 1};
        int pos2 = -1;

        int[] resultado2 = insertarEnVector(v3, v4, pos2);

        System.out.println("\nResultado Ejemplo 2:");
        mostrarVector(resultado2);
    }

    //Muestra un vector por pantalla
    public static void mostrarVector(int[] v) {
        System.out.print("{");
        for (int i = 0; i < v.length; i++) {
            System.out.print(v[i]);
            if (i < v.length - 1) {
                System.out.print(", ");
            }
        }
        System.out.println("}");
    }
    public static int[] insertarEnVector(int[] v1, int[] v2, int pos) {

        // Si la posición es menor que 0, se devuelve v1 tal cual
        if (pos < 0) {
            return v1;
        }

        // Si la posición es mayor que la longitud de v1,
        // se devuelve v2 tal cual
        if (pos > v1.length) {
            return v2;
        }

        // Si la posición es válida (incluyendo igual a v1.length),
        // se crea un nuevo vector con el tamaño total
        int[] resultado = new int[v1.length + v2.length];

        int indice = 0;

        // Copiamos los elementos de v1 antes de la posición
        for (int i = 0; i < pos; i++) {
            resultado[indice++] = v1[i];
        }

        // Copiamos todos los elementos de v2
        for (int i = 0; i < v2.length; i++) {
            resultado[indice++] = v2[i];
        }

        // Copiamos el resto de v1 después de la posición
        for (int i = pos; i < v1.length; i++) {
            resultado[indice++] = v1[i];
        }
        return resultado;
    }
}
