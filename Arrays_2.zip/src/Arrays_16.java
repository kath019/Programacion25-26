//los diseñadores de una aplicación necesitan obtener los datos ordenados de una tabla...
//a partir de una tabla, crear otra donde
// se almacenen los datos ordenados con los índices de la tabla original
import java.util.Arrays;

public class Arrays_16 {
    public static void main(String[] args) {

        // Array original que NO debe modificarse
        int[] tablaOriginal = {3, 5, 1, 4};

        // Llamamos al método que devuelve el array de índices ordenados
        int[] tablaConIndices = ordenarIndices(tablaOriginal);

        // Mostramos resultados
        System.out.println("Tabla original: " + Arrays.toString(tablaOriginal));
        System.out.println("Tabla con índices: " + Arrays.toString(tablaConIndices));
    }

    //Este método crea un array de índices que indica
     //en qué orden quedarían los elementos del array original
     // sin modificarlo.

    public static int[] ordenarIndices(int[] tabla) {

        int n = tabla.length;

        // Array donde se guardarán los índices
        int[] indices = new int[n];

        // 1. Inicializamos el array de índices
        //    indices = [0, 1, 2, 3, ..., n-1]
        for (int i = 0; i < n; i++) {
            indices[i] = i;
        }

        // 2. Ordenamos el array de índices
        //    comparando los valores del array original
        for (int i = 0; i < n - 1; i++) {
            for (int j = i + 1; j < n; j++) {

                // Si el valor asociado al índice i
                // es mayor que el valor asociado al índice j,
                // intercambiamos los índices
                if (tabla[indices[i]] > tabla[indices[j]]) {

                    int aux = indices[i];
                    indices[i] = indices[j];
                    indices[j] = aux;
                }
            }
        }

        // 3. Devolvemos el array de índices ordenados
        return indices;
    }
}
