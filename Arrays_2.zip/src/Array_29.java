//public int[] filtraCon8(int x[])
//Devuelve un array con todos los números que contienen el 8 (por ej. 8, 28, 782)
//que se encuentren en otro array que se
//pasa como parámetro. El tamaño del array
//que se devuelve será menor o igual al
//que se pasa como parámetro.

public class Array_29 {
    public static void main(String[] args) {
        int[] numeros = {8, 23, 875, 18, 44, 875, 7};
        int[] resultado = filtraCon8(numeros);

        // Mostrar array resultado
        System.out.print("Array resultado: ");
        for (int i = 0; i < resultado.length; i++) {
            System.out.print(resultado[i] + " ");
        }
    }

    //Devuelve un array con los números que contienen el dígito 8
    public static int[] filtraCon8(int [] x) {
        int contador = 0;

        // Primer recorrido: contar cuántos números contienen el 8
        for (int i = 0; i < x.length; i++) {
            if (contiene8(x[i])) {
                contador++;
            }
        }

        // Si no hay ninguno, devolver array con -1
        if (contador == 0) {
            return new int[]{-1};
        }

        // Crear array del tamaño exacto
        int[] resultado = new int[contador];
        int indice = 0;

        // Segundo recorrido: rellenar el array resultado
        for (int i = 0; i < x.length; i++) {
            if (contiene8(x[i])) {
                resultado[indice] = x[i];
                indice++;
            }
        }
        return resultado;
    }

    //Comprueba si un número contiene el dígito 8
    public static boolean contiene8(int numero) {
        numero = Math.abs(numero); // Por si el número es negativo

        while (numero > 0) {
            if (numero % 10 == 8) {
                return true;
            }
            numero /= 10;
        }
        return false;
    }
}
