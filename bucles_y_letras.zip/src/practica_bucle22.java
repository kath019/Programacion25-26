//una flecha
import java.util.Scanner;

public class practica_bucle22 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce la altura (impar y >= 3): ");
        int altura = sc.nextInt();

        // Validación
        if (altura < 3 || altura % 2 == 0) {
            System.out.println("Error: la altura debe ser un número impar mayor o igual a 3.");
        } else {
            int centro = (altura + 1) / 2;
            for (int i = 1; i <= altura; i++) {

                for (int j = 1; j <= altura; j++) {
                    // Parte de la pirámide (punta)
                    if (i <= centro) {
                        if (j >= centro - (i - 1) && j <= centro + (i - 1)) {
                            System.out.print("*");
                        } else {
                            System.out.print(" ");
                        }
                    }
                    // Parte del palo
                    else {
                        if (j == centro) {
                            System.out.print("*");
                        } else {
                            System.out.print(" ");
                        }
                    }
                }
                System.out.println();
            }
        }
    }
}
