 // *   *
 //  * *
 //   *
 //  * *
 // *   *
import java.util.Scanner;

public class practica_bucle21 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la altura de la letra 'X', debe ser impar:");
        int alt = sc.nextInt();
        if ( (alt % 2 == 0) || alt < 3) {
            System.out.println("Error");
        } else {
            for (int i = 1; i <= alt; i++) {

                for (int j = 1; j <= alt; j++) {

                    if (j == i || j == (alt + 1 - i)) {
                        System.out.print("*");
                    } else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}
