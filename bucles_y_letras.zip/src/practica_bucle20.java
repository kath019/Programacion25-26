//*   *
//*   *
//*   *
// ***
import java.util.Scanner;

public class practica_bucle20 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la altura de la letra 'U':");
        int alt = sc.nextInt();

        for (int i = 1; i <= alt; i++) {
            if (i == alt) {

                System.out.print(" ");
                for (int j = 1; j <= 3; j++) {
                    System.out.print("*");
                }
            } else {
                // Laterales
                System.out.println("*   *");
                continue;
            }
        }
    }
}
