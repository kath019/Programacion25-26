//pasar un número a binario
import java.util.Scanner;

public class practica_bucle26 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.print("Introduce un número entero positivo: ");
        long numero = sc.nextLong();

        long binario = 0;
        long posicion = 1;

        while (numero > 0) {
            long resto = numero % 2;
            binario = binario + resto * posicion;
            posicion = posicion * 10;
            numero = numero / 2;
        }

        System.out.println("El número en binario es: " + binario);
    }
}
