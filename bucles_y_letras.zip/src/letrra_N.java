import java.util.Scanner;

public class letrra_N {
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra N (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo
            System.out.print("*");

            // Diagonal central
            for (int j = 1; j < altura - 1; j++) {
                if (j == i) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }

            // Borde derecho
            System.out.print("*");

            System.out.println();
        }
    }
}
