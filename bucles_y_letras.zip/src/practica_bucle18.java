// Piramide hueca con bucle e if
import java.util.Scanner;

public class practica_bucle18 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Introduzca la altura de la pirámide:");
        int alt = sc.nextInt();
        System.out.println("Introduzca el caracter de la pirámide:");
        char caracter = sc.next().charAt(0);

        for (int i = 1; i <= alt; i++) {
            for (int j = 1; j <= (alt - i); j++) {
                System.out.print(" ");
            }
            for (int k= 1; k <= (i * 2) - 1; k++) {
                if (k == 1 || k == (i * 2) - 1 || i == alt ) {
                    System.out.print(caracter);
                } else {
                    System.out.print(" ");
                }
            }
           System.out.println(" ");
        }
    }
}
