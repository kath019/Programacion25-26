import java.util.Scanner;

public class letra_B {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra B (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila del travesaño

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo
            System.out.print("*");

            // Partes internas de la B
            if (i == 0 || i == altura - 1 || i == mitad) {
                // fila superior, inferior o del travesaño → asteriscos llenos a la derecha
                for (int j = 0; j < altura - 2; j++) {
                    System.out.print("*");
                }
            } else {
                // filas intermedias → espacios y asterisco derecho
                for (int j = 0; j < altura - 2; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
