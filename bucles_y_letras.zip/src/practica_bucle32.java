//partir un número en dos según la posición que se introduzca
//contar cantidad de digitos con bucle while
import java.util.Scanner;

public class practica_bucle32 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Pedir número entero positivo
        System.out.print("Por favor, introduzca un número entero positivo: ");
        long numero = sc.nextLong(); // usar long por si el número es grande

        // Pedir posición de corte
        System.out.print("Introduzca la posición a partir de la cual quiere partir el número: ");
        int posicion = sc.nextInt();

        // Calcular el divisor: 10^(donde cortar)
        long divisor = 1;
        long temp = numero;

        // Contamos cuántos dígitos tiene el número
        int digitos = 0;
        while (temp > 0) {
            temp /= 10;
            digitos++;
        }

        // Queremos partir a partir de la posición 'posicion'
        // Las posiciones se cuentan desde 1
        // Entonces necesitamos 10^(digitos - posicion + 1)
        for (int i = 0; i < digitos - posicion + 1; i++) {
            divisor *= 10;
        }

        // Obtener las dos partes
        long parte1 = numero / divisor;
        long parte2 = numero % divisor;

        System.out.println("Los números partidos son el " + parte1 + " y el " + parte2 + ".");
    }
}
