//letra L con bucle e if
import java.util.Scanner;

public class practica_bucle19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese la lomgitud de la letra:");
        int alt =  sc.nextInt();

        for (int i = 1; i <= (alt / 2) + 1; i++) {
            System.out.println(" ");
            for ( int j = 1; j <= i; j++) {
                if ( j == i || i == (alt / 2) + 1 ) {
                    System.out.print("*");
                }
            }
        }

    }
}
