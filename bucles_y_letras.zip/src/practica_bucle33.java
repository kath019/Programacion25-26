//mostrar que números se han introducido y cuales no
import java.util.Scanner;

public class practica_bucle33 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduzca un número entero: ");
        long numero = sc.nextLong();

        // Variables para cada dígito
        boolean cero = false, uno = false, dos = false, tres = false, cuatro = false;
        boolean cinco = false, seis = false, siete = false, ocho = false, nueve = false;

        long temp = numero;
        if (temp == 0) {
            cero = true; // caso especial si el número es 0
        }

        while (temp > 0) {
            int digito = (int)(temp % 10);
            switch (digito) {
                case 0: cero = true; break;
                case 1: uno = true; break;
                case 2: dos = true; break;
                case 3: tres = true; break;
                case 4: cuatro = true; break;
                case 5: cinco = true; break;
                case 6: seis = true; break;
                case 7: siete = true; break;
                case 8: ocho = true; break;
                case 9: nueve = true; break;
            }
            temp /= 10;
        }

        // Mostrar los dígitos que aparecen
        System.out.print("Dígitos que aparecen en el número:");
        if (cero) System.out.print(" 0");
        if (uno) System.out.print(" 1");
        if (dos) System.out.print(" 2");
        if (tres) System.out.print(" 3");
        if (cuatro) System.out.print(" 4");
        if (cinco) System.out.print(" 5");
        if (seis) System.out.print(" 6");
        if (siete) System.out.print(" 7");
        if (ocho) System.out.print(" 8");
        if (nueve) System.out.print(" 9");
        System.out.println();

        // Mostrar los dígitos que no aparecen
        System.out.print("Dígitos que no aparecen:");
        boolean hayNoAparecen = false;
        if (!cero) { System.out.print(" 0"); hayNoAparecen = true; }
        if (!uno) { System.out.print(" 1"); hayNoAparecen = true; }
        if (!dos) { System.out.print(" 2"); hayNoAparecen = true; }
        if (!tres) { System.out.print(" 3"); hayNoAparecen = true; }
        if (!cuatro) { System.out.print(" 4"); hayNoAparecen = true; }
        if (!cinco) { System.out.print(" 5"); hayNoAparecen = true; }
        if (!seis) { System.out.print(" 6"); hayNoAparecen = true; }
        if (!siete) { System.out.print(" 7"); hayNoAparecen = true; }
        if (!ocho) { System.out.print(" 8"); hayNoAparecen = true; }
        if (!nueve) { System.out.print(" 9"); hayNoAparecen = true; }
        System.out.println();
    }
}
