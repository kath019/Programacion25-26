import java.util.Scanner;

public class letra_H {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra H (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila del travesaño central

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo
            System.out.print("*");

            if (i == mitad) {
                // Travesaño central → llenamos todo hasta el borde derecho
                for (int j = 1; j < altura - 1; j++) {
                    System.out.print("*");
                }
            } else {
                // Filas intermedias → espacios entre los bordes
                for (int j = 1; j < altura - 1; j++) {
                    System.out.print(" ");
                }
            }
            // Borde derecho
            System.out.print("*");

            System.out.println();
        }
    }
}
