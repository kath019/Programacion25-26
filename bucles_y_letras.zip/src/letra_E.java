import java.util.Scanner;

public class letra_E {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        do {
            System.out.print("Introduce la altura de la letra E (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila del travesaño central

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo siempre
            System.out.print("*");

            if (i == 0 || i == altura - 1 || i == mitad) {
                // Fila superior, inferior y central → asteriscos hasta la derecha
                for (int j = 0; j < altura - 1; j++) {
                    System.out.print("*");
                }
            } else {
                // Filas intermedias → solo borde izquierdo, el resto espacios
                for (int j = 0; j < altura - 1; j++) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
