import java.util.Scanner;

public class letra_K {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra K (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila central donde se cruzan las diagonales

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo
            System.out.print("*");

            // Espacios antes de la diagonal
            int espacios;
            if (i < mitad) {
                espacios = mitad - i - 1;
                for (int j = 0; j < espacios; j++) {
                    System.out.print(" ");
                }
                System.out.print("*"); // diagonal superior
            } else if (i > mitad) {
                espacios = i - mitad - 1;
                for (int j = 0; j < espacios; j++) {
                    System.out.print(" ");
                }
                System.out.print("*"); // diagonal inferior
            }
            // En la fila central solo queda el borde izquierdo
            System.out.println();
        }
    }
}
