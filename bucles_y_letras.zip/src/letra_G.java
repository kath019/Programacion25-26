import java.util.Scanner;

public class letra_G {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra G (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2;

        for (int i = 0; i < altura; i++) {
            if (i == 0 || i == altura - 1) {
                // Fila superior e inferior llenas
                for (int j = 0; j < altura; j++) {
                    System.out.print("*");
                }
            } else if (i == mitad) {
                // Travesaño interno de la G
                System.out.print("*"); // borde izquierdo
                for (int j = 1; j < altura - 1; j++) {
                    if (j >= mitad) {
                        System.out.print("*"); // travesaño derecho
                    } else {
                        System.out.print(" ");
                    }
                }
                System.out.print("*"); // borde derecho
            } else if (i < mitad) {
                // Filas superiores del medio → solo borde izquierdo
                System.out.print("*");
                for (int j = 1; j < altura; j++) {
                    System.out.print(" ");
                }
            } else {
                // Filas inferiores del medio → borde izquierdo y borde derecho
                System.out.print("*");
                for (int j = 1; j < altura - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            }

            System.out.println();
        }
    }
}
