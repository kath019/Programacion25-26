import java.util.Scanner;

public class ochodeM {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la altura (impar y >= 5): ");
        int altura = sc.nextInt();

        // Validación
        if (altura < 5 || altura % 2 == 0) {
            System.out.println("Error: la altura debe ser impar y mayor o igual a 5.");
        } else {
            int mitad = altura / 2; // fila central

            for (int i = 0; i < altura; i++) {
                for (int j = 0; j < 6; j++) {
                    // Líneas superior, central e inferior llenas
                    if (i == 0 || i == mitad || i == altura - 1) {
                        System.out.print("M");
                    }
                    // Bordes laterales
                    else if (j == 0 || j == 5) {
                        System.out.print("M");
                    }
                    // Interior vacío
                    else {
                        System.out.print(" ");
                    }
                }
                System.out.println();
            }
        }
    }
}
