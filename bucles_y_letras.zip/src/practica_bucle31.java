//división de un número de 6 cifras y ver si las 3 primeras y últimas cifras son primas
//usando /1000 para las tres primeras cifras y %1000 para las tres ultimas
import java.util.Scanner;

public class practica_bucle31 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int numero;
        // Pedir número de 6 cifras
        do {
            System.out.print("Introduce un número de 6 cifras: ");
            numero = sc.nextInt();
        } while (numero < 100000 || numero > 999999); // exacto 6 cifras

        // Obtener las tres primeras cifras
        int primeras = numero / 1000;

        // Obtener las tres últimas cifras
        int ultimas = numero % 1000;

        // --- Comprobar si las tres primeras cifras son primas ---
        boolean esPrimoPrimeras = true;
        if (primeras <= 1) {
            esPrimoPrimeras = false;
        } else {
            for (int i = 2; i <= primeras / 2; i++) {
                if (primeras % i == 0) {
                    esPrimoPrimeras = false;
                    break;
                }
            }
        }

        if (esPrimoPrimeras) {
            System.out.println(primeras + " es un número primo");
        } else {
            System.out.println(primeras + " NO es un número primo");
        }

        // --- Comprobar si las tres últimas cifras son primas ---
        boolean esPrimoUltimas = true;
        if (ultimas <= 1) {
            esPrimoUltimas = false;
        } else {
            for (int i = 2; i <= ultimas / 2; i++) {
                if (ultimas % i == 0) {
                    esPrimoUltimas = false;
                    break;
                }
            }
        }

        if (esPrimoUltimas) {
            System.out.println(ultimas + " es un número primo");
        } else {
            System.out.println(ultimas + " NO es un número primo");
        }
    }
}
