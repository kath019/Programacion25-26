//DNI y letra correspondiente
import java.util.Scanner;

public class practica_bucle23 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el número del DNI: ");
        int dni = sc.nextInt();

        // Tabla de letras
        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";

        // Cálculo del resto
        int resto = dni % 23;

        // Obtener la letra
        char letra = letras.charAt(resto);

        System.out.println("La letra del DNI es: " + letra);
    }
}
