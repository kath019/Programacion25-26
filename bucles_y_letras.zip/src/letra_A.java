import java.util.Scanner;

public class letra_A {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 3
        do {
            System.out.print("Introduce la altura de la letra A (>=3): ");
            altura = sc.nextInt();
        } while (altura < 3);

        int mitad = altura / 2; // fila del travesaño

        for (int i = 0; i < altura; i++) {
            // Espacios iniciales para centrar la A
            for (int j = 0; j < altura - i - 1; j++) {
                System.out.print(" ");
            }

            // Asteriscos y espacios internos
            for (int j = 0; j < 2 * i + 1; j++) {
                // Dibujar el travesaño en la mitad o los bordes de la A
                if (i == mitad || j == 0 || j == 2 * i) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }
}
