//número capicúa con uso de bucle while, % y /
import java.util.Scanner;

public class practica_bucle25 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduzca un número entero positivo: ");
        long numero = sc.nextLong();

        long original = numero;
        long invertido = 0;

        while (numero > 0) {
            long digito = numero % 10;
            invertido = invertido * 10 + digito;
            numero = numero / 10;
        }

        if (original == invertido) {
            System.out.println("El " + original + " es capicúa.");
        } else {
            System.out.println("El " + original + " no es capicúa.");
        }
    }
}
