import java.util.Scanner;

public class letra_S {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra S (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila del travesaño central

        for (int i = 0; i < altura; i++) {
            if (i == 0 || i == altura - 1 || i == mitad) {
                // Fila superior, inferior y central → llenas
                for (int j = 0; j < altura; j++) {
                    System.out.print("*");
                }
            } else if (i < mitad) {
                // Filas entre la superior y la mitad → borde izquierdo
                System.out.print("*");
                for (int j = 1; j < altura; j++) {
                    System.out.print(" ");
                }
            } else {
                // Filas entre la mitad y la inferior → borde derecho
                for (int j = 0; j < altura - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
