//Z Y Z
import java.util.Scanner;

public class practica_bucle35 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int altura;

        // Solicitar altura válida
        do {
            System.out.print("Introduce la altura de la Z: ");
            altura = sc.nextInt();
        } while (altura <= 3 || altura % 2 == 0);

        // Dibujar las dos Z
        for (int i = 0; i < altura; i++) {
            // Dibujar la primera Z
            for (int j = 0; j < altura; j++) {
                if (i == 0 || i == altura - 1) {
                    System.out.print("*"); // fila superior e inferior llena
                } else if (j == altura - 1 - i) {
                    System.out.print("*"); // diagonal
                } else {
                    System.out.print(" ");
                }
            }

            // Separación de 3 espacios
            System.out.print("   ");

            // Dibujar la segunda Z
            for (int j = 0; j < altura; j++) {
                if (i == 0 || i == altura - 1) {
                    System.out.print("*"); // fila superior e inferior llena
                } else if (j == altura - 1 - i) {
                    System.out.print("*"); // diagonal
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println(); // pasar a la siguiente fila
        }
    }
}
