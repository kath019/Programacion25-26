//letras M y Y
import java.util.Scanner;

public class practica_bucle29 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

        int alt;
        // Pedir altura hasta que sea válida (impar y mayor que 3)
        do {
            System.out.print("Introduzca una altura (impar y > 3): ");
            alt = sc.nextInt();
        } while (alt <= 3 || alt % 2 == 0);

        // Dibujar letra M y Y fila por fila
        for (int i = 0; i < alt; i++) {
            // ----- Letra M -----
            for (int j = 0; j < alt; j++) {
                if (j == 0 || j == alt - 1 || (i <= alt / 2 && j == i) || (i <= alt / 2 && j == alt - 1 - i)) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }

            // Separación entre M y Y
            System.out.print("    "); // 4 espacios

            // ----- Letra Y -----
            for (int j = 0; j < alt; j++) {
                if ((i <= alt / 2 && (j == i || j == alt - 1 - i)) || (i > alt / 2 && j == alt / 2)) {
                    System.out.print("*");
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println(); // Saltar a la siguiente fila
        }
    }
}
