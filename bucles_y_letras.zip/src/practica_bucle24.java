//Juego del ahorcado
//.indexOf(___) para recorrer un String y ver si la palabra contiene una variable
import java.util.Scanner;

public class practica_bucle24 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Jugador A indica la palabra secreta:");
        String correcto = sc.nextLine().toLowerCase();
        System.out.println("Pista: La palabra secreta contiene: " + correcto.length() + " letras");

        for (int i = 1; i <= 3; i++){
            System.out.println("Jugador B indica letra: ");
            String intento = sc.nextLine().toLowerCase();
            if (correcto.contains(intento)){
                int posicion = correcto.indexOf(intento) + 1;
                System.out.println("La primera aparicion de la letra '"+ intento +"' está en la posición: "+ posicion);
            } else {
                System.out.println("La letra "+ intento +" no aparece");
            }
        }

        System.out.println("Trata de acertar la palabra:");
        String ultimo = sc.nextLine().toLowerCase();
        if (ultimo.equals(correcto)){
            System.out.println("Acertaste");
        } else {
            System.out.println("Ohhh, fallaste");
        }
    }
}
