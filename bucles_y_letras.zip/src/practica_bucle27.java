//flecha al lado con alt / 2 e if para dividir la parte de arriba y de abajo
import java.util.Scanner;

public class practica_bucle27 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduce la altura de la flecha, debe ser impar o mayor/igual a 3: ");
        int alt = sc.nextInt();

        if (alt % 2 == 0 || alt < 3){
            System.out.println("Error");
        } else {
            int centro = alt / 2;

            for (int i = 1; i <= alt; i++){
                int espacios;

                //parte superior
                if(i <= centro){
                    espacios = centro - i;
                }//parte inferior
                else {
                    espacios = i - centro;
                }
                for (int j = 1; j <= espacios; j++){
                    System.out.print(" ");
                }
                System.out.print("*     *");
                System.out.println();
            }
        }
    }
}
