//decir cuantas vocales hay en una cadena
import java.util.Scanner;

public class practica_bucle34 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce una cadena: ");
        String cad = sc.nextLine();

        int contador = 0;

        // Recorrer cada carácter de la cadena
        for (int i = 0; i < cad.length(); i++) {
            char c = cad.charAt(i);

            // Comprobar si es vocal
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ||
                    c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
                contador++;
            }
        }

        System.out.println("La cantidad de vocales es: " + contador);
    }
}
