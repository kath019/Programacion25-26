//construir un nuevo número saltando las cifras según indique el segundo número introducido.
import java.util.Scanner;

public class practica_bucle30 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int numero;
        int salto;

        // Pedir número positivo
        do {
            System.out.print("Introduzca un número entero positivo: ");
            numero = sc.nextInt();
        } while (numero <= 0);

        // Pedir salto entre 0 y 2
        do {
            System.out.print("Introduzca el salto (0, 1 o 2): ");
            salto = sc.nextInt();
        } while (salto < 0 || salto > 2);

        int numeroOriginal = numero;

        // Primero calculamos la cantidad de dígitos que tiene el número
        int divisor = 1;
        while (divisor <= numero / 10) {
            divisor *= 10;
        }

        int resultado = 0;
        int posicion = 0;

        while (divisor > 0) {
            // Obtener el dígito más significativo
            int digitoActual = numero / divisor;
            numero %= divisor;

            // Aplicar salto
            if (posicion % (salto + 1) == 0) {
                resultado = resultado * 10 + digitoActual;
            }

            // Preparar divisor para el siguiente dígito
            divisor /= 10;
            posicion++;
        }

        System.out.println("Resultado: " + resultado);
    }
}
