import java.util.Scanner;

public class letra_P {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra P (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int mitad = altura / 2; // fila del travesaño superior

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo
            System.out.print("*");

            if (i == 0 || i == mitad) {
                // Fila superior y travesaño → asteriscos hasta borde derecho
                for (int j = 0; j < altura - 2; j++) {
                    System.out.print("*");
                }
            } else if (i < mitad) {
                // Filas entre la superior y la mitad → solo borde derecho
                for (int j = 0; j < altura - 2; j++) {
                    System.out.print(" ");
                }
                System.out.print("*");
            } else {
                // Filas debajo del travesaño → solo borde izquierdo
                for (int j = 0; j < altura - 2; j++) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}

