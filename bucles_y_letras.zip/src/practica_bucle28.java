//el rombo de SAMPLE
//uso de .substring(inicio,fin) para limitar los caracteres
import java.util.Scanner;

public class practica_bucle28 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Leer cadena del usuario
        System.out.print("Introduce una cadena: ");
        String cadena = sc.nextLine();

        // Limitar a 10 caracteres si es más larga
        if (cadena.length() > 10) {
            cadena = cadena.substring(0, 10);
        }

        int longitud = cadena.length();

        // Parte superior del rombo
        for (int i = 0; i < longitud; i++) {
            // Espacios iniciales
            for (int j = 0; j < (longitud - i - 1); j++) {
                System.out.print(" ");
            }

            // Parte izquierda
            for (int j = 0; j <= i; j++) {
                System.out.print(cadena.charAt(j));
            }

            // Parte derecha (espejo)
            for (int j = i - 1; j >= 0; j--) {
                System.out.print(cadena.charAt(j));
            }

            System.out.println(); // salto de línea
        }

        // Parte inferior del rombo
        for (int i = longitud - 2; i >= 0; i--) {
            // Espacios iniciales
            for (int j = 0; j < longitud - i - 1; j++) {
                System.out.print(" ");
            }

            // Parte izquierda
            for (int j = 0; j <= i; j++) {
                System.out.print(cadena.charAt(j));
            }

            // Parte derecha (espejo)
            for (int j = i - 1; j >= 0; j--) {
                System.out.print(cadena.charAt(j));
            }

            System.out.println();
        }
    }
}
