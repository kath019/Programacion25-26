//letra D o cuadrado
import java.util.Scanner;

public class letra_D {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        // Pedir altura mínima 5
        do {
            System.out.print("Introduce la altura de la letra D (>=5): ");
            altura = sc.nextInt();
        } while (altura < 5);

        int anchura = altura - 1; // anchura de la D proporcional a la altura

        for (int i = 0; i < altura; i++) {
            // Borde izquierdo siempre
            System.out.print("*");

            if (i == 0 || i == altura - 1) {
                // Fila superior e inferior: asteriscos hasta el borde derecho
                for (int j = 0; j < anchura; j++) {
                    System.out.print("*");
                }
            } else {
                // Filas intermedias: espacios internos y borde derecho
                for (int j = 0; j < anchura - 1; j++) {
                    System.out.print(" ");
                }
                System.out.print("*"); // borde derecho
            }

            System.out.println();
        }
    }
}
