//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        // Inicializa el fichero de log (IMPORTANTE)
        Logger.iniciarLog();

        try {
            Cliente c1 = new Cliente ("Laura", 20);
            System.out.println(c1.toString());

            Cliente c2 = new Cliente ("Miranda", 7);

            Cliente c3 = new Cliente ("Luis", -9);

        } catch (MenorEdad e) {

            // Código EX002 → menor de edad
            Logger.escribirLog("EX002", e);
            System.out.println("Error: " + e.getMessage());

        } catch (EdadInvalida e) {

            // Código EX001 → edad inválida
            Logger.escribirLog("EX001", e);
            System.out.println("Error: " + e.getMessage());
        }

        // Segundo bloque de pruebas
        try {
            // Este lanzará excepción (edad negativa)
            Cliente c3 = new Cliente("Pedro", -5);

        } catch (EdadInvalida | MenorEdad e) {

            // Se registra el error en el log
            Logger.escribirLog("EX001", e);
            System.out.println("Error: " + e.getMessage());
        }
    }
}