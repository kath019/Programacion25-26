// Crea una excepción propia, y lánzala cuando, en la clase Cliente,
// intente dársele un valor negativo o mayor de 100 al atributo edad.

public class EdadInvalida extends Exception {
    public EdadInvalida(String message) {
        super(message);
    }
}
