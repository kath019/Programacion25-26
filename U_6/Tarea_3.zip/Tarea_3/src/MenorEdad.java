//Además, otra excepción debe lanzarse cuando el cliente
// intente crearse con una edad menor de 18

public class MenorEdad extends RuntimeException {
    public MenorEdad(String message) {
        super(message);
    }
}
