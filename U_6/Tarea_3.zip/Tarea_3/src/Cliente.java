public class Cliente {
    private String nombre;
    private int edad;

    public Cliente(String nombre, int edad) throws EdadInvalida, MenorEdad {
        this.nombre = nombre;
        setEdad(edad);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) throws EdadInvalida, MenorEdad {
        if(edad > 100 || edad < 0) {
            throw new EdadInvalida("Edad no válida");
        }
        if (edad < 18) {
            throw new MenorEdad("Edad menor de 18");
        }
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                '}';
    }
}
