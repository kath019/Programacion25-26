import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Logger {

    // Nombre del fichero de log (se genera una vez por ejecución)
    private static String ficheroLogger;

    // Método que crea el nombre del fichero con fecha y hora
    public static void iniciarLog() {
        // Formato para el nombre del archivo
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");

        // Ejemplo: log_20260408_103015.log
        ficheroLogger = "log_" + LocalDateTime.now().format(formato) + ".log";
    }

    // Método que escribe una línea en el log
    public static void escribirLog(String codigo, Exception e) {

        // try-with-resources → abre y cierra el fichero automáticamente
        try (FileWriter fw = new FileWriter(ficheroLogger, true)) {

            // Formato de fecha para el contenido del log
            DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

            // Obtener fecha actual
            String fecha = LocalDateTime.now().format(formatoFecha);

            // Construir línea de log
            String linea = fecha + " - " + codigo + " - "
                    + e.getClass().getSimpleName() + ": "
                    + e.getMessage() + "\n";

            // Escribir en el fichero
            fw.write(linea);

        } catch (IOException ex) {
            // Error si no se puede escribir en el archivo
            System.out.println("Error al escribir en el log");
        }
    }
}