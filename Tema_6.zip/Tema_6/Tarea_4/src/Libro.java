import java.util.Objects;

//Crear una clase Libro que tenga como atributos un título y un autor.
//caracter inválido como exepción
public class Libro implements Comparable<Libro>{
    private String titulo;
    private String autor;


    public Libro(String titulo, String autor) throws CaracterInvalido{
        for(int i = 0; i < titulo.length(); i++) {
            if(Character.isDigit(titulo.charAt(i))){
                throw new CaracterInvalido("El título no puede contener números");
            }
        }
        for (int i = 0; i < autor.length(); i++){
            if(Character.isDigit(autor.charAt(i))){
                throw new CaracterInvalido("El nombre del autor no puede contener números");
            }
        }
        this.titulo = titulo;
        this.autor = autor;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) throws CaracterInvalido{
        for(int i = 0; i < autor.length(); i++){
            if(Character.isDigit(autor.charAt(i))){
                throw new CaracterInvalido("El autor no puede contener números");
            }
        }
        this.autor = autor;
    }

    @Override
    public String toString() {
        return titulo + ": " + autor ;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Libro libro = (Libro) o;
        return Objects.equals(titulo, libro.titulo) && Objects.equals(autor, libro.autor);
    }
    @Override
    public int hashCode() {
        return Objects.hash(titulo, autor);
    }
    @Override
    public int compareTo(Libro o) {
        return this.titulo.compareTo(o.titulo);
    }

}
