//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        try {
            Libro libro1 = new Libro ("El Quijote", "Cervantes");
            System.out.println("Libro creado correctamente");

            //Libro libro2 = new Libro ("Libro123", "Autor");

            RegistroLibros registro1 = new RegistroLibros(3);
            registro1.addLibro("Harry Potter", "JK Rowling");
            registro1.addLibro("Don Quijote", "Cervantes");
            registro1.addLibro("IT", "King");

            registro1.searchLibro("Harry Potter");

            registro1.cargarRegistroDeFichero("registro.txt");
            registro1.cargarRegistroAfichero("registro.txt");

        } catch (CaracterInvalido e) {
            System.out.println(e.getMessage());
        }

    }
}
