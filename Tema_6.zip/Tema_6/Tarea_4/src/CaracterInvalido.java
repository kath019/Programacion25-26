public class CaracterInvalido extends Exception {
    public CaracterInvalido(String message) {
        super(message);
    }
}
