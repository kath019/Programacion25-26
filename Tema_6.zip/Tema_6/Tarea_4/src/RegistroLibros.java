import java.io.*;

public class RegistroLibros {
    private Libro [] lista;
    private int contLibros;

    public RegistroLibros(int maxLibros) {
        this.lista = new Libro[maxLibros];
        this.contLibros = 0;
    }


    public Libro[] getLista() {
        return lista;
    }

    public void setLista(Libro[] lista) {
        this.lista = lista;
    }

    public int getContLibros() {
        return contLibros;
    }

    public void setContLibros(int contLibros) {
        this.contLibros = contLibros;
    }

//Un método para añadir un libro al registro. A este método habrá
// que pasarle como parámetros el título del libro, y el nombre de su autor.
// Añadirá a la tabla un objeto Libro con esos datos, siempre que
// no supere el tamaño de la tabla. Devolverá true o false
// dependiendo de si ha podido o no realizar la acción.

    public boolean addLibro(String titulo, String autor) {
        // Comprobar si hay espacio
        if (contLibros >= lista.length) {
            return false;
        } else {
            try{
            Libro nuevoL1 = new Libro(titulo, autor);
            lista[contLibros] = nuevoL1;
            contLibros++;

            } catch (CaracterInvalido e) {
                System.out.println(e.getMessage());
            }
            return true;
        }
    }

//Un método que se llame buscaLibro, que reciba un título, y busque
// en la tabla si ese libro está contenido en ella. Devolverá
// true o false dependiendo de si se ha encontrado o no el libro en cuestión.
    public boolean searchLibro(String titulo) {
        for (int i = 0; i < contLibros; i++) {
            if (lista[i].getTitulo().equals(titulo)) {
                return true;
            }
        }
        return false;
    }

    //Un método que se llame cargarRegistroDesdeFichero, que reciba el nombre de un fichero de texto.
    // Este método deberá ir leyendo el fichero en cuestión, y añadiendo cada uno de ellos en la tabla (utilizar el primer método).
    //  Irá guardando libros hasta que el fichero se acabe, o no quepan más libros en la tabla.
    //  En el fichero, cada libro estará en una línea distinta, con el formato:
    //Título: Autor

    public void cargarRegistroDeFichero(String NombreFichero) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(NombreFichero));
            String linea;
            while ((linea = br.readLine()) != null && contLibros < lista.length) {
                String [] partes = linea.split(":");
                String titulo = partes[0];
                String autor = partes[1];
                addLibro(titulo, autor);
            }
            br.close();

        } catch (IOException e) {
            System.out.println("Error al cargar registro de fichero");;
        }
    }

    //Un método cargarRegistroAfichero que reciba el nombre de un fichero, y cargue los libros de la tabla en el fichero de nombre
    // pasado por parámetro con el mismo formato indicado en el punto anterior.

    public void cargarRegistroAfichero(String NombreFichero) {
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(NombreFichero));
            for(int i = 0; i < contLibros; i++){
                bw.write(lista[i].toString());
                bw.newLine();

            }
            bw.close();
        }catch(Exception e){
            System.out.println("Error al cargar registro de fichero");
        }
    }

    //Este método debe estar sobrecargado de tal forma que podamos llamarlo sin pasarle ningún parámetro,
    // y tomará por defecto el nombre de fichero registro.txt
    public void CargarFichero() {
        cargarRegistroDeFichero("registro.txt");
    }

}
