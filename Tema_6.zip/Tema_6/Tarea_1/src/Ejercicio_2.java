//Actividad 2: Diseñar una aplicación que pida al usuario su nombre y edad. Estos datos deben guardarse en el fichero "datos.txt".
// Si este fichero existe, debe borrarse su contenido, y en caso de no existir, debe crearse.

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.Scanner;

public class Ejercicio_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce tu nombre: ");
        String nombre = sc.nextLine();

        System.out.println("Introduce tu edad: ");
        int edad = sc.nextInt();

       try{
           BufferedWriter EscribirFichero = new BufferedWriter(new FileWriter("datos.txt"));
           EscribirFichero.write("Nombre: " + nombre);
           EscribirFichero.newLine();
           EscribirFichero.write("Edad : " + edad);

           EscribirFichero.close();

       } catch(Exception e){
           System.out.println("Error");
       }
    }
}
