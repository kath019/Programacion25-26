import java.io.*;

//Actividad 3: Crear un programa que duplique el conenido de un fichero.
//Duplicaremos el fichero original.txt en uno que se llame copia.txt
public class Ejercicio_3 {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("original.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("copia.txt"));

            String linea;
            while((linea = br.readLine()) != null){
                bw.write(linea);
                bw.newLine();
            }
            br.close();
            bw.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
