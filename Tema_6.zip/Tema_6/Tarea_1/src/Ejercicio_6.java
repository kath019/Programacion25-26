//Actividad 6: Crear una aplicación que permita mostrar el libro de firmas o insertar un nuevo nombre
// (comprobando que no se encuentre repetido). Llamaremos al fichero firmas.txt.

import java.io.*;
import java.util.Scanner;

public class Ejercicio_6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Ver libro de firmas");
        System.out.println("2. Insertar firma");
        int opcion = sc.nextInt();
        sc.nextLine(); // 🔥 limpiar buffer

        if (opcion == 1) {
            try {
                BufferedReader br = new BufferedReader(new FileReader("firmas.txt"));
                String linea;

                while ((linea = br.readLine()) != null) {
                    System.out.println(linea);
                }

                br.close();
            } catch (IOException e) {
                System.out.println("Error al leer archivo");
            }
        }

        if (opcion == 2) {
            System.out.println("Ingrese nueva firma: ");
            String nueva = sc.nextLine();

            try {
                BufferedReader br = new BufferedReader(new FileReader("firmas.txt"));
                String linea;

                while ((linea = br.readLine()) != null) {
                    if (linea.equalsIgnoreCase(nueva)) {
                        System.out.println("Esa firma ya existe");
                        br.close();
                        return; // 🔥 corta el programa
                    }
                }

                br.close();

            } catch (IOException e) {
                System.out.println("Error al comprobar");
            }

            // Solo llega aquí si NO está repetido
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("firmas.txt", true));
                bw.write(nueva);
                bw.newLine();
                bw.close();

                System.out.println("Firma añadida");

            } catch (IOException e) {
                System.out.println("Error al escribir");
            }
        }
    }
}
