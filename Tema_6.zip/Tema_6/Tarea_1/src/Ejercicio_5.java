//Actividad 5: En el archivo numeros.txt disponemos de una serie de números (uno por cada línea).
// Diseñar un programa que procese el fichero y nos muestre el menor y el mayor.
/*convertir un string a int-> num = Integer.parseInt(linea);
obtener lo max -> int max = Integer.MIN_VALUE;
ontener lo min -> int min = Integer.MAX_VALUE;
*/

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Ejercicio_5 {
    public static void main(String[] args) {
        try{
            BufferedReader br = new BufferedReader(new FileReader("numeros.txt"));

            String linea;
            int num;
            int numMin = Integer.MAX_VALUE;
            int numMax = Integer.MIN_VALUE;

            while ((linea = br.readLine()) != null){
                num = Integer.parseInt(linea);
                if(num < numMin) {
                    numMin = num;
                }
                if (num > numMax) {
                    numMax = num;
                }
            }
            System.out.println("Número mínimo: " + numMin);
            System.out.println("Número máximo: " + numMax);
            br.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
