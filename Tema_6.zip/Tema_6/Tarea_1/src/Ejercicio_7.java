//Actividad 7: En LINUX disponemos de un comando "more", al que se le pasa un fichero y lo muestra poco a poco (cada 24 líneas).
// Implementar un programa que funcione de forma similar.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio_7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
            BufferedReader br = new BufferedReader(new FileReader("mostrar24lineas.txt"));
            String linea;
            int contador = 0;

            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
                contador++;

                if (contador == 24) {
                    System.out.println("\n--- Pulsa ENTER para continuar ---");
                    sc.nextLine(); // espera al usuario
                    contador = 0; // reinicia contador
                }
            }

            br.close();

        } catch (IOException e) {
            System.out.println("Error al leer el archivo.");
        }
    }
}
