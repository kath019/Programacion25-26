import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

//Actividad 4: Realizar un programa que lea un fichero de texto llamado carta.txt, tenemos que contar los caracteres,
// las líneas y las palabras. Para facilitar el procesamiento supondremos que
// cada palabra está separada de otra por un único espacio en blanco.
public class Ejercicio_4 {
    public static void main(String[] args) {
        try{
            BufferedReader br = new BufferedReader(new FileReader("carta.txt"));
            String linea;
            int contLineas = 0;
            int contCaracteres = 0;
            int contPalabras = 0;

            while((linea = br.readLine()) != null){
                contLineas++;

                contCaracteres += linea.length();

                String [] palabras = linea.split(" ");
                contPalabras += palabras.length;
            }

            System.out.println("Hay un total de: " + contLineas + " líneas");
            System.out.println("Hay un totoal de: "+ contPalabras + " palabras");
            System.out.println("Hay un total de: " + contCaracteres + " caracteres");
            br.close();

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
