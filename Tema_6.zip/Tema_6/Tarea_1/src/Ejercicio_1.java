//Actividad 1: Realizar un programa que solicite al usuario el nombre de un fichero de texto y muestre su contenido en pantalla.
// Si no se proporciona ningún nombre de fichero, la aplicación utilizará por defecto prueba.txt.

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Ejercicio_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Escribe el nombre de un fichero:");
        String nombre = sc.nextLine();

        if(nombre.isEmpty()) {
            nombre = "prueba.txt";
        }
        try {
            BufferedReader lecturaFichero = new BufferedReader(new FileReader(nombre));
            String linea;
            while ((linea = lecturaFichero.readLine()) != null) {
                System.out.println(linea);
            }
            lecturaFichero.close();
        } catch (IOException e) {
            System.out.println("Error al leer el fichero");
        }
    }
}
