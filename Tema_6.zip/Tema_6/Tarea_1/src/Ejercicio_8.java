//Actividad 8: Disponemos de dos ficheros perso1.txt y perso2.txt con nombres de personas (ambos ordenados).
// Realizar un programa que lea ambos ficheros y que cree un tercer fichero (todos.txt) con todos los nombres ordenados alfabéticamente.

import java.io.*;

public class Ejercicio_8 {
    public static void main(String[] args) {
        try {
            // Abrimos los dos ficheros de entrada (ya ordenados)
            BufferedReader br1 = new BufferedReader(new FileReader("perso1.txt"));
            BufferedReader br2 = new BufferedReader(new FileReader("perso2.txt"));

            // Creamos el fichero de salida
            BufferedWriter bw = new BufferedWriter(new FileWriter("todos.txt"));

            // Leemos la primera línea de cada fichero
            String linea1 = br1.readLine();
            String linea2 = br2.readLine();

            // Mientras ambos ficheros tengan contenido
            while (linea1 != null && linea2 != null) {

                // Comparamos alfabéticamente (sin distinguir mayúsculas)
                if (linea1.compareToIgnoreCase(linea2) <= 0) { // < 0 → linea1 va antes, 0 → linea2 va antes, = 0 → iguales
                    // Escribimos la menor
                    bw.write(linea1);
                    bw.newLine();

                    // Avanzamos en el fichero 1
                    linea1 = br1.readLine();

                } else {
                    // Escribimos la menor (en este caso linea2)
                    bw.write(linea2);
                    bw.newLine();

                    // Avanzamos en el fichero 2
                    linea2 = br2.readLine();
                }
            }

            // Si quedan líneas en el fichero 1, las copiamos
            while (linea1 != null) {
                bw.write(linea1);
                bw.newLine();
                linea1 = br1.readLine();
            }

            // Si quedan líneas en el fichero 2, las copiamos
            while (linea2 != null) {
                bw.write(linea2);
                bw.newLine();
                linea2 = br2.readLine();
            }

            // Cerramos todos los ficheros
            br1.close();
            br2.close();
            bw.close();

            System.out.println("Ficheros combinados correctamente.");

        } catch (IOException e) {
            System.out.println("Error al trabajar con los archivos.");
        }
    }

}
