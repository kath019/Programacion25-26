/*
U6U7 - Examen - 2526 - Inventario militar

El Ministerio de Defensa desea modernizar el sistema de control logístico de varias bases militares mediante una aplicación en Java
que permita gestionar el inventario de material, vehículos, soldados asignados y movimientos entre almacenes.

Cada base militar dispone de distintos almacenes donde se guarda equipamiento.

Información de las clases
Clase Soldado
De cada soldado se desea almacenar:
DNI
Nombre
Apellidos
Edad
Rango (soldado, cabo, sargento, teniente, etc.)
Dos soldados se consideran iguales si tienen el mismo DNI.
El orden natural de los soldados será:
Apellidos ascendente
Nombre ascendente
DNI en caso de empate

Clase Material
De cada material militar se almacenará:
Código del material
Nombre del material
Tipo (arma, comunicación, sanitario, uniforme, munición, herramienta...)
Cantidad disponible
Nivel de prioridad (1 a 5)
Dos materiales serán iguales si tienen el mismo código.
El orden natural de los materiales será por:
Nombre ascendente
Código en caso de empate
Clase Vehiculo

De cada vehículo militar se almacenará:
Matrícula militar
Modelo
Tipo (blindado, camión, jeep, ambulancia, tanque...)
Estado (operativo, reparación, fuera de servicio)
Kilómetros
Dos vehículos serán iguales si tienen la misma matrícula.

Clase Almacen
Cada base dispone de varios almacenes. De cada almacén interesa:
Código del almacén
Nombre
Una colección de materiales sin repetidos y ordenados alfabéticamente
Una colección de vehículos sin repetidos

Clase BaseMilitar
De cada base se almacenará:
Código de base
Nombre de la base
Ubicación
Relación de soldados destinados a la base
Relación de almacenes de la base
La estructura elegida debe permitir acceder directamente a cada almacén usando su código.

Clase principal InventarioMilitar
Será la clase que controle todo el sistema.
Debe almacenar todas las bases militares usando una estructura que permita:
acceso rápido por código de base
mantener las bases ordenadas por código automáticamente
Operaciones obligatorias
Gestión de bases
boolean addBase(BaseMilitar b)

Añade una nueva base.
Devuelve:

true si se inserta correctamente
false si ya existe una base con ese código
boolean removeBase(Integer codigo)
Elimina una base.

Gestión de soldados
boolean addSoldado(Integer codBase, Soldado s)
Añade un soldado a una base concreta.
No se permiten duplicados.

void mostrarSoldados(Integer codBase)
Muestra los soldados ordenados por el orden natural.
void mostrarSoldadosEdad(Integer codBase)
Muestra los soldados ordenados por:
Edad ascendente
Nombre en caso de empate
int cantidadBasesSoldado(String dni)
Devuelve en cuántas bases aparece destinado un soldado.

Gestión de almacenes
boolean addAlmacen(Integer codBase, Almacen a)
Añade un almacén a una base.
boolean addMaterial(Integer codBase, Integer codAlmacen, Material m)
Añade material a un almacén.
boolean removeMaterial(Integer codBase, Integer codAlmacen, Material m)
Elimina material.
void mostrarMateriales(Integer codBase, Integer codAlmacen)
Muestra los materiales ordenados por nombre.
void mostrarMaterialesPrioridad(Integer codBase, Integer codAlmacen)
Muestra los materiales ordenados por:
Prioridad descendente
Nombre ascendente
Material materialMayorCantidad()
Devuelve el material con mayor cantidad entre todas las bases y almacenes.
(Recorriendo toda la estructura manualmente)

Gestión de vehículos
boolean addVehiculo(Integer codBase, Integer codAlmacen, Vehiculo v)
Añade vehículo.
void mostrarVehiculosOperativos()
Muestra todos los vehículos operativos de todas las bases.
Vehiculo vehiculoMasKm()
Devuelve el vehículo con más kilómetros.

Informes generales
void mostrarBases()
Muestra las bases ordenadas por número total de soldados (de mayor a menor).
Solo se mostrará:
código
nombre
ubicación
número de soldados
void mostrarAlmacenesVacios()
Muestra todos los almacenes sin materiales ni vehículos.
Persistencia en fichero binario

Toda la información deberá guardarse en un fichero llamado:
militar.dat
La clase principal deberá incluir:
void guardarDatos()
Guarda toda la estructura completa en fichero binario.
void cargarDatos()
Carga todos los datos desde fichero binario.

Clase Main obligatoria
Crear una clase Main que pruebe todo el sistema.
Debe contener datos codificados en el programa, sin pedir por teclado:
Insertar mínimo:
4 bases militares
8 almacenes en total
15 soldados
20 materiales
10 vehículos

Distribuidos libremente.
 */

// ============================================================
// U6U7 - Examen - 2526 - Inventario militar
// SOLUCIÓN COMPLETA COMENTADA
// ============================================================

import java.io.*;
import java.util.*;

// ============================================================
// MAIN
// ============================================================
public class Main {

    public static void main(String[] args) {

        InventarioMilitar im = new InventarioMilitar();

        // ----------------------------------------------------
        // CREAR BASES
        // ----------------------------------------------------
        im.addBase(new BaseMilitar(101, "Base Sur", "Sevilla"));
        im.addBase(new BaseMilitar(102, "Base Norte", "Burgos"));
        im.addBase(new BaseMilitar(103, "Base Este", "Valencia"));
        im.addBase(new BaseMilitar(104, "Base Centro", "Madrid"));

        // ----------------------------------------------------
        // ALMACENES
        // ----------------------------------------------------
        im.addAlmacen(101, new Almacen(1, "Armas"));
        im.addAlmacen(101, new Almacen(2, "Vehiculos"));

        im.addAlmacen(102, new Almacen(1, "General"));
        im.addAlmacen(102, new Almacen(2, "Blindados"));

        im.addAlmacen(103, new Almacen(1, "Sanitario"));
        im.addAlmacen(103, new Almacen(2, "Municion"));

        im.addAlmacen(104, new Almacen(1, "Central"));
        im.addAlmacen(104, new Almacen(2, "Reserva"));

        // ----------------------------------------------------
        // SOLDADOS
        // ----------------------------------------------------
        im.addSoldado(101,new Soldado("111A","Ana","Lopez",25,"Cabo"));
        im.addSoldado(101,new Soldado("222B","Luis","Perez",30,"Soldado"));

        im.addSoldado(102,new Soldado("333C","Marta","Ruiz",27,"Teniente"));
        im.addSoldado(102,new Soldado("444D","Carlos","Diaz",22,"Soldado"));

        im.addSoldado(103,new Soldado("555E","Lucia","Navarro",29,"Sargento"));
        im.addSoldado(103,new Soldado("666F","Pedro","Garcia",35,"Soldado"));

        im.addSoldado(104,new Soldado("777G","Sara","Martin",26,"Cabo"));
        im.addSoldado(104,new Soldado("888H","David","Santos",32,"Soldado"));

        // ----------------------------------------------------
        // MATERIALES
        // ----------------------------------------------------
        im.addMaterial(101,1,new Material("M01","Fusil","Arma",50,5));
        im.addMaterial(101,1,new Material("M02","Pistola","Arma",30,4));

        im.addMaterial(102,1,new Material("M03","Radio","Comunicacion",10,3));
        im.addMaterial(102,2,new Material("M04","Casco","Proteccion",80,2));

        im.addMaterial(103,1,new Material("M05","Botiquin","Sanitario",40,5));
        im.addMaterial(103,2,new Material("M06","Municion 9mm","Municion",200,5));

        im.addMaterial(104,1,new Material("M07","Uniforme","Ropa",60,1));
        im.addMaterial(104,2,new Material("M08","Linterna","Herramienta",25,2));

        // ----------------------------------------------------
        // VEHICULOS
        // ----------------------------------------------------
        im.addVehiculo(101,2,new Vehiculo("ET111","Jeep A","Jeep","Operativo",12000));
        im.addVehiculo(101,2,new Vehiculo("ET112","Camion B","Camion","Reparacion",50000));

        im.addVehiculo(102,2,new Vehiculo("ET221","Blindado X","Blindado","Operativo",9000));

        im.addVehiculo(103,2,new Vehiculo("ET331","Ambulancia Y","Ambulancia","Operativo",70000));

        im.addVehiculo(104,2,new Vehiculo("ET441","Tanque Z","Tanque","Fuera servicio",30000));

        // ----------------------------------------------------
        // PRUEBAS
        // ----------------------------------------------------
        System.out.println("SOLDADOS BASE 101:");
        im.mostrarSoldados(101);

        System.out.println("\nSOLDADOS BASE 101 POR EDAD:");
        im.mostrarSoldadosEdad(101);

        System.out.println("\nMATERIALES BASE 101 ALMACEN 1:");
        im.mostrarMateriales(101,1);

        System.out.println("\nMATERIALES POR PRIORIDAD:");
        im.mostrarMaterialesPrioridad(101,1);

        System.out.println("\nVEHICULOS OPERATIVOS:");
        im.mostrarVehiculosOperativos();

        System.out.println("\nBASES ORDENADAS POR SOLDADOS:");
        im.mostrarBases();

        System.out.println("\nMATERIAL MAYOR CANTIDAD:");
        System.out.println(im.materialMayorCantidad());

        System.out.println("\nVEHICULO MAS KM:");
        System.out.println(im.vehiculoMasKm());

        // guardar
        im.guardarDatos();
    }
}

// ============================================================
// CLASE INVENTARIO MILITAR
// ============================================================
class InventarioMilitar {

    private TreeMap<Integer, BaseMilitar> bases;

    public InventarioMilitar() {
        bases = new TreeMap<>();
    }

    public boolean addBase(BaseMilitar b) {
        if (bases.containsKey(b.getCodigo()))
            return false;

        bases.put(b.getCodigo(), b);
        return true;
    }

    public boolean removeBase(Integer codigo) {
        return bases.remove(codigo) != null;
    }

    public boolean addSoldado(Integer codBase, Soldado s) {
        BaseMilitar b = bases.get(codBase);
        if (b != null) return b.addSoldado(s);
        return false;
    }

    public void mostrarSoldados(Integer codBase) {
        BaseMilitar b = bases.get(codBase);
        if (b != null) b.mostrarSoldados();
    }

    public void mostrarSoldadosEdad(Integer codBase) {
        BaseMilitar b = bases.get(codBase);
        if (b != null) b.mostrarSoldadosEdad();
    }

    public boolean addAlmacen(Integer codBase, Almacen a) {
        BaseMilitar b = bases.get(codBase);
        if (b != null) return b.addAlmacen(a);
        return false;
    }

    public boolean addMaterial(Integer codBase,Integer codAlmacen,Material m){
        BaseMilitar b = bases.get(codBase);
        if (b != null) return b.addMaterial(codAlmacen,m);
        return false;
    }

    public boolean addVehiculo(Integer codBase,Integer codAlmacen,Vehiculo v){
        BaseMilitar b = bases.get(codBase);
        if (b != null) return b.addVehiculo(codAlmacen,v);
        return false;
    }

    public void mostrarMateriales(Integer codBase,Integer codAlmacen){
        BaseMilitar b = bases.get(codBase);
        if (b != null) b.mostrarMateriales(codAlmacen);
    }

    public void mostrarMaterialesPrioridad(Integer codBase,Integer codAlmacen){
        BaseMilitar b = bases.get(codBase);
        if (b != null) b.mostrarMaterialesPrioridad(codAlmacen);
    }

    public Material materialMayorCantidad(){

        Material max = null;

        for(BaseMilitar b : bases.values()){
            Material aux = b.materialMayorCantidad();

            if(aux != null){
                if(max == null || aux.getCantidad() > max.getCantidad()){
                    max = aux;
                }
            }
        }

        return max;
    }

    public Vehiculo vehiculoMasKm(){

        Vehiculo max = null;

        for(BaseMilitar b : bases.values()){

            Vehiculo aux = b.vehiculoMasKm();

            if(aux != null){
                if(max == null || aux.getKm() > max.getKm()){
                    max = aux;
                }
            }
        }

        return max;
    }

    public void mostrarVehiculosOperativos(){

        for(BaseMilitar b : bases.values()){
            b.mostrarVehiculosOperativos();
        }
    }

    public void mostrarBases(){

        ArrayList<BaseMilitar> lista =
                new ArrayList<>(bases.values());

        Collections.sort(lista,
                (a,b)->b.totalSoldados()-a.totalSoldados());

        for(BaseMilitar x : lista){
            System.out.println(x);
        }
    }

    public void guardarDatos(){

        try{
            ObjectOutputStream out =
                    new ObjectOutputStream(
                            new FileOutputStream("militar.dat"));

            out.writeObject(bases);
            out.close();

        }catch(Exception e){
            System.out.println("Error guardando");
        }
    }

    public void cargarDatos(){

        try{
            ObjectInputStream in =
                    new ObjectInputStream(
                            new FileInputStream("militar.dat"));

            bases = (TreeMap<Integer,BaseMilitar>) in.readObject();
            in.close();

        }catch(Exception e){
            System.out.println("Error cargando");
        }
    }
}

// ============================================================
// BASE MILITAR
// ============================================================
class BaseMilitar implements Serializable {

    private int codigo;
    private String nombre;
    private String ubicacion;

    private TreeSet<Soldado> soldados;
    private TreeMap<Integer,Almacen> almacenes;

    public BaseMilitar(int codigo,String nombre,String ubicacion){

        this.codigo = codigo;
        this.nombre = nombre;
        this.ubicacion = ubicacion;

        soldados = new TreeSet<>();
        almacenes = new TreeMap<>();
    }

    public int getCodigo(){
        return codigo;
    }

    public boolean addSoldado(Soldado s){
        return soldados.add(s);
    }

    public boolean addAlmacen(Almacen a){

        if(almacenes.containsKey(a.getCodigo()))
            return false;

        almacenes.put(a.getCodigo(),a);
        return true;
    }

    public boolean addMaterial(Integer codAlmacen,Material m){

        Almacen a = almacenes.get(codAlmacen);
        if(a != null) return a.addMaterial(m);

        return false;
    }

    public boolean addVehiculo(Integer codAlmacen,Vehiculo v){

        Almacen a = almacenes.get(codAlmacen);
        if(a != null) return a.addVehiculo(v);

        return false;
    }

    public void mostrarSoldados(){

        for(Soldado s : soldados)
            System.out.println(s);
    }

    public void mostrarSoldadosEdad(){

        ArrayList<Soldado> lista =
                new ArrayList<>(soldados);

        Collections.sort(lista,
                (a,b)->{
                    if(a.getEdad()!=b.getEdad())
                        return a.getEdad()-b.getEdad();

                    return a.getNombre().compareToIgnoreCase(b.getNombre());
                });

        for(Soldado s : lista)
            System.out.println(s);
    }

    public void mostrarMateriales(Integer codAlmacen){

        Almacen a = almacenes.get(codAlmacen);
        if(a != null) a.mostrarMateriales();
    }

    public void mostrarMaterialesPrioridad(Integer codAlmacen){

        Almacen a = almacenes.get(codAlmacen);
        if(a != null) a.mostrarMaterialesPrioridad();
    }

    public Material materialMayorCantidad(){

        Material max = null;

        for(Almacen a : almacenes.values()){

            Material aux = a.materialMayorCantidad();

            if(aux != null){
                if(max == null || aux.getCantidad()>max.getCantidad())
                    max = aux;
            }
        }

        return max;
    }

    public Vehiculo vehiculoMasKm(){

        Vehiculo max = null;

        for(Almacen a : almacenes.values()){

            Vehiculo aux = a.vehiculoMasKm();

            if(aux != null){
                if(max == null || aux.getKm()>max.getKm())
                    max = aux;
            }
        }

        return max;
    }

    public void mostrarVehiculosOperativos(){

        for(Almacen a : almacenes.values())
            a.mostrarVehiculosOperativos();
    }

    public int totalSoldados(){
        return soldados.size();
    }

    public String toString(){
        return codigo + " - " + nombre +
                " - " + ubicacion +
                " - Soldados:" + soldados.size();
    }
}

// ============================================================
// ALMACEN
// ============================================================
class Almacen implements Serializable {

    private int codigo;
    private String nombre;

    private TreeSet<Material> materiales;
    private HashSet<Vehiculo> vehiculos;

    public Almacen(int codigo,String nombre){

        this.codigo = codigo;
        this.nombre = nombre;

        materiales = new TreeSet<>();
        vehiculos = new HashSet<>();
    }

    public int getCodigo(){
        return codigo;
    }

    public boolean addMaterial(Material m){
        return materiales.add(m);
    }

    public boolean addVehiculo(Vehiculo v){
        return vehiculos.add(v);
    }

    public void mostrarMateriales(){

        for(Material m : materiales)
            System.out.println(m);
    }

    public void mostrarMaterialesPrioridad(){

        ArrayList<Material> lista =
                new ArrayList<>(materiales);

        Collections.sort(lista,
                (a,b)->{
                    if(a.getPrioridad()!=b.getPrioridad())
                        return b.getPrioridad()-a.getPrioridad();

                    return a.getNombre().compareToIgnoreCase(b.getNombre());
                });

        for(Material m : lista)
            System.out.println(m);
    }

    public Material materialMayorCantidad(){

        Material max = null;

        for(Material m : materiales){

            if(max == null || m.getCantidad()>max.getCantidad())
                max = m;
        }

        return max;
    }

    public Vehiculo vehiculoMasKm(){

        Vehiculo max = null;

        for(Vehiculo v : vehiculos){

            if(max == null || v.getKm()>max.getKm())
                max = v;
        }

        return max;
    }

    public void mostrarVehiculosOperativos(){

        for(Vehiculo v : vehiculos){

            if(v.getEstado().equalsIgnoreCase("Operativo"))
                System.out.println(v);
        }
    }
}

// ============================================================
// SOLDADO
// ============================================================
class Soldado implements Serializable, Comparable<Soldado>{

    private String dni,nombre,apellidos,rango;
    private int edad;

    public Soldado(String dni,String nombre,String apellidos,
                   int edad,String rango){

        this.dni=dni;
        this.nombre=nombre;
        this.apellidos=apellidos;
        this.edad=edad;
        this.rango=rango;
    }

    public int getEdad(){ return edad; }
    public String getNombre(){ return nombre; }

    public int compareTo(Soldado o){

        int r = apellidos.compareToIgnoreCase(o.apellidos);

        if(r==0) r = nombre.compareToIgnoreCase(o.nombre);
        if(r==0) r = dni.compareToIgnoreCase(o.dni);

        return r;
    }

    public boolean equals(Object x){

        if(!(x instanceof Soldado)) return false;

        Soldado s=(Soldado)x;
        return dni.equals(s.dni);
    }

    public int hashCode(){
        return dni.hashCode();
    }

    public String toString(){
        return dni+" "+nombre+" "+apellidos+
                " Edad:"+edad+" "+rango;
    }
}

// ============================================================
// MATERIAL
// ============================================================
class Material implements Serializable, Comparable<Material>{

    private String codigo,nombre,tipo;
    private int cantidad,prioridad;

    public Material(String codigo,String nombre,String tipo,
                    int cantidad,int prioridad){

        this.codigo=codigo;
        this.nombre=nombre;
        this.tipo=tipo;
        this.cantidad=cantidad;
        this.prioridad=prioridad;
    }

    public int getCantidad(){ return cantidad; }
    public int getPrioridad(){ return prioridad; }
    public String getNombre(){ return nombre; }

    public int compareTo(Material o){

        int r = nombre.compareToIgnoreCase(o.nombre);

        if(r==0) r = codigo.compareToIgnoreCase(o.codigo);

        return r;
    }

    public boolean equals(Object x){

        if(!(x instanceof Material)) return false;

        Material m=(Material)x;
        return codigo.equals(m.codigo);
    }

    public int hashCode(){
        return codigo.hashCode();
    }

    public String toString(){
        return codigo+" "+nombre+
                " Cant:"+cantidad+
                " Prioridad:"+prioridad;
    }
}

// ============================================================
// VEHICULO
// ============================================================
class Vehiculo implements Serializable{

    private String matricula,modelo,tipo,estado;
    private int km;

    public Vehiculo(String matricula,String modelo,
                    String tipo,String estado,int km){

        this.matricula=matricula;
        this.modelo=modelo;
        this.tipo=tipo;
        this.estado=estado;
        this.km=km;
    }

    public int getKm(){ return km; }
    public String getEstado(){ return estado; }

    public boolean equals(Object x){

        if(!(x instanceof Vehiculo)) return false;

        Vehiculo v=(Vehiculo)x;
        return matricula.equals(v.matricula);
    }

    public int hashCode(){
        return matricula.hashCode();
    }

    public String toString(){
        return matricula+" "+modelo+
                " "+tipo+
                " "+estado+
                " Km:"+km;
    }
}