//Actividad 3: Crear una colección de 20 números enteros aleatorios
// menores que 10, guardarlos por orden decreciente a medida que
// se vayan generando y mostrar la colección por pantalla.

import java.util.ArrayList;
import java.util.Random;

public class Actividad_3 {
    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList <Integer>();
        Random aleatorio = new Random();

        for (int i = 0; i < 20; i++) {
            int num = aleatorio.nextInt(10);

            int j = 0;
            // Buscar posición correcta(de mayor a menor)
            while(j < lista.size() && lista.get(j) > num){
                j++;
            }
            lista.add(j, num);
        }
        System.out.println("Lista ordenada de forma decreciente: \n" + lista);
    }
}
