//Actividad 2: Repetir el ejercicio anterior, pero ordenar la
// lista en sentido decreciente.

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Actividad_2 {
    public static void main(String[] args) {
        Random aleatorio = new Random();
        ArrayList<Integer> lista = new ArrayList<Integer>();
        for (int i = 0; i < 20; i++) {
            lista.add(aleatorio.nextInt(100));
        }

        // Ordenar de mayor a menor
        Collections.sort(lista,  Collections.reverseOrder());
        System.out.println("Lista ordenada de forma decreciente: \n" + lista);
    }
}
