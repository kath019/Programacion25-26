//Actividad 8: Implementar una función a la que se le pase una lista de nombres y devuelva
// una copia sin elementos repetidos (sin modificar la original), con el prototipo:
//
//List eliminaRepetidos (List c)

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Actividad_8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> lista = new ArrayList(8);
        List<String> lista2 = new ArrayList(8);
        System.out.println("Ingresa 8 nombres:");

        String nombre = " ";
        for ( int i = 0; i < 8; i++) {
            nombre = sc.nextLine();
            lista.add(nombre);
        }
        System.out.println("Lista sin repetidos:");
        System.out.println(eliminaRepetidos(lista));
    }
    public static List eliminaRepetidos(List c){
      List<String> listaNueva = new ArrayList();
        for( int i = 0; i <8; i++){
            if(!(listaNueva.contains(c.get(i)))){
                listaNueva.add((String) c.get(i));
            }
        }
        return  listaNueva;
    }
}
