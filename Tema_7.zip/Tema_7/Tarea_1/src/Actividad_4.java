//Actividad 4: Introducir por consola una frase que conste exclusivamente
//de palabras separadas por espacios. Almacenar en una lista las palabras
// de la frase, una en cada nodo y mostrar por pantalla las palabras
// que estén repetidas. A continuación, mostrar las que no lo estén.

import java.util.ArrayList;
import java.util.Scanner;

public class Actividad_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> lista = new ArrayList<String>();
        ArrayList<String> repetidas = new ArrayList<>();
        ArrayList<String> noRepetidas = new ArrayList<>();

        System.out.println("Introducir una frase:");
        String frase = sc.nextLine();

        //separar por espacios
        String [] palabras = frase.split(" ");
        for(String palabra : palabras){
            lista.add(palabra);
        }

        for(String palabra : palabras){
            int cont = 0;
            for(String p : lista){
                if(p.equals(palabra)){
                    cont++;
                }
            }
            if(cont > 1) {
                if(!repetidas.contains(palabra)){
                    repetidas.add(palabra);
                }
            } else  {
                noRepetidas.add(palabra);
            }
        }
        System.out.println("Repetidas " + repetidas);
        System.out.println("No repetidas " + noRepetidas);
    }

}
