//Actividad 6: Introducir por teclado, hasta que se introduzca "fin", una serie de nombres que se insertarán en una colección,
//de forma que se conserve el orden de inserción y que no puedan repetirse. Mostrar la estructura por pantalla.

import java.util.ArrayList;
import java.util.Scanner;

public class Actividad_6 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<String> lista = new ArrayList();

        System.out.println("Introduzca nombres, para terminar introduzca fin: ");
        String nombres = " ";
        while (!nombres.equals("fin")) {
            nombres = sc.nextLine();
            if(!lista.contains(nombres)){
                if(!nombres.equals("fin")){
                lista.add(nombres);
                }
            }
        }
        System.out.println("Nombres de la lista" + lista);
    }
}
