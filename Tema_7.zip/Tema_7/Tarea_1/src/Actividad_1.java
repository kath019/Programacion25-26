//Actividad 1: Crear una colección de 20 números enteros aleatorios menores que 100, y guardarlos en el orden
// en que se vayan generando; mostrar por pantalla dicha lista una vez creada.
// Ordenarla en sentido creciente y volverla a mostrar por pantalla.

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Actividad_1 {
    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList<>();
        Random aleatorio = new Random();

        for (int i = 0; i < 20; i++) {
        int num = aleatorio.nextInt(100);
        lista.add(num);
        }

        //Ordenar la lista
        Collections.sort(lista);

        System.out.println("Lista ordenada: " + lista);
    }
}
