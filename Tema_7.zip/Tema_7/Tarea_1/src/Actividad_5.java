//Actividad 5: Crear una colección de 20 números enteros aleatorios distintos menores que 100,
// guardarlos por orden decreciente a medida que se vayan generando, y mostrar la colección por pantalla.

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;

public class Actividad_5 {
    public static void main(String[] args) {
        HashSet lista = new HashSet();        //no acepta números repetidos
        ArrayList lOrdenada= new ArrayList();

        while(lista.size() < 20){
            Random aleatorio = new Random();
            int num = aleatorio.nextInt(20);
            lista.add(num);

        }

        lOrdenada = new ArrayList<>(lista);
        Collections.sort(lOrdenada,  Collections.reverseOrder());
        System.out.println("Lista ordenada de forma decreciente: \n" + lOrdenada);
    }
}
