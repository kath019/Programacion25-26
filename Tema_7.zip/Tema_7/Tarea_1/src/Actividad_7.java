//Actividad 7: Introducir por teclado, hasta que se introduzca "fin", una serie de nombres que se insertarán
// por orden alfabético en una colección que no permita repeticiones. Mostrar luego la lista de nombres por pantalla.

import java.util.*;

public class Actividad_7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashSet lista = new HashSet();        //no acepta números repetidos
        ArrayList <String> lOrdenada= new ArrayList();

        System.out.println("Introduzca nombres, para terminar introduzca fin:");
        String nombres = " ";
        while (!nombres.equals("fin")) {
            nombres = sc.nextLine();
            if(!nombres.equals("fin")){
                lista.add(nombres);
            }
        }

        lOrdenada = new ArrayList<>(lista);
        Collections.sort(lOrdenada);
        System.out.println("Lista ordenada de forma decreciente: \n" + lOrdenada);
    }
}
