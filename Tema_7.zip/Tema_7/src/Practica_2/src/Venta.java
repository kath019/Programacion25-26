//Crea una clase Venta con producto (String), categoria (String, ej: "Electrónica", "Ropa", "Alimentos") y precio (double).


public class Venta {
    private String producto;
    private String categoria;
    private double precio;

    public Venta(String producto, String categoria, double precio) {
        this.producto = producto;
        this.categoria = categoria;
        this.precio = precio;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
}
