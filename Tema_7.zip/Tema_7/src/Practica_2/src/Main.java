// Lo que debes programar: Llena un ArrayList con unas 15 ventas aleatorias repartidas en esas tres categorías.
// Su misión es calcular y mostrar por pantalla cuánto dinero se recaudó por cada categoría.
// Tiene que recorrer la lista y sumar los precios agrupándolos por su categoría correspondiente.
// Mostrar al final algo como: "Total Electrónica: $500. Total Ropa: $120...".

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Venta venta1 = new Venta("ry", "Electrónica", 50);
        Venta venta2 = new Venta("vc", "Electrónica", 60);
        Venta venta3 = new Venta("dg", "Electrónica", 70);
        Venta venta4 = new Venta("za", "Ropa", 23);
        Venta venta5 = new Venta("ca", "Ropa", 24);
        Venta venta6 = new Venta("mi", "Ropa", 25);
        Venta venta7 = new Venta("pa", "Alimentos", 6);
        Venta venta8 = new Venta("co", "Alimentos", 7);
        Venta venta9 = new Venta("le", "Alimentos", 8);
        Venta venta10 = new Venta("ke", "Alimentos", 9);
        Venta venta11 = new Venta("ww", "Electrónica", 100);
        Venta venta12 = new Venta("we", "Electrónica", 110);
        Venta venta13 = new Venta("df", "Ropa", 12);
        Venta venta14 = new Venta("fd", "Ropa", 13);
        Venta venta15 = new Venta("wy", "Ropa", 14);

        ArrayList<Venta> lista = new ArrayList<Venta>();
        lista.add(venta1);
        lista.add(venta2);
        lista.add(venta3);
        lista.add(venta4);
        lista.add(venta5);
        lista.add(venta6);
        lista.add(venta7);
        lista.add(venta8);
        lista.add(venta9);
        lista.add(venta10);
        lista.add(venta11);
        lista.add(venta12);
        lista.add(venta13);
        lista.add(venta14);
        lista.add(venta15);

        int totalprecioE = 0;
        int totalprecioR = 0;
        int totalprecioA = 0;
        for (Venta recorre : lista) {
            if (recorre.getCategoria().equals("Ropa")) {
                totalprecioR += (int) recorre.getPrecio();
            } else if (recorre.getCategoria().equals("Alimentos")) {
                totalprecioA += (int) recorre.getPrecio();
            } else if (recorre.getCategoria().equals("Electrónica")) {
                totalprecioE += (int) recorre.getPrecio();
            }
        }
                System.out.println("Total ropa: " + totalprecioR);
                System.out.println("Total alimentos: " + totalprecioA);
                System.out.println("Total precio es: " + totalprecioE);
    }
}