//En tu clase principal, crea un ArrayList de tipo Estudiante.
// Agrega 5 estudiantes diferentes con sus respectivas notas a la lista. Recorre el ArrayList para calcular el promedio de notas de todo el grupo.
//  Encuentra e imprime el nombre del estudiante que tiene la nota más alta.

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
    Estudiante e1 =  new Estudiante("María", 8);
    Estudiante e2 =  new Estudiante("Juan", 9);
    Estudiante e3 =  new Estudiante("Lucía", 7);
    Estudiante e4 =  new Estudiante("Mateo", 10);
    Estudiante e5 =  new Estudiante("Jose", 6);

    ArrayList<Estudiante> lista = new ArrayList<Estudiante>();
        lista.add(e1);
        lista.add(e2);
        lista.add(e3);
        lista.add(e4);
        lista.add(e5);

        double suma = 0;
        for ( Estudiante estudiante : lista ) {
            suma += estudiante.getNota();
        }
        double promedio = suma / lista.size();
        System.out.println("El promedio es: " + promedio);

        double notaActual = 0;
        for (int i = 0; i < lista.size(); i++) {
            double nota = lista.get(i).getNota();
            if(nota > notaActual) {
                notaActual = nota;
            }
        }
        System.out.println("La nota más alta es: " + notaActual);
    }
}