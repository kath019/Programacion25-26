//Crea una clase llamada Estudiante que tenga dos atributos: nombre (String) y nota (double).
// Crea su constructor y los métodos getters. En tu clase principal, crea un ArrayList de tipo Estudiante.
// Agrega 5 estudiantes diferentes con sus respectivas notas a la lista. Recorre el ArrayList para calcular el promedio de notas de todo el grupo.
//  Encuentra e imprime el nombre del estudiante que tiene la nota más alta.
public class Estudiante {
    private String nombre;
    private double nota;

    public Estudiante(String nombre, double nota) {
        this.nombre = nombre;
        this.nota = nota;
    }

    public String getNombre() {
        return nombre;
    }

    public double getNota() {
        return nota;
    }
}
