// =======================================================
// PROGRAMA: ESTACIÓN METEOROLÓGICA
// Incluye las clases:
// 1. Main
// 2. EstacionMeteorologica
// 3. Medicion
// 4. Coordenadas
// 5. ComparadorHumedadDesc
// =======================================================

import java.io.*;
import java.util.*;

// =======================================================
// CLASE PRINCIPAL
// =======================================================
public class Main {
    public static void main(String[] args) {

        // Creamos unas coordenadas para la estación
        Coordenadas c = new Coordenadas(40, -3);

        // Creamos la estación leyendo del fichero datos.dat
        EstacionMeteorologica estacion = new EstacionMeteorologica("datos.dat", c);

        // Añadimos mediciones manualmente
        estacion.addMedicion(new Medicion(25, 70, 1012));
        estacion.addMedicion(new Medicion(18, 90, 1008));
        estacion.addMedicion(new Medicion(32, 60, 1015));
        estacion.addMedicion(new Medicion(15, 95, 1005));

        System.out.println("LISTA ORIGINAL:");
        estacion.mostrarLista();

        // Ordenar por temperatura ascendente
        estacion.ordenaTemperaturasAsc();
        System.out.println("\nORDENADO POR TEMPERATURA ASC:");
        estacion.mostrarLista();

        // Ordenar por humedad descendente
        estacion.ordenaHumedadesDesc();
        System.out.println("\nORDENADO POR HUMEDAD DESC:");
        estacion.mostrarLista();

        // Presión máxima
        System.out.println("\nMEDICIÓN CON MAYOR PRESIÓN:");
        System.out.println(estacion.presionMaxima());

        // Buscar medición
        Medicion buscar = new Medicion(18, 90, 1008);

        if (estacion.buscaMedicion(buscar)) {
            System.out.println("\nLa medición existe.");
        } else {
            System.out.println("\nLa medición NO existe.");
        }

        // Guardar fichero
        estacion.guardarFichero("datos.dat");
    }
}

// =======================================================
// CLASE ESTACION METEOROLOGICA
// =======================================================
class EstacionMeteorologica {

    // Lista donde guardamos las mediciones
    private ArrayList<Medicion> lista;

    // Coordenadas de la estación
    private Coordenadas localizacion;

    // ---------------------------------------------------
    // Constructor
    // Recibe nombre del fichero y coordenadas
    // ---------------------------------------------------
    public EstacionMeteorologica(String nombreFichero, Coordenadas c) {

        lista = new ArrayList<>();
        localizacion = c;

        // Intentamos leer el fichero binario
        try {
            ObjectInputStream entrada =
                    new ObjectInputStream(new FileInputStream(nombreFichero));

            while (true) {
                Medicion m = (Medicion) entrada.readObject();
                lista.add(m);
            }

        } catch (EOFException e) {
            // Fin del fichero (normal)
        } catch (Exception e) {
            // Si no existe fichero no pasa nada
        }
    }

    // ---------------------------------------------------
    // Añadir una medición
    // ---------------------------------------------------
    public void addMedicion(Medicion m) {
        lista.add(m);
    }

    // ---------------------------------------------------
    // Orden natural = temperatura ascendente
    // ---------------------------------------------------
    public void ordenaTemperaturasAsc() {
        Collections.sort(lista);
    }

    // ---------------------------------------------------
    // Ordenar humedad descendente
    // Necesitamos Comparator
    // ---------------------------------------------------
    public void ordenaHumedadesDesc() {
        Collections.sort(lista, new ComparadorHumedadDesc());
    }

    // ---------------------------------------------------
    // Buscar medición con presión máxima
    // ---------------------------------------------------
    public Medicion presionMaxima() {

        if (lista.isEmpty()) {
            return null;
        }

        Medicion max = lista.get(0);

        for (Medicion m : lista) {
            if (m.getPresion() > max.getPresion()) {
                max = m;
            }
        }

        return max;
    }

    // ---------------------------------------------------
    // Buscar una medición
    // ---------------------------------------------------
    public boolean buscaMedicion(Medicion m) {
        return lista.contains(m);
    }

    // ---------------------------------------------------
    // Guardar lista en fichero binario
    // ---------------------------------------------------
    public void guardarFichero(String nombreFichero) {

        try {
            ObjectOutputStream salida =
                    new ObjectOutputStream(new FileOutputStream(nombreFichero));

            for (Medicion m : lista) {
                salida.writeObject(m);
            }

            salida.close();

        } catch (Exception e) {
            System.out.println("Error guardando fichero.");
        }
    }

    // ---------------------------------------------------
    // Mostrar lista
    // ---------------------------------------------------
    public void mostrarLista() {
        for (Medicion m : lista) {
            System.out.println(m);
        }
    }
}

// =======================================================
// CLASE MEDICION
// Implementa Comparable para orden natural
// =======================================================
class Medicion implements Serializable, Comparable<Medicion> {

    private int temperatura;
    private int humedad;
    private int presion;

    // Constructor
    public Medicion(int temperatura, int humedad, int presion) {
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.presion = presion;
    }

    // Getters
    public int getTemperatura() {
        return temperatura;
    }

    public int getHumedad() {
        return humedad;
    }

    public int getPresion() {
        return presion;
    }

    // ---------------------------------------------------
    // compareTo = orden natural por temperatura ascendente
    // ---------------------------------------------------
    @Override
    public int compareTo(Medicion otra) {
        return this.temperatura - otra.temperatura;
    }

    // ---------------------------------------------------
    // equals para comparar objetos
    // ---------------------------------------------------
    @Override
    public boolean equals(Object obj) {

        if (this == obj) return true;

        if (obj == null || getClass() != obj.getClass())
            return false;

        Medicion otra = (Medicion) obj;

        return temperatura == otra.temperatura &&
                humedad == otra.humedad &&
                presion == otra.presion;
    }

    // ---------------------------------------------------
    // toString para mostrar bonito
    // ---------------------------------------------------
    @Override
    public String toString() {
        return "[Temp=" + temperatura +
                ", Humedad=" + humedad +
                ", Presion=" + presion + "]";
    }
}

// =======================================================
// COMPARATOR PARA HUMEDAD DESCENDENTE
// =======================================================
class ComparadorHumedadDesc implements Comparator<Medicion> {

    @Override
    public int compare(Medicion m1, Medicion m2) {
        return m2.getHumedad() - m1.getHumedad();
    }
}

// =======================================================
// CLASE COORDENADAS
// =======================================================
class Coordenadas {

    private int latitud;
    private int longitud;

    // Constructor
    public Coordenadas(int latitud, int longitud) {
        this.latitud = latitud;
        this.longitud = longitud;
    }

    @Override
    public String toString() {
        return "(" + latitud + ", " + longitud + ")";
    }
}