import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

public class Aprobados implements Serializable {
    HashMap<Integer, Aspirante> aspirantes;
    HashMap<Integer, ArrayList<Double>> notas;

    /* --------------------------------------------------------
       Carga los dos ficheros
       -------------------------------------------------------- */
    public void cargarDatos() {

        try {
            ObjectInputStream in1 =
                    new ObjectInputStream(
                            new FileInputStream("aspirantes.dat"));

            aspirantes =
                    (HashMap<Integer, Aspirante>) in1.readObject();

            in1.close();

            ObjectInputStream in2 =
                    new ObjectInputStream(
                            new FileInputStream("calificaciones.dat"));

            notas =
                    (HashMap<Integer, ArrayList<Double>>) in2.readObject();

            in2.close();

        } catch (Exception e) {
            System.out.println("Error cargando datos.");
        }
    }

    /* --------------------------------------------------------
       Calcula media de notas de un aspirante
       -------------------------------------------------------- */
    public double calcularMedia(int id) {

        ArrayList<Double> lista = notas.get(id);

        double suma = 0;

        for (double n : lista) {
            suma += n;
        }

        return suma / lista.size();
    }

    /* --------------------------------------------------------
       Genera informe ordenado por nombre
       -------------------------------------------------------- */
    public void generarInforme() {

        // Lista temporal para ordenar
        ArrayList<String> informe = new ArrayList<>();

        for (int id : aspirantes.keySet()) {

            Aspirante a = aspirantes.get(id);

            double media = calcularMedia(id);

            String linea =
                    a.getNombre() + ";" +
                            a.getDni() + ";" +
                            String.format("%.2f", media);

            informe.add(linea);
        }

        // Orden alfabético
        Collections.sort(informe);

        System.out.println("\nNombre\tDNI\tCalificación Media");

        for (String s : informe) {

            String datos[] = s.split(";");

            System.out.println(
                    datos[0] + "\t" +
                            datos[1] + "\t" +
                            datos[2]);
        }
    }
}
