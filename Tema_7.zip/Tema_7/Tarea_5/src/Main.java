import java.util.Scanner;

public class Main{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);

        int opcion;

        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Introducir aspirantes");
            System.out.println("2. Calificar prueba");
            System.out.println("3. Aprobados");
            System.out.println("4. Salir");

            System.out.print("Opcion: ");
            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {

                case 1:

                    // Crear objeto
                    IntroducirAspirantes ia =
                            new IntroducirAspirantes();

                    ia.insertarAspirante();
                    ia.guardarFicheros();
                    break;

                case 2:

                    CalificacionPruebas cp =
                            new CalificacionPruebas();

                    cp.introducirNotas();
                    cp.guardarFichero();
                    break;

                case 3:

                    Aprobados ap =
                            new Aprobados();

                    ap.cargarDatos();
                    ap.generarInforme();
                    break;

                case 4:
                    System.out.println("Fin del programa.");
                    break;

                default:
                    System.out.println("Opción incorrecta.");
            }

        } while (opcion != 4);
    }
}
