import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class IntroducirAspirantes implements Serializable {
    // Mapa:
    // clave = número identificativo
    // valor = objeto Aspirante
    HashMap<Integer, Aspirante> aspirantes = new HashMap<>();

    // Lista solo con IDs
    ArrayList<Integer> ids = new ArrayList<>();

    // Número incremental
    int contador = 1;

    Scanner sc = new Scanner(System.in);

    public void insertarAspirante() {

        String seguir;

        do {
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("DNI: ");
            String dni = sc.nextLine();

            System.out.print("Telefono: ");
            long telefono = sc.nextLong();

            // Crear objeto aspirante
            Aspirante a = new Aspirante(nombre, dni, telefono);

            // Guardar en mapa
            aspirantes.put(contador, a);

            // Guardar ID en lista
            ids.add(contador);

            System.out.println("Aspirante guardado con ID: " + contador);

            contador++;

            System.out.print("¿Insertar otro? (s/n): ");
            seguir = sc.nextLine();

        } while (seguir.equalsIgnoreCase("s"));
    }

    public void guardarFicheros() {

        try {
            ObjectOutputStream out1 = new ObjectOutputStream(new FileOutputStream("aspirantes.dat"));

            out1.writeObject(aspirantes);
            out1.close();

            ObjectOutputStream out2 = new ObjectOutputStream(new FileOutputStream("ids_aspirantes.dat"));

            out2.writeObject(ids);
            out2.close();

            System.out.println("Ficheros guardados correctamente.");

        } catch (Exception e) {
            System.out.println("Error guardando ficheros.");
        }
    }
}
