import java.io.*;
import java.util.*;


public class CalificacionPruebas implements Serializable {
    // ID -> Lista de notas
    HashMap<Integer, ArrayList<Double>> notas = new HashMap<>();

    Scanner sc = new Scanner(System.in);
    public void introducirNotas() {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("ids_aspirantes.dat"));
            ArrayList<Integer> ids = (ArrayList<Integer>) in.readObject();

            in.close();

            for (int id : ids) {
                System.out.print("Nota aspirante ID " + id + ": ");
                double nota = sc.nextDouble();

                // Si no existe lista, crearla
                if (!notas.containsKey(id)) {
                    notas.put(id, new ArrayList<Double>());
                }

                // Añadir nota
                notas.get(id).add(nota);
            }
            sc.nextLine();

        } catch (Exception e) {
            System.out.println("Error leyendo IDs.");
        }
    }

    public void guardarFichero() {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("calificaciones.dat"));
            out.writeObject(notas);
            out.close();
            System.out.println("Calificaciones guardadas.");

        } catch (Exception e) {
            System.out.println("Error guardando notas.");
        }
    }

}
