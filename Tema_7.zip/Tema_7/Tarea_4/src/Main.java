import java.io.*;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LinkedHashMap<String, Empleado> diccionario = new LinkedHashMap<>();
        System.out.println("1. Cargar desde fichero");
        System.out.println("2. Insertar desde consola");

        int opcion = sc.nextInt();
        sc.nextLine();
        if (opcion == 1) {
            diccionario = cargarFichero();
            mostrarMenu(diccionario);
        } else if (opcion == 2) {
            mostrarMenu(diccionario);
        } else {
            System.out.println("Número inválido");
        }
        guardarFichero(diccionario);
    }

    public static void mostrarMenu(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        int opcion = 0;
        while (opcion != 6) {
        System.out.println("Inserte\n1 para visualizar el listado" +
                "\n2 para borrar un empleado" +
                "\n3 para visualizar un empleado" +
                "\n4 para modificar un empleado" +
                "\n5 para insertar un empleado" +
                "\nInserte 6 para salir");
            opcion = sc.nextInt();
            sc.nextLine();
            if (opcion == 1) {
                visualizarListado(diccionario);
            } else if (opcion == 2) {
                borrarEmpleado(diccionario);
            } else if (opcion == 3) {
                visualizarEmpleado(diccionario);
            } else if (opcion == 4) {
                modificarEmpleado(diccionario);
            }else if (opcion == 5) {
                System.out.println("Inserte el nombre:");
                String nombre = sc.nextLine();
                System.out.println("Inserte el dni:");
                String dni = sc.nextLine();
                System.out.println("Inserte la edad:");
                int edad = sc.nextInt();
                sc.nextLine();
                System.out.println("Inserte la estatura:");
                double estatura = sc.nextDouble();
                sc.nextLine();
                System.out.println("Inserte el sueldo:");
                int sueldo = sc.nextInt();
                Empleado emp1 = new Empleado(nombre, dni, edad, estatura, sueldo);
                diccionario.put(dni, emp1);
            }
        }
    }

    public static void visualizarListado(LinkedHashMap<String, Empleado> diccionario) {
        for (Empleado e : diccionario.values()) { System.out.println(e); }
    }

    public static void borrarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        String continuar;
        do{
            System.out.println("Ingrese el dni a borrar:");
            String dni = sc.nextLine();
            if(diccionario.remove(dni) != null) {
                System.out.println("Empleado eliminado");
            } else {
                System.out.println("No existe ese dni");
            }
            System.out.println("Ingrese 'e' para seguir eliminando ");
            continuar = sc.nextLine();
        } while (continuar.equalsIgnoreCase("e"));
    }
    public static void modificarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el dni del empleado a modificar;");
        String dni = sc.nextLine();
        Empleado e =  diccionario.get(dni);

        if(e != null) {
            System.out.println("Ingrese el nuevo nombre:");
            String nombre = sc.nextLine();
            e.setNombre(nombre);
            System.out.println("Ingrese nueva edad:");
            int edad = sc.nextInt();
            e.setEdad(edad);
            System.out.println("Ingrese nueva estatura:");
            double estatura = sc.nextDouble();
            e.setEstatura(estatura);
            System.out.println("Ingrese nueva sueldo:");
            int sueldo = sc.nextInt();
            e.setSueldo(sueldo);
        } else {
            System.out.println("No existe ese dni");
        }
    }

    public static void visualizarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el dni del empleado:");
        String dni = sc.nextLine();
        Empleado e =  diccionario.get(dni);
        if(e != null) {
            System.out.println(e);
        } else {
            System.out.println("No existe ese dni");
        }
    }

    public static void guardarFichero(LinkedHashMap<String, Empleado> diccionario) {
        try{
            ObjectOutputStream guardar = new ObjectOutputStream(new FileOutputStream("empleados.dat"));
            guardar.writeObject(diccionario);
            guardar.close();
            System.out.println("Datos guardados.");
        } catch (IOException e) {
            System.out.println("Error al guardar datos.");;
        }
    }

    public static LinkedHashMap<String, Empleado> cargarFichero() {
        LinkedHashMap<String, Empleado> diccionario = new LinkedHashMap<>();
        File fichero = new File("empleados.dat");
        if(!fichero.exists()) {
            System.out.println("No existe el fichero");
        }
        try{
            ObjectInputStream cargar = new ObjectInputStream(new FileInputStream(fichero));
            diccionario = (LinkedHashMap<String, Empleado>) cargar.readObject();
            cargar.close();
            System.out.println("Datos cargados.");
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("Error al cargar datos.");
        } catch (Exception e) {
            System.out.println("Error al cargar datos."+ e.getMessage());
        }
        return diccionario;
    }
}
