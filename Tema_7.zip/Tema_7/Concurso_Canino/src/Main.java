public class Main {
    public static void main(String[] args) {
        Concurso concurso = new Concurso("Concurso internacional", "Madrid");
        Propietario p1 = new Propietario("Ana", "Lopez", 1, "España");
        Propietario p2 = new Propietario("John", "Smith", 2, "USA");
        Propietario p3 = new Propietario("Maria", "Rossi", 3, "Italia");


        Perro perro1 = new Perro("Max", 5, 20.5, true, p1, "Pastor Aleman");
        Perro perro2 = new Perro("Luna", 3, 18.0, true, p2, "Pastor Aleman");
        Perro perro3 = new Perro("Rocky", 6, 25.0, false, p3, "Pastor Aleman");

        Perro perro4 = new Perro("Bella", 2, 10.0, true, p1, "Bulldog");
        Perro perro5 = new Perro("Toby", 4, 12.5, true, p2, "Bulldog");
        Perro perro6 = new Perro("Daisy", 1, 9.0, false, p3, "Bulldog");

        Perro perro7 = new Perro("Charlie", 7, 30.0, true, p1, "Labrador");
        Perro perro8 = new Perro("Milo", 5, 28.0, true, p2, "Labrador");
        Perro perro10 = new Perro("Leo", 4, 27.0, true, p1, "Labrador");
        Perro perro9 = new Perro("Coco", 3, 26.0, false, p3, "Labrador");


        //Añadir perros al concurso
        concurso.addDog("Pastor Aleman", perro1);
        concurso.addDog("Pastor Aleman", perro2);
        concurso.addDog("Pastor Aleman", perro3);

        concurso.addDog("Bulldog", perro4);
        concurso.addDog("Bulldog", perro5);
        concurso.addDog("Bulldog", perro6);

        concurso.addDog("Labrador", perro7);
        concurso.addDog("Labrador", perro8);
        concurso.addDog("Labrador", perro9);
        concurso.addDog("Labrador", perro10);

        //Mostrar perros de un propietario
        System.out.println("Perros del socio 1:");
        concurso.ownerDogs(1);

        //Ordenar por peso
        System.out.println("\nPerros Labrador por peso:");
        concurso.perrosPorPeso("Labrador");

        //Ordenar por edad
        System.out.println("\nPerros Bulldog por edad:");
        concurso.perrosPorEdad("Bulldog");

        //Descalificar un perro
        System.out.println("\nDescalificando perro...");
        concurso.disqualifyDog(perro5);

        // Guardar en fichero
        concurso.guardarPerros();

    }
}
