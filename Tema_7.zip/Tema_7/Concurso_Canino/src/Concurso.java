import java.io.*;
import java.util.*;

public class Concurso implements Serializable {
    private String nombre;
    private String localidad;
    private Map<String, Set<Perro>> perrosPorRaza;

    public Concurso(String nombre, String localidad) {
        this.nombre = nombre;
        this.localidad = localidad;
        this.perrosPorRaza= new HashMap<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLocalidad() {
        return localidad;
    }

    public void setLocalidad(String localidad) {
        this.localidad = localidad;
    }

    public Map<String, Set<Perro>> getPerrosPorRaza() {
        return perrosPorRaza;
    }

    public void setPerrosPorRaza(Map<String, Set<Perro>> perrosPorRaza) {
        this.perrosPorRaza = perrosPorRaza;
    }

    public void addDog(String raza, Perro perro) {
        //Comprobar que la raza del perro coincide con la que pasamos
        if(!perro.getRaza().equalsIgnoreCase(raza)) {
            System.out.println("Error: el perro no pertenece a la raaza indicada.");
            return;
        }
        // Si la raza NO existe en el mapa, la creamos
        if(!perrosPorRaza.containsKey(raza)) {
            perrosPorRaza.put(raza,new HashSet<>());
        }
        //Añadimos el perro al conjunto de esa raza
        perrosPorRaza.get(raza).add(perro);
    }

    //eliminar un perro por la raza
    public void disqualifyDog(Perro perro) {

        boolean encontrado = false;

        for(Set<Perro> perros: perrosPorRaza.values()) {

            //Intentamos eliminar el perro
            if(perros.remove(perro)){
                encontrado = true;
                break;
            }
        }
        if(!encontrado) {
            System.out.println("Perro no inscrito");
        }

    }

    public void ownerDogs(int numSocio){
        boolean encontrado = false;

        // Recorremos todos los conjuntos de perros (todas las razas)
        for (Set<Perro> perros: perrosPorRaza.values()){
            // 🐶 Recorremos cada perro
            for(Perro p: perros) {
                // Comprobamos si pertenece al socio
                if(p.getPropietario().getNumSocio() == numSocio){
                    System.out.println(p);
                    encontrado = true;
                }
            }
            if(!encontrado) {
                System.out.println("Este socio no tiene perros inscritos.");
            }
        }
    }

    public void perrosPorPeso(String raza){
        if(!perrosPorRaza.containsKey(raza)){
            System.out.println("No hay perros de esa raza");
            return;
        }

        // Crear el Set de perros de esa raza
        Set<Perro> perros =  perrosPorRaza.get(raza);

        // Pasar el Set a una lista (para poder ordenar)
        List<Perro> lista = new ArrayList<>(perros);

        //ORDENAR DE FORMA DECRECIENTE
        lista.sort((p1, p2) -> Double.compare(p2.getPeso(), p1.getPeso()));

        //mostrar los perros
        for(Perro perro:lista){
            System.out.println(perro);
        }
    }

    public void perrosPorEdad(String raza){
        if(!perrosPorRaza.containsKey(raza)){
            System.out.println("No hay perros de esa raza");
            return;
        }

        Set<Perro> perros = perrosPorRaza.get(raza);

        List<Perro> lista = new ArrayList<>(perros);

        lista.sort((p1, p2) -> Integer.compare(p2.getEdad(), p1.getEdad()));

        for(Perro perro: lista){
            System.out.println(perro);
        }
    }

    public void cargarPerros(){
        try{
            ObjectInputStream cargar = new ObjectInputStream(new FileInputStream("perros.dat"));
            while(true){
                Perro perro = (Perro) cargar.readObject();
                System.out.println("Datos cargados");
                addDog(perro.getRaza(), perro);
                cargar.close();
            }
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("Error al cargar datos.");
        }
    }

    //guardarlos sin tener en cuenta el Map con la raza
    public void guardarPerros() {
        try{
            ObjectOutputStream guardar = new ObjectOutputStream(new FileOutputStream("perros.dat"));
            //se recorren todas las razas
            for(Set<Perro> perros: perrosPorRaza.values()){
                //Recorremos cada perro
                for(Perro perro: perros) {
                    //Guardamos cada perro individualmente
                    guardar.writeObject(perro);
                    guardar.close();
                    System.out.println("Datos guardados");
                }
            }
        } catch (IOException e) {
            System.out.println("Error al guardar datos.");
        }
    }
}
