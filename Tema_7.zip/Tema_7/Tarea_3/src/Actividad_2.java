//Actividad 2: Añada al programa anterior la siguiente funcionalidad.
// El programa pedirá al usuario un dni, calculará la clave que ha de
// consultar, comprobará que dicha clave existe, y, en tal caso, mostrará
// el valor asociado a esa clave en el HashMap.

import java.util.HashMap;
import java.util.Scanner;

public class Actividad_2 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

            HashMap<Integer, String> claveUsario = new HashMap<>();

            boolean salir = false;
            while(salir==false){
                System.out.println("Menú:");
                System.out.println("Agregar: 1");
                System.out.println("Buscar: 2");
                System.out.println("Salir: 3");
                int opcion = sc.nextInt();
                sc.nextLine();

                if(opcion==1){
                    System.out.println("Ingresa el dni:");
                    String dni1 = sc.next();
                    sc.nextLine();
                    System.out.println("Ingresa el nombre:");
                    String nombre1 = sc.nextLine();

                    int sumaDni = Actividad_1.CalcularClave(dni1);

                    claveUsario.put(sumaDni,nombre1);
                    System.out.println(sumaDni);

                } else if (opcion==2) {
                    String resultado;
                    System.out.println("Ingresa la clave:");
                    int clave = sc.nextInt();
                    sc.nextLine();
                    resultado = claveUsario.get(clave);
                    if(resultado == null){
                        System.out.println("No existe el clave con la clave: "+clave);
                    } else {
                        System.out.println("El nombre para esa clave es: " + resultado);
                    }
                } else {
                    break;
                }
            }
        }
}
