//Actividad 3: Recorre el Map anterior, extrayendo cada pareja clave-valor, y mostrándolas, de tal forma que
// se escriban los datos así:
//La clave 37 está asociada al nombre "Pedro Gonzalez Jimenez".
//La clave ... está asociada al nombre ....

import java.util.HashMap;
import java.util.Scanner;

public class Actividad_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<Integer, String> claveUsario = new HashMap<>();

        boolean salir = false;
        while(salir==false){
            System.out.println("Menú:");
            System.out.println("Agregar: 1");
            System.out.println("Buscar: 2");
            System.out.println("Salir: 3");
            int opcion = sc.nextInt();
            sc.nextLine();

            if(opcion==1){
                System.out.println("Ingresa el dni:");
                String dni1 = sc.next();
                sc.nextLine();
                System.out.println("Ingresa el nombre:");
                String nombre1 = sc.nextLine();

                int sumaDni = Actividad_1.CalcularClave(dni1);

                claveUsario.put(sumaDni,nombre1);
                System.out.println(sumaDni);

            } else if (opcion==2) {
                String resultado;
                System.out.println("Ingresa la clave:");
                int clave = sc.nextInt();
                sc.nextLine();
                resultado = claveUsario.get(clave);
                if(resultado == null){
                    System.out.println("No existe el clave con la clave: "+clave);
                } else {
                    //La clave 37 está asociada al nombre "Pedro Gonzalez Jimenez"
                    System.out.println("La clave " + clave + " está asociada al nombre " + resultado);
                }
            } else {
                break;
            }
        }
    }
}
