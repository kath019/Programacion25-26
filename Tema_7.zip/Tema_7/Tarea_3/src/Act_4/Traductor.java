package Act_4;//Actividad 4: Crea una clase llamada Traductor, que contenga un atributo llamado "diccionario" de tipo HashMap
// y se comporte de esta forma:

//Al crear el objeto Traductor, el atributo diccionario debe ser cargado con la información de un archivo
// de texto cuyo nombre se le pasará por parámetro al constructor. Este archivo debe contener varias palabras en
// español y su traducción al inglés, de tal forma que las palabras en español sean la clave,
// y las que estén en inglés, el valor. Por ejemplo:
//hola, hello
//mundo, world
//gracias, thanks
//adios, bye
//Crear un método que reciba una palabra o una frase, y devuelva la cadena traducida al inglés.

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

public class Traductor {
    private HashMap<String, String> diccionario;

    public Traductor(String nombreFichero) {
        diccionario = new HashMap<>();
        CargarDatos(nombreFichero);
    }

    public void CargarDatos(String nombreArchivo){
        try{
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String linea;

            while ((linea = br.readLine()) != null){
                String[] partes = linea.split(", ");
                String nombre = partes[0];
                String significado = partes[1];
                diccionario.put(nombre, significado);
            }
                br.close();
        }catch(Exception e){
            System.out.println("No se pudo leer los datos");
        }
    }

    public String  traducir(String texto){
        String[] palabras = texto.split(" ");
        String resultado = "";

        for(String palabra : palabras){
            if(diccionario.containsKey(palabra)){
                resultado += diccionario.get(palabra);
            } else{
                resultado += palabra + " ";
            }
        }
        return resultado.trim();
    }
}
