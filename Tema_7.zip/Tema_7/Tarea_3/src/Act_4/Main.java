package Act_4;

public class Main {
    public static void main(String[] args) {
        Traductor t = new Traductor("diccionario.txt");

        String frase = "hola mundo";
        System.out.println(t.traducir(frase));
    }
}