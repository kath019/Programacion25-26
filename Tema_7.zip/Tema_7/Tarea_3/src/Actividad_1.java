//Actividad 1: Crea un HashMap cuya clave sea un Integer, y cuyos valores sean los nombres de algunos de tus compañeros.
// La clave ha de calcularse mediante un método que reciba un String que represente el dni, y devuelva la suma de sus dígitos.
//
//46221877D -> 4+6+2+2+1+8+7+7=37
//Una vez guardados los elementos, deben mostrarse todos los elementos (clave-valor) del HasMap.

import java.util.ArrayList;
import java.util.HashMap;

public class Actividad_1 {
    public static void main(String[] args) {
        HashMap<Integer, String> companieros = new HashMap<>();
        String [] lista = {"Sara", "Juan", "Lucía", "José", "María"};
        String [] dni = {"3030303033R", "12345678V", "27486248F", "16452974Z", "64827496P"};


        for(int i=0; i < lista.length; i++){
            int clave = CalcularClave(dni[i]);
            companieros.put(clave, lista[i]);
        }
        for (Integer i : companieros.keySet()) {
            System.out.println("clave: " + i + " valor: " + companieros.get(i));
        }
    }

    public static int CalcularClave(String dni){
        int suma = 0;
        for(int i = 0; i < dni.length(); i++){
            char c = dni.charAt(i);
            if(Character.isDigit(c)){
                suma += Character.getNumericValue(c);
            }
        }
        return  suma;
    }
}
