public class Formulario_2 {
    /* MÉTODO PARA GUARDAR UN FICHERO CON UN MAPA ORDENADO POR INSERCIÓN COMO PARÁMETRO
        public static void guardarFichero(LinkedHashMap<String, Empleado> diccionario) {
        try{
            ObjectOutputStream guardar = new ObjectOutputStream(new FileOutputStream("empleados.dat"));
            guardar.writeObject(diccionario);
            guardar.close();
            System.out.println("Datos guardados.");
        } catch (IOException e) {
            System.out.println("Error al guardar datos.");;
        }
    }
     */

    /* MÉTODO PARA CARGAR(LEER) UN FICHERO CON UN MAPA ORDENADO POR INSERCIÓN COMO PARÁMETRO
    public static LinkedHashMap<String, Empleado> cargarFichero() {
        LinkedHashMap<String, Empleado> diccionario = new LinkedHashMap<>();
        try{
            ObjectInputStream cargar = new ObjectInputStream(new FileInputStream("empleados.dat"));
            diccionario = (LinkedHashMap<String, Empleado>) cargar.readObject();
            cargar.close();
            System.out.println("Datos cargados.");
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("Error al cargar datos.");
        }
        return diccionario;
    }
    */

    /*VISUALIZAR EL LISTADO
        public static void visualizarListado(LinkedHashMap<String, Empleado> diccionario) {
        for (Empleado e : diccionario.values()) { System.out.println(e); }
    }
     */

    /*BORRAR TODO UN ELEMENTO POR CLAVE
    public static void borrarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        String continuar;
        do{
            System.out.println("Ingrese el dni a borrar:");
            String dni = sc.nextLine();
            if(diccionario.remove(dni) != null) {
                System.out.println("Empleado eliminado");
            } else {
                System.out.println("No existe ese dni");
            }
            System.out.println("Ingrese 'e' para seguir eliminando ");
            continuar = sc.nextLine();
        } while (continuar.equalsIgnoreCase("e"));
    }
     */

    /*VER UN ELEMENTO POR CLAVE
        public static void visualizarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el dni del empleado:");
        String dni = sc.nextLine();
        Empleado e =  diccionario.get(dni);
        if(e != null) {
            System.out.println(e);
        } else {
            System.out.println("No existe ese dni");
        }
    }
     */

    /*MODIFICAR TODO UN ELEMENTO POR CLAVE
        public static void modificarEmpleado(LinkedHashMap<String, Empleado> diccionario) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese el dni del empleado a modificar;");
        String dni = sc.nextLine();
        Empleado e =  diccionario.get(dni);

        if(e != null) {
            System.out.println("Ingrese el nuevo nombre:");
            String nombre = sc.nextLine();
            e.setNombre(nombre);
            System.out.println("Ingrese nueva edad:");
            int edad = sc.nextInt();
            e.setEdad(edad);
        } else {
            System.out.println("No existe ese dni");
        }
    }
     */

    /*INSERTAR UN ELEMENTO PARTE POR PARTE
                    System.out.println("Inserte el nombre:");
                String nombre = sc.nextLine();
                System.out.println("Inserte el dni:");
                String dni = sc.nextLine();
                System.out.println("Inserte la edad:");
                int edad = sc.nextInt();
                sc.nextLine();

                Empleado emp1 = new Empleado(nombre, dni, edad);
                diccionario.put(dni, emp1);
     */

    /*COMPARATOR
    class ComparadorHumedadDesc implements Comparator<Medicion> {

    @Override
    public int compare(Medicion m1, Medicion m2) {
        return m2.getHumedad() - m1.getHumedad();
    }
}
     */
}
