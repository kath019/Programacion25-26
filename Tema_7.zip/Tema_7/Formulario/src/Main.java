public class Main {
    /*
    🔹 RESUMEN RÁPIDO
    ArrayList → lista normal
    LinkedList → muchas inserciones/eliminaciones
    HashSet → sin duplicados, sin orden
    TreeSet → sin duplicados + ordenado
    LinkedHashSet → sin duplicados + orden de inserción
    HashMap → clave-valor sin orden
    TreeMap → clave-valor ordenado
    LinkedHashMap → clave-valor con orden de inserción
     */
    /*PARA ORDENAR UN COLLECTION
        Collections.sort(listaCollection);
     */

    /*public interface Collection<E> extends Iterable<E>
    // Basic operations
    int size();
    isEmpty();
    contains(Object element);
    add(E element); //optional
    remove(Object element); //optional

    // Bulk operations
     containsAll(Collection<?> c);
     addAll(Collection<? extends E> c); //optional
     removeAll(Collection<?> c); //optional
     retainAll(Collection<?> c); //optional
    clear(); //elimina todos los elementos de la Collection
    */

    //• for-each
    //for (Object o : collection){System.out.println(o);}


    /*
    Interface List: métodos
    • add(i,o) Insert o at position i
    • add(o) Append o to the end
    • get(i) Return the i-th element
    • remove(o) Remove the element o
    • set(i,o) Replace the i-th element with o
    • shuffle(list) mezcla los elementos de forma aleatoria

     */

    /*
    Interface Map: métodos
    • Clear() Remove all mappings
    • containsKey(k) Whether contains a mapping for k
    • containsValue(v) Whether contains a mapping to v
    • SetentrySet() Set of key-value pairs
    • get(k) The value associated with k
    • isEmpty() Whether it is empty
    • keySet() Set of keys
    • put(k,v) Associate v with k
    • remove(k) Remove the mapping for k
    • size() The number of pairs
     */

}
