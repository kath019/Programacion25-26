public class Main {
    /*
    🔹 1. TIPOS PRINCIPALES (elige rápido)
        📌 List (ordenadas, permiten duplicados)
            ArrayList → acceso rápido (leer)
            LinkedList → insertar/eliminar rápido
        📌 Set (sin duplicados)
            HashSet → sin orden
            TreeSet → ordenado automáticamente
            LinkedHashSet → mantiene orden de inserción
        📌 Map (clave → valor)
            HashMap → sin orden
            TreeMap → ordenado por clave
            LinkedHashMap → orden de inserción
    🔹 2. ORDENAR
        Collections.sort(lista);
    🔹 3. INTERFAZ COLLECTION (base de todo)
            🧱 Básicos
            size()
            isEmpty()
            contains(Object o)
            add(E e)
            remove(Object o)
            📦 Operaciones en grupo
            containsAll(Collection c)
            addAll(Collection c)
            removeAll(Collection c)
            retainAll(Collection c)
            clear()
    🔹 4. RECORRER (MUY IMPORTANTE)
        for (Object o : collection) {
            System.out.println(o);
        }
    🔹 5. INTERFAZ LIST
        add(i, o)      // insertar en posición
        add(o)         // añadir al final
        get(i)         // obtener elemento
        remove(o)      // eliminar
        set(i, o)      // reemplazar
        Collections.shuffle(list) // mezclar
    🔹 6. INTERFAZ MAP
        clear()
        containsKey(k)
        containsValue(v)
        entrySet()
        get(k)
        isEmpty()
        keySet()
        put(k, v)
        remove(k)
        size()
    🔥 TRUCO RÁPIDO PARA EL EXAMEN
    ¿Duplicados?
        → Sí → List
        → No → Set
        ¿Clave-valor?
        → Map
        ¿Necesito orden?
        → Sí → Tree
        → Orden de inserción → LinkedHash
        → Me da igual → Hash
     */

}
