import java.io.*;
import java.util.*;

public class Coronavirus implements Serializable{
    private String nombre;
    private String localidad;
    private Map<Character, Set<Paciente>> infectados;

    public Coronavirus() {
        this.nombre = "COVID-19";
        this.localidad = "Wuhan";
        this.infectados = new HashMap<>();
    }

    public void addPaciente(char cepa, Paciente paciente) {
        // Comprobación si la cepa no coincide con la cepa
        if(paciente.getCepa() != cepa) {
            System.out.println("Paciente no cumple");
        }

        //si la cepa no existe, se crea
        infectados.putIfAbsent(cepa, new HashSet<>());

        //añadir
        infectados.get(cepa).add(paciente);
    }

    public void darDeAltaPaciente(Paciente paciente){
        boolean encontrado = false;

        for(Set<Paciente> pacientes: infectados.values()) {

            //Intentamos eliminar el paciente
            if(pacientes.remove(paciente)){
                encontrado = true;
                break;
            }
        }
        if(!encontrado) {
            System.out.println("No se ha encontrado el paciente");
        }
    }

    public void pacientesDeUnDoctor(int numColegiado){
        boolean encontrado = false;

        // Recorremos todos los conjuntos de perros (todas las razas)
        for (Set<Paciente> pacientes: infectados.values()){
            // 🐶 Recorremos cada perro
            for(Paciente p: pacientes) {
                // Comprobamos si pertenece al socio
                if(p.getMedico().getNumColegiado() == numColegiado){
                    System.out.println(p);
                    encontrado = true;
                }
            }
            if(!encontrado) {
                System.out.println("Este médico no lleva ningún paciente.");
            }
        }
    }

    public void pacientesporPeso(char cepa){
        if(!infectados.containsKey(cepa)){
            System.out.println("No hay pacientes con esa cepa");
            return;
        }

        // Crear el Set de perros de esa raza
        Set<Paciente> pacientes =  infectados.get(cepa);

        // Pasar el Set a una lista (para poder ordenar)
        List<Paciente> lista = new ArrayList<>(pacientes);

        //ORDENAR DE FORMA DECRECIENTE
        lista.sort((p1, p2) -> Double.compare(p2.getPeso(), p1.getPeso()));

        //mostrar los perros
        for(Paciente paciente:lista){
            System.out.println(paciente);
        }
    }

    public void pacientesPorEdad(char cepa){
        if(!infectados.containsKey(cepa)){
            System.out.println("No hay pacientes de esa edad");
            return;
        }

        Set<Paciente> pacientes = infectados.get(cepa);

        List<Paciente> lista = new ArrayList<>(pacientes);

        lista.sort((p1, p2) -> Integer.compare(p2.getEdad(), p1.getEdad()));

        for(Paciente paciente: lista){
            System.out.println(paciente);
        }
    }

    public void cargarPacientes(){
        try{
            ObjectInputStream cargar = new ObjectInputStream(new FileInputStream("pacientes.dat"));
            while(true){
                Paciente paciente = (Paciente) cargar.readObject();
                System.out.println("Datos cargados");
                addPaciente(paciente.getCepa(), paciente);
                cargar.close();
            }
        } catch (ClassNotFoundException | IOException e) {
            System.out.println("Error al cargar datos.");
        }
    }

    public void guardarPacientes(){
        try{
            ObjectOutputStream guardar = new ObjectOutputStream(new FileOutputStream("pacientes.dat"));
            //se recorren todas las razas
            for(Set<Paciente> pacientes: infectados.values()){
                //Recorremos cada perro
                for(Paciente paciente: pacientes) {
                    //Guardamos cada perro individualmente
                    guardar.writeObject(paciente);
                    guardar.close();
                    System.out.println("Datos guardados");
                }
            }
        } catch (IOException e) {
            System.out.println("Error al guardar datos.");
        }
    }
}
