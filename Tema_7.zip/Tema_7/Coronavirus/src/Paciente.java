import java.io.Serializable;

public class Paciente implements Serializable {
    private String nombre;
    private int edad;
    private double peso;
    private boolean esVacunado;
    private Medico medico;
    private char cepa;

    public Paciente(String nombre, int edad, double peso, boolean esVacunado, Medico medico, char cepa) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.esVacunado = esVacunado;
        this.medico = medico;
        this.cepa = cepa;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public boolean isEsVacunado() {
        return esVacunado;
    }

    public void setEsVacunado(boolean esVacunado) {
        this.esVacunado = esVacunado;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public char getCepa() {
        return cepa;
    }

    public void setCepa(char cepa) {
        this.cepa = cepa;
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "nombre='" + nombre + '\'' +
                ", edad=" + edad +
                ", peso=" + peso +
                ", esVacunado=" + esVacunado +
                ", medico=" + medico +
                ", cepa=" + cepa +
                '}';
    }
}
