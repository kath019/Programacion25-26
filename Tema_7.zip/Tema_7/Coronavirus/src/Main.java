import java.util.HashSet;

public class Main {
    public static void main(String[] args) {
        Coronavirus coronavirus = new Coronavirus();
        // Crear médicos
        Medico m1 = new Medico("Dr. López", "Marques", 1, "V.Rocío");
        Medico m2 = new Medico("Dra. Pérez", "Castaño", 2, "V. Macarena");
        Medico m3 = new Medico("Dr. García", "Lopez", 3, "H. Militar");

        // Crear pacientes (10, con distintas cepas)
        Paciente p1 = new Paciente("Ana", 25, 60.5, true, m1, 'A');
        Paciente p2 = new Paciente("Luis", 30, 75.0, false, m2, 'B');
        Paciente p3 = new Paciente("María", 40, 68.0, true, m3, 'C');
        Paciente p4 = new Paciente("Carlos", 22, 70.2, false, m1, 'A');
        Paciente p5 = new Paciente("Lucía", 35, 55.3, true, m2, 'B');
        Paciente p6 = new Paciente("Pedro", 50, 80.0, false, m3, 'C');
        Paciente p7 = new Paciente("Sofía", 28, 62.1, true, m1, 'A');
        Paciente p8 = new Paciente("Jorge", 33, 77.7, false, m2, 'B');
        Paciente p9 = new Paciente("Elena", 45, 65.4, true, m3, 'C');
        Paciente p10 = new Paciente("Raúl", 29, 72.0, false, m1, 'A');

        // Añadir pacientes
        coronavirus.addPaciente('A', p1);
        coronavirus.addPaciente('B', p2);
        coronavirus.addPaciente('C', p3);
        coronavirus.addPaciente('A', p4);
        coronavirus.addPaciente('B', p5);
        coronavirus.addPaciente('C', p6);
        coronavirus.addPaciente('A', p7);
        coronavirus.addPaciente('B', p8);
        coronavirus.addPaciente('C', p9);
        coronavirus.addPaciente('A', p10);

        // Pacientes de un médico
        System.out.println("\nPACIENTES DEL MÉDICO 1");
        coronavirus.pacientesDeUnDoctor("1");

        // Dar de alta (eliminar) un paciente
        System.out.println("\n=== DAR DE ALTA A ANA ===");
        coronavirus.darDeAltaPaciente(p1);

        // Intentar eliminar uno que no existe
        System.out.println("\n=== ELIMINAR PACIENTE NO EXISTENTE ===");
        coronavirus.darDeAltaPaciente(p1);

        // Guardar en fichero
        coronavirus.guardarPacientes();

        // Crear nuevo objeto para comprobar carga
        Coronavirus covid2 = new Coronavirus();
        covid2.cargarPacientes();

    }
}