import java.io.Serializable;
import java.util.Objects;

public class Aeronave implements Serializable {
    private String designacion;
    private String fabricante;
    private TipoAeronave tipoAeronave;
    private double alcMax;
    private int id;
    private static int contador = 1;

    public Aeronave(String designacion, String fabricante, TipoAeronave tipoAeronave, double alcMax) {
        this.designacion = designacion;
        this.fabricante = fabricante;
        this.tipoAeronave = tipoAeronave;
        this.alcMax = alcMax;
        //id unico
        this.id = contador++;
    }

    public String getDesignacion() {
        return designacion;
    }

    public void setDesignacion(String designacion) {
        this.designacion = designacion;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }

    public TipoAeronave getTipoAeronave() {
        return tipoAeronave;
    }

    public void setTipoAeronave(TipoAeronave tipoAeronave) {
        this.tipoAeronave = tipoAeronave;
    }

    public double getAlcMax() {
        return alcMax;
    }

    public void setAlcMax(double alcMax) {
        this.alcMax = alcMax;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Aeronave{" +
                "designacion='" + designacion + '\'' +
                ", fabricante='" + fabricante + '\'' +
                ", tipoAeronave=" + tipoAeronave +
                ", alcMax=" + alcMax +
                ", id=" + id +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Aeronave aeronave = (Aeronave) o;
        return Objects.equals(designacion, aeronave.designacion);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(designacion);
    }
}
