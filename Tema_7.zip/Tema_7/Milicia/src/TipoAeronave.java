public enum TipoAeronave {
    CAZA,
    BOMBARDERO,
    TRANSPORTE,
    DRON,
    HELICOPTERO
}
