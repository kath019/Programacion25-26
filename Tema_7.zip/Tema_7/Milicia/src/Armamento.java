import java.io.Serializable;
import java.util.Objects;

public class Armamento implements Serializable {
    private String nombre;
    private String descriptivo;
    private int cantMunicion;
    private double alcMax;

    private static int contador = 1;
    private int id;

    public Armamento(String nombre, String descriptivo, int cantMunicion, double alcMax) {
        this.nombre = nombre;
        this.descriptivo = descriptivo;
        this.cantMunicion = cantMunicion;
        this.alcMax = alcMax;
        this.id = contador++;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescriptivo() {
        return descriptivo;
    }

    public void setDescriptivo(String descriptivo) {
        this.descriptivo = descriptivo;
    }

    public int getCantMunicion() {
        return cantMunicion;
    }

    public void setCantMunicion(int cantMunicion) {
        this.cantMunicion = cantMunicion;
    }

    public double getAlcMax() {
        return alcMax;
    }

    public void setAlcMax(double alcMax) {
        this.alcMax = alcMax;
    }

    public int getId() {
        return id;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Armamento armamento = (Armamento) o;
        return Objects.equals(nombre, armamento.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(nombre);
    }

    @Override
    public String toString() {
        return "Armamento{" +
                "nombre='" + nombre + '\'' +
                ", descriptivo='" + descriptivo + '\'' +
                ", cantMunicion=" + cantMunicion +
                ", alcMax=" + alcMax +
                ", id=" + id +
                '}';
    }
}
