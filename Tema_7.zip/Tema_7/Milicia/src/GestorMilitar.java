import java.io.*;
import java.util.*;

public class GestorMilitar implements Serializable {
    //las claves ya son únicas por lo que no necesitas un Set
   HashMap<String,Aeronave> designacionAeronave;
   HashMap<String, Armamento> nombreArmamento;

    //para relacionarlos
    private HashMap<Aeronave, Set<Armamento>> aeronaveArmamentos;
    private HashMap<Armamento, Set<Aeronave>> armamentoAeronaves;

    public GestorMilitar() {
        designacionAeronave = new HashMap<>();
        nombreArmamento = new HashMap<>();
        aeronaveArmamentos = new HashMap<>();
        armamentoAeronaves = new HashMap<>();
    }

    public void addEquipamiento(Aeronave a, Armamento arm){
        //parte opcional para mejor funcionamiento
        if (!designacionAeronave.containsKey(a.getDesignacion()) ||
                !nombreArmamento.containsKey(arm.getNombre())) {
            System.out.println("Error: aeronave o armamento no registrado");
            return;
        }

        // Aeronave → Armamento
        aeronaveArmamentos.putIfAbsent(a, new HashSet<>());
        aeronaveArmamentos.get(a).add(arm);

        // Armamento → Aeronave
        armamentoAeronaves.putIfAbsent(arm, new HashSet<>());
        armamentoAeronaves.get(arm).add(a);
    }

    public List<Armamento> getArmamento(Aeronave a){

        // Si no existe la aeronave en el mapa de relaciones
        if (!aeronaveArmamentos.containsKey(a)) {
            return new ArrayList<>(); // lista vacía
        }
        // Obtener el set
        Set<Armamento> setArm = aeronaveArmamentos.get(a);

        // Convertir a lista
        List<Armamento> lista = new ArrayList<>(setArm);

        // Ordenar alfabéticamente por nombre
        lista.sort(Comparator.comparing(Armamento::getNombre));

        return lista;
    }

    public List<Aeronave> getAeronaves(Armamento arm){
        // Si no existe el armamento en la relación
        if (!armamentoAeronaves.containsKey(arm)) {
            return new ArrayList<>(); // lista vacía
        }

        // Obtener el set
        Set<Aeronave> setAero = armamentoAeronaves.get(arm);

        // Convertir a lista
        List<Aeronave> lista = new ArrayList<>(setAero);

        // Ordenar por designación
        lista.sort(Comparator.comparing(Aeronave::getDesignacion));
        return lista;
    }

    public Aeronave getAeronave(String designacion){

        //arriba tienes HashMap<String, Aeronave> designacionAeronave
        return designacionAeronave.get(designacion);
    }

    public void removeAeronave(String designacion){
        // 1. Obtener la aeronave
        Aeronave a = designacionAeronave.get(designacion);

        if (a == null) {
            System.out.println("Aeronave no encontrada");
            return;
        }

        // 2. Eliminar relaciones (Aeronave → Armamento)
        Set<Armamento> armamentos = aeronaveArmamentos.get(a);

        if (armamentos != null) {
            for (Armamento arm : armamentos) {

                // Quitar la aeronave del mapa inverso
                Set<Aeronave> aeronaves = armamentoAeronaves.get(arm);
                if (aeronaves != null) {
                    aeronaves.remove(a);

                    // Si queda vacío, opcionalmente eliminar la clave
                    if (aeronaves.isEmpty()) {
                        armamentoAeronaves.remove(arm);
                    }
                }
            }
        }
    }

    public Armamento getArmamentoPorNombre(String nombre){
        //arriba tienes HashMap<String, Armamento> nombreArmamento;
        return nombreArmamento.get(nombre);
    }


    public void guardarDatos() {

        try (ObjectOutputStream oos = new ObjectOutputStream(
                new FileOutputStream("inventario_militar.dat"))) {

            oos.writeObject(designacionAeronave);
            oos.writeObject(nombreArmamento);
            oos.writeObject(aeronaveArmamentos);
            oos.writeObject(armamentoAeronaves);

            System.out.println("Datos guardados correctamente.");

        } catch (IOException e) {
            System.out.println("Error al guardar datos: " + e.getMessage());
        }
    }

    public void cargarDatos() {

        try (ObjectInputStream ois = new ObjectInputStream(
                new FileInputStream("inventario_militar.dat"))) {

            designacionAeronave = (HashMap<String, Aeronave>) ois.readObject();
            nombreArmamento = (HashMap<String, Armamento>) ois.readObject();
            aeronaveArmamentos = (HashMap<Aeronave, Set<Armamento>>) ois.readObject();
            armamentoAeronaves = (HashMap<Armamento, Set<Aeronave>>) ois.readObject();

            System.out.println("Datos cargados correctamente.");

        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar datos: " + e.getMessage());
        }
    }

}
