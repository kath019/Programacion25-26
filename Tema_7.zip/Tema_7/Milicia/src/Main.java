public class Main{
    public static void main(String [] args) {
        GestorMilitar gestor = new GestorMilitar();

        // =========================
        // 🟦 1. Crear aeronaves
        // =========================
        Aeronave a1 = new Aeronave("F-22 Raptor", "Lockheed Martin", TipoAeronave.CAZA, 2960);
        Aeronave a2 = new Aeronave("B-2 Spirit", "Northrop Grumman", TipoAeronave.BOMBARDERO, 11000);
        Aeronave a3 = new Aeronave("C-130 Hercules", "Lockheed Martin", TipoAeronave.TRANSPORTE, 3800);
        Aeronave a4 = new Aeronave("MQ-9 Reaper", "General Atomics", TipoAeronave.DRON, 1850);
        Aeronave a5 = new Aeronave("AH-64 Apache", "Boeing", TipoAeronave.HELICOPTERO, 480);

        // Guardar aeronaves en el gestor
        gestor.designacionAeronave.put(a1.getDesignacion(), a1);
        gestor.designacionAeronave.put(a2.getDesignacion(), a2);
        gestor.designacionAeronave.put(a3.getDesignacion(), a3);
        gestor.designacionAeronave.put(a4.getDesignacion(), a4);
        gestor.designacionAeronave.put(a5.getDesignacion(), a5);

        // =========================
        // 🟦 2. Crear armamento
        // =========================
        Armamento ar1 = new Armamento("AIM-120 AMRAAM", "Misil aire-aire", 10, 160);
        Armamento ar2 = new Armamento("JDAM", "Bomba guiada", 5, 28);
        Armamento ar3 = new Armamento("Hellfire", "Misil aire-tierra", 8, 11);
        Armamento ar4 = new Armamento("M61 Vulcan", "Cañón rotatorio", 1200, 2);
        Armamento ar5 = new Armamento("GBU-31", "Bomba penetrante", 4, 24);

        // Guardar armamento en el gestor
        gestor.nombreArmamento.put(ar1.getNombre(), ar1);
        gestor.nombreArmamento.put(ar2.getNombre(), ar2);
        gestor.nombreArmamento.put(ar3.getNombre(), ar3);
        gestor.nombreArmamento.put(ar4.getNombre(), ar4);
        gestor.nombreArmamento.put(ar5.getNombre(), ar5);

        // =========================
        // 🟦 3. Relaciones
        // =========================
        gestor.addEquipamiento(a1, ar1);
        gestor.addEquipamiento(a1, ar4);

        gestor.addEquipamiento(a2, ar2);
        gestor.addEquipamiento(a2, ar5);

        gestor.addEquipamiento(a3, ar2);

        gestor.addEquipamiento(a4, ar3);

        gestor.addEquipamiento(a5, ar3);
        gestor.addEquipamiento(a5, ar4);

        // =========================
        // 🟦 4. PRUEBAS DE CONSULTA
        // =========================

        System.out.println("=== ARMAMENTO DEL F-22 ===");
        System.out.println(gestor.getArmamento(a1));

        System.out.println("\n=== AERONAVES CON HELLFIRE ===");
        System.out.println(gestor.getAeronaves(ar3));

        System.out.println("\n=== BUSCAR AERONAVE ===");
        System.out.println(gestor.getAeronave("F-22 Raptor"));

        System.out.println("\n=== BUSCAR ARMAMENTO ===");
        System.out.println(gestor.getArmamentoPorNombre("JDAM"));

        // =========================
        // 🟦 5. PRUEBA BORRADO
        // =========================
        System.out.println("\n=== ELIMINAR AERONAVE MQ-9 ===");
        gestor.removeAeronave("MQ-9 Reaper");

        System.out.println("Aeronaves con Hellfire después de borrar:");
        System.out.println(gestor.getAeronaves(ar3));

        // =========================
        // 🟦 6. GUARDAR Y CARGAR
        // =========================
        gestor.guardarDatos();

        GestorMilitar gestor2 = new GestorMilitar();
        gestor2.cargarDatos();

        System.out.println("\n=== PRUEBA CARGA ===");
        System.out.println(gestor2.getArmamento(a1));
    }
}