//mostrar el array al reves de como se introdujo con bucle for
import java.util.Arrays;
import java.util.Scanner;

public class Arrays_2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("¿Cuántos números desea introducir? ");
        int n = sc.nextInt();
        int [] array = new int[n];

        for (int i = 0; i < array.length; i++) {
            array[i] = sc.nextInt();
        }
        System.out.println("Los numeros itroducidos al reves son:");
        for (int i = array.length - 1; i >= 0; i--){
            System.out.print(array[i] + " ");
        }
    }
}
