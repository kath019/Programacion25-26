//juego de la camara secreta
//uso del final int MAX =__ para sacar un rango entre 1...MAX

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Arrays_5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random rand = new Random();

        System.out.println("Introduce la longitud de la clave: ");
        int longitud = sc.nextInt();
        int [] combSecreta = new int[longitud];//tabla combinación secreta
        int [] combJugador = new int[longitud];//tabla introducida jugador

        geeneraCombin(combSecreta);
        System.out.println(Arrays.toString(combSecreta));
        System.out.println("Escriba una combinación:");
        leeTabla(combJugador);

        while (!Arrays.equals(combSecreta, combJugador)){
            muestraPistas(combSecreta, combJugador);//mostrar pistas
            System.out.println("Escriba una combinación:");
            leeTabla(combJugador);//se vuelve a  pedir otra combinación
        }

    }
    static void geeneraCombin (int [] t){
        //declaracion de esta variable para usarla con Math.random
        //MAX determina el valor máximo que se asigna a un elemento
        //comprendido entre 1...MAX
        final int MAX = 5;

        //bucle para rellenar el array con números del 1 al 5
        for ( int i = 0; i < t.length; i++) {
            t[i] = (int) (Math.random()*MAX + 1);
        }
    }

    //recorre la tabla pasada como parámetro y asigna a cada elemento el valor leido
    static void leeTabla(int [] t){
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i<t.length; i++){
            t[i] = sc.nextInt();
        }
    }

    //recorre las dos tablas e infica para cada elemento de la combinacion introducida
    //si es mayor, menor o igual que el equivalente en la combinacion secreta
    static void muestraPistas (int [] secret, int [] jug){
        for (int i = 0; i <jug.length; i++){
            System.out.println(jug[i]);
            if (secret[i] > jug[i]){
                System.out.println("mayor");
            } else if (secret[i] < jug[i]){
                System.out.println("menor");
            } else{
                System.out.println("igual");
            }
        }
    }
}
