//Elimiar elementos de una tabla con una función
import java.util.Arrays;
import java.util.Scanner;

public class Arrays_4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //los números favoritos
        int t [] = {3, 4, 2, 1, 6, 19, 22};
        int numElem = t.length;

        //mostrar la tabla completa
        System.out.print(Arrays.toString(t));

        System.out.println("Índice de elementos a borrar:");
        int borrar = sc.nextInt();

        //mientras el índice sea positivo y existan elementos válidos en la tabla
        while ( borrar >= 0 && numElem != 0) {
            if (borrar < numElem) {
                //sustituir el valor por el ultimo elemento valido
                t[borrar] = t.length - 1;
                //ahora hay un dato menos en la tabla
                numElem--;
                mostrarTabla(t, numElem);
            } else {
                System.out.println("No existe elemento a borrar");
            }
            System.out.println("Índice de elementos a borrar:");
            borrar = sc.nextInt();
        }
    }
    static void mostrarTabla(int[] a, int n) {
        System.out.print("[");
        for (int i = 0; i < n; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println("]");
    }
}
