//media de positivos, negativos y cantidad de ceros
// introducidos por teclado
import java.util.Scanner;

public class Arrays_3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce la cantidad de datos a guardar:");
        int cantidad = sc.nextInt();

        System.out.println("Introduce los datos:");
        int [] numeros = new int [cantidad];

        int ceros = 0;
        int negativos = 0;
        int contneg= 0;
        int positivos = 0;
        int contpos = 0;

        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = sc.nextInt();
            if (numeros[i] == 0) {
                ceros++;
            } else if ( numeros[i] < 0) {
                contneg++;
                negativos += numeros[i] ;

            } else if (numeros[i] > 0) {
                contpos++;
                positivos += numeros[i];
            }
        }

        positivos /= contpos;
        System.out.println("La media de los positivos es: " + positivos);

        negativos /= contneg;
        System.out.println("La media de los negativos es: " + negativos);

        System.out.println("La cantidad de ceros es: " + ceros);
    }
}
