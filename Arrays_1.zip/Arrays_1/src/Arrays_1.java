//mostrar elementos de Array con Arrays.toString
import java.util.Arrays;
import java.util.Scanner;

public class Arrays_1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingrese 5 números decimales:");
        double[] t = new double[5];

        for (int i = 0; i < 5; i++){
            t [i]= sc.nextDouble();
        }
        System.out.print("Los números introducidos son: " + Arrays.toString(t));
    }
}
