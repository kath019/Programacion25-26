public class Ej2 {
}
