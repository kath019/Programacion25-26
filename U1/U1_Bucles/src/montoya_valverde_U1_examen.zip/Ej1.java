public class Ej1 {
}
