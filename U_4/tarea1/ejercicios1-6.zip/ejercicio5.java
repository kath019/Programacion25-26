public class ejercicio5 {
    public static class CuentaCorriente {
        private Double saldo;
        private Double limite_descubrimiento;
        private String nombre;
        private String dni;
        static String nombreBanco = "Banco de Java";

        /*creación de métodos*/
        public CuentaCorriente(String nombre, String dni){
            saldo=0.0;
            limite_descubrimiento = -50.0;
            this.nombre = nombre;
            this.dni =dni;
        }

        public CuentaCorriente(double saldo) {
            this.saldo = saldo;
            this.nombre = "Sin asignar";
            this.dni = "Sin asignar";
            this.limite_descubrimiento = 0.0;
        }

        public CuentaCorriente (double saldo, double limite_descubrimiento, String dni) {
            this.saldo = saldo;
            this.limite_descubrimiento = limite_descubrimiento;
            this.dni = dni;
            this.nombre = "Sin asignar";
        }

        static void modificarNombreBanco(String nuevoNombre) {
            nombreBanco = nuevoNombre;
        }

        public void mostrar_informacion () {
            System.out.println("Nombre: "+nombre);
            System.out.println("DNI: "+ dni);
            System.out.println("Saldo: "+ saldo);
            System.out.println("Banco: " + nombreBanco);
        }


    }
}
