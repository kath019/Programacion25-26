//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        /* EJERCICIO 1
        ejercicio1.CuentaCorriente cc = new ejercicio1.CuentaCorriente("Lopera", "123456F");

        ejercicio1.CuentaCorriente cc2 = new ejercicio1.CuentaCorriente("Del Nido", "654321F");

        cc.mostrar_informacion();
        cc2.mostrar_informacion();


        cc.ingresar_dinero(100.0);
        cc.mostrar_informacion(); */

        /* EJERCICIO 2
        ejercicio2.CuentaCorriente objeto1 = new ejercicio2.CuentaCorriente(500);
        ejercicio2.CuentaCorriente objeto2 = new ejercicio2.CuentaCorriente(600, 60, "30303030R");

        objeto1.mostrar_informacion();
        System.out.println();
        objeto2.mostrar_informacion();*/


        /* EJERCICIO 5
        ejercicio5.CuentaCorriente objeto1 = new ejercicio5.CuentaCorriente("Carla", "12345678R");

        objeto1.mostrar_informacion();
        System.out.println();
        objeto1.nombreBanco = "Banco de la nación";
        objeto1.mostrar_informacion();*/

        ejercicio6.Texto objeto1 = new ejercicio6.Texto(5);
        objeto1.añadirCadPrincipio("HO");
        objeto1.añadir(';');
        objeto1.añadirCadena("LA");
        objeto1.añadir('x');
        objeto1.mostrar();
        System.out.println("Número de vocales: " + objeto1.contarVocales());

    }
}