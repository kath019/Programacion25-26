public class ejercicio6 {
    public static class Texto {
        private String cadena;
        private final int taMax;
        private final String VOCALES = "aeiouáéíóú";

        public Texto (int taMax){
            cadena = "";
            this.taMax = taMax;
        }

        public void añadir (char c) {
            if(taMax < cadena.length()) {
                cadena = cadena + c;
            }
        }

        public void añadirPrincipio (char cI ) {
            if (taMax < cadena.length()) {
                cadena = cI + cadena;
            }
        }

        public void añadirCadena (String nuevaCadena) {
            if( taMax < cadena.length() + nuevaCadena.length()) {
                cadena = cadena + nuevaCadena;
            }
        }

        public void añadirCadPrincipio (String cadenalPrincipio) {
            if ( taMax < cadenalPrincipio.length() + cadena.length()) {
                cadena = cadenalPrincipio + cadena;
            }
        }

        //función que comprueba si el caracter pasado es una vocal o no, irá dentro del metodo de abajo
        private boolean esVocal (char c) {
            boolean vocal = false;
            c = Character.toLowerCase(c);
            if (VOCALES.indexOf(c) != -1) {
                vocal = true;
            }
            return vocal;
        }

        public int contarVocales () {
            int voc = 0;
            for (int i = 0; i < cadena.length(); i++) {
                if (esVocal(cadena.charAt(i))) {
                    voc++;
                }
            }
            return voc;
        }

        public void mostrar () {
            System.out.println(cadena);
        }
    }
}
