public class Main{
    public static void main (String [] args) {
        Coche grande = new Coche(4,"Toyota");
        System.out.println(grande.getMarca());
        grande.setMarca("Citroint");
        System.out.println(grande.getMarca());

    }
}
