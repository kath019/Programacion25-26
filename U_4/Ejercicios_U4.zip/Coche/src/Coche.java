public class Coche {
    private int puertas;
    private String marca;

    public Coche(int puert, String mar) {
        this.puertas = puert;
        this.marca = mar;
    }

    //funciones
    public int getPuertas() {//devuelve datos
        return puertas;
    }
    public String getMarca() {
        return marca;
    }

    public void setPuertas(int puert) {
        this.puertas = puert;
    }

    public void setMarca(String mar) {
        this.marca = mar;
    }

    //clase
    public static void main (String[] args) {
        //objeto
        Coche cocheFamiliar = new Coche(5, "Renault");

    }
}
