//En una tienda se necesita registrar productos. De cada producto se conoce su nombre y su precio. Si el precio es mayor a 500,
// se debe aplicar un descuento del 10%. Si no, el descuento será del 5%. El sistema debe mostrar el nombre del producto y el precio final
// a pagar.

public class Main{
    public static void main(String[] args) {
        Producto p1 = new Producto(540.67, "María");

        p1.aplicarDescuento();
        p1.mostrarInformacion();
    }
}