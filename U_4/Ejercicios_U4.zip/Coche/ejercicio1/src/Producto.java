public class Producto {
    private String nombre;
    private double precio;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Producto(double precio, String nombre) {
        this.precio = precio;
        this.nombre = nombre;
    }

    public void aplicarDescuento (){
        if (this.precio > 500){
            double descuento = this.precio * 0.1;
            this.precio -= descuento;
        } else {
            double descuento = this.precio * 0.05;
            this.precio -= descuento;
        }
    }

    public void mostrarInformacion (){
        System.out.println("Nombre: " + this.nombre);
        System.out.println("Precio: " + this.precio);
    }
}
