import java.util.Calendar;

public class Videojuego {
    private Calendar fecha;
    private Personaje personaje;
    private Escenario escenario;
    private static String ip = "192.168.1.1";


    public Videojuego() {
        this.fecha = Calendar.getInstance();
        this.personaje = new Personaje();
        TipoEnemigo[] tipos = {TipoEnemigo.BuzzBomber, TipoEnemigo.Coconuts};
        this.escenario = new Escenario(tipos);
    }

    public Videojuego(Personaje personaje, Escenario escenario) {
        this.personaje = personaje;
        this.escenario = escenario;
        this.fecha = Calendar.getInstance();
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @Override
    public String toString() {
        return "Videojuego{" +
                "fecha=" + fecha +
                ", personaje=" + personaje +
                ", escenario=" + escenario +
                '}';
    }
}
