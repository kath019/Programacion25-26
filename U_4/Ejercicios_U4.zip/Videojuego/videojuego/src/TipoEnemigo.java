public enum TipoEnemigo {
    BuzzBomber,
    CrabMeat,
    Coconuts,
    Chopper,
    MotoBug,
}
