import java.util.Arrays;

public class Enemigo {
    private TipoEnemigo tipoEnemigo;
    private int puntosVida;
    private int puntosDanio;

    public Enemigo(TipoEnemigo tipoEnemigo) {
        this.tipoEnemigo = tipoEnemigo;
        this.puntosVida = 100;
        this.puntosDanio = 70;
    }

    public void RestarVida(int danio){
        puntosVida -= danio;
        if(puntosVida <= 0){
            puntosVida = 0;
        }
    }

    @Override
    public String toString() {
        return "Enemigo{" +
                "tipoEnemigo=" + tipoEnemigo +
                ", puntosVida=" + puntosVida +
                ", puntosDanio=" + puntosDanio +
                '}';
    }
}
