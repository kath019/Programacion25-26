public class Personaje {
    private TiposPersonaje tipos;
    private double velocidad;
    private int punietazo;
    private int patada;

    public Personaje() {
        this.tipos = TiposPersonaje.Sonic;
        this.velocidad = 100.0;
        this.punietazo = 100;
        this.patada = 200;
    }

    public Personaje(TiposPersonaje tipos, double velocidad, int punietazo, int patada) {
        this.tipos = tipos;
        this.velocidad = velocidad;
        this.punietazo = punietazo;
        this.patada = patada;
    }

    @Override
    public String toString() {
        return "Personaje: " + tipos +
                " tiene velocidad de: " + velocidad +
                ", punietazo de: " + punietazo +
                " y patada: " + patada;
    }
}
