import java.util.Arrays;

public class Escenario {
    private int pixAlt;
    private int pixLong;
    private int anillo;
    private int gemas;
    private TipoEnemigo[] tipoEnemigo;
    private Enemigo[] listaEnemigos;
    private int contEnemigo;

    public Escenario(TipoEnemigo[] tipoEnemigo) {
        this.tipoEnemigo = tipoEnemigo;
        this.listaEnemigos = new Enemigo[10];
        this.pixAlt = 100;
        this.pixLong = 100;
        this.anillo = 500;
        this.gemas = 2;
        this.contEnemigo = 0;
    }

    public void AniadirEnemigo(TipoEnemigo tipo) {
        Enemigo enemigo = new Enemigo(tipo);
        listaEnemigos[contEnemigo] = enemigo;
        contEnemigo++;
    }

    public void EliminarEnemigo(int indice){
        if (indice >= 0 && indice < contEnemigo) {
            for (int i = indice; i < contEnemigo - 1; i++) {
                listaEnemigos[i] = listaEnemigos[i + 1];
            }
            listaEnemigos[contEnemigo - 1] = null;
            contEnemigo--;
        }        this.listaEnemigos = new Enemigo[10];
    }

    public int getNumeroEnemigos() {
        return contEnemigo;
    }

    @Override
    public String toString() {
        return "Escenario{" +
                "pixAlt=" + pixAlt +
                ", pixLong=" + pixLong +
                ", anillo=" + anillo +
                ", gemas=" + gemas +
                ", tipoEnemigo=" + Arrays.toString(tipoEnemigo) +
                ", listaEnemigos=" + Arrays.toString(listaEnemigos) +
                '}';
    }
}
