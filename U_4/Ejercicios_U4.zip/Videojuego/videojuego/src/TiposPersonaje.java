public enum TiposPersonaje {
    Sonic,
    Tails,
    Knuckles,
}
