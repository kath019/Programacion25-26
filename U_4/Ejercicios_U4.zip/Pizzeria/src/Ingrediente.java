public class Ingrediente {
    private String nombre;
    private double caloriasPor100gr;

    public Ingrediente() {
        this.nombre = "Queso";
        this.caloriasPor100gr = 250;
    }

    public Ingrediente(String nombre, double caloriasPor100gr) {
        this.nombre = nombre;
        this.caloriasPor100gr = caloriasPor100gr;
    }

    public String getNombre() {
        return nombre;
    }
    public void getCaloriaspor100(double caloriasPor100gr) {
        this.caloriasPor100gr = caloriasPor100gr;
    }

    @Override
    public String toString() {
        return nombre + '(' + caloriasPor100gr + "cal/100g";
    }
}
