import java.util.Arrays;

public class Pizzeria {
    private Pedido[] listaPedido;
    private int contPedidos;

    public Pizzeria() {
        this.listaPedido = new Pedido[5];
        this.contPedidos = 0;
    }

    public Pizzeria(int n) {
        this.listaPedido = new Pedido[n];
        this.contPedidos = 0;
    }

    public void aniadirPedido(Pedido pedido) {
        if (contPedidos == listaPedido.length){
            modificar();
        }

        listaPedido[contPedidos] = pedido;
        contPedidos++;
    }

    public void modificar(){
            Pedido[] pedido = new Pedido[listaPedido.length * 2];

            for(int i = 0; i < listaPedido.length; i++){
                pedido[i] = listaPedido[i];
            }
            listaPedido = pedido;
    }

    @Override
    public String toString() {
        return "Pizzeria: " +
                "lista de Pedidos: " + Arrays.toString(listaPedido) +
                ", con " + contPedidos + " pedidos";
    }
}
