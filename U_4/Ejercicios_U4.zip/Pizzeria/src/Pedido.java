import java.util.Calendar;

public class Pedido {
    private Pizza pizza;
    private Calendar fecha;

    public Pedido(Pizza pizza) {
        this.pizza = pizza;
        this.fecha = Calendar.getInstance();
    }

    // Método para crear pedido estrella
    public static Pedido crearPedidoEstrella() {
        Pizza pizza = new Pizza("Familiar");
        pizza.addIngrediente(new Ingrediente("Jamón ibérico", 300));
        pizza.addIngrediente(new Ingrediente()); // Queso por defecto
        return new Pedido(pizza);
    }

    public Pizza getPizza() {
        return pizza;
    }

    @Override
    public String toString() {
        return "Pedido realizado el: " + fecha.getTime() + "\n" + pizza;
    }
}
