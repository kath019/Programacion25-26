public enum Size {
    Mediana,
    Familiar
}
