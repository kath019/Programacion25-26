import java.util.Arrays;

public class Pizza {
    private  Size size;
    private Ingrediente[] ingredientes;
    private int contIngredientes;

    public Pizza(String familiar) {
        this.size = Size.Familiar;
        this.contIngredientes = 0;
        this.ingredientes = new  Ingrediente[3];
    }

    public Pizza(Size size) {
        this.size = size;
        this.contIngredientes = 0;
        this.ingredientes = new  Ingrediente[3];
    }

    public void mostrarTamanios(){
        System.out.println("Tamaños de pizza disponibles:");
        for(Size s: Size.values()){
            System.out.println("- " + s);
        }
    }

    public  int getContIngredientes(){
        return this.contIngredientes;
    }

    public boolean addIngrediente(Ingrediente ingrediente){
        if(contIngredientes < 3){
            ingredientes[contIngredientes] = ingrediente;
            contIngredientes++;
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Pizza de tamaño " +
                 size +
                ", ingredientes =" + Arrays.toString(ingredientes) +
                ", con " + contIngredientes +
                " ingredientes";
    }
}
