public enum Nota {
    Do,
    Re,
    Mi,
    Fa,
    Sol,
}
