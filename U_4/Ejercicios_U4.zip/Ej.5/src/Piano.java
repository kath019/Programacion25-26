//Actividad 6: Crear la clase Piano y la clase Campana que heredan de Instrumento.

import java.util.List;

public class Piano extends Instrumento{

    public Piano() {

    }

    @Override
    public void interpretar() {
        for(int i = 0; i < super.contador; i++){
            System.out.println (super.notas[i]);
        }
    }
}
