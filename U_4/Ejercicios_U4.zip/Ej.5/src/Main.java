//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Nota[] melodia = { Nota.Do, Nota.Mi, Nota.Sol, Nota.Do, Nota.Re };
    Piano piano = new Piano();
    piano.add (Nota.Do);
    piano.add (Nota.Re);
    piano.add (Nota.Mi);
    piano.interpretar();

    Campana campana = new Campana();
    campana.add (Nota.Do);
    campana.add (Nota.Re);
    campana.add (Nota.Mi);
    campana.add (Nota.Sol);
    campana.interpretar();
}
