import java.util.List;

public class Campana extends Instrumento{

    public Campana() {
    }

    @Override
    public void interpretar() {
        for(int i = 0; i < super.contador; i++){
            System.out.println (super.notas[i]);
        }
    }
}
