//Actividad 5: Crear la clase Instrumento, que es una clase abstracta que almacena un máximo de 100 notas musicales.
// Mientras haya sitio es posible añadir nuevas notas musicales, al final, con el método add().
//  La clase también dispone del método abstracto interpretar() que en cada subclase que herede de Instrumento,
//   mostrará por consola las notas musicales según las interprete. Utilizar enumerados para definir las notas musicales.

import java.util.List;

public abstract class Instrumento {
    protected Nota[] notas;
    protected int contador = 0;

    public Instrumento() {
        this.notas = new Nota[100];
    }

    public void add(Nota nota) {
        if (contador >= 100) {
            System.out.println("Melodía llena");

        } else {
            notas[contador] = nota;
            contador++;
        }

    }
    public abstract  void interpretar();
}
