import java.util.Arrays;

public class Vivienda {
    private String direccion;
    private double metrosCuadrados;
    private Estancias[] listaEstancias;
    private int contEstacias;

    public Vivienda(String direccion, double metrosCuadrados, int nuevaEstancia) {
        this.direccion = direccion;
        this.metrosCuadrados = metrosCuadrados;
        this.listaEstancias = new Estancias[nuevaEstancia];
        this.contEstacias = 0;
    }

    public void aniadirEstancia(Estancias nuevaEstancia){
        if (this.contEstacias == this.listaEstancias.length ){
            System.out.println("Capacidad llena");
        } else {
            listaEstancias[contEstacias] = nuevaEstancia;
            contEstacias++;
        }
    }

    public void EliminarEstancia(int indice){
        if (indice >= 0 && indice < contEstacias){
            for (int i = indice; i < contEstacias - 1; i++){
                this.listaEstancias[i] = listaEstancias[i + 1];
            }
            listaEstancias[contEstacias - 1] = null;
            this.contEstacias--;
        } else {
            System.out.println("Indice invalido");
        }
    }

    public static void mostrarEstancias() {
        for (Estancias e : Estancias.values()) {
            System.out.println(e);
        }
    }

    @Override
    public String toString() {
        return "Vivienda{" +
                "direccion='" + direccion + '\'' +
                ", metrosCuadrados=" + metrosCuadrados +
                ", listaEstancias=" + Arrays.toString(listaEstancias) +
                '}';
    }
    public void mostrar_informacion(){
        System.out.println(this.toString());
    }
}
