public class ManoDeObra {
    private String nombreEmpresa;
    private String descripcion;
    private int horas;
    private int cantObreros;

    public ManoDeObra(String nombreEmpresa, String descripcion, int horas, int cantObreros) {
        this.nombreEmpresa = nombreEmpresa;
        this.descripcion = descripcion;
        this.horas = horas;
        this.cantObreros = cantObreros;
    }

    @Override
    public String toString() {
        return "ManoDeObra{" +
                "nombreEmpresa='" + nombreEmpresa + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", horas=" + horas +
                ", cantObreros=" + cantObreros +
                '}';
    }


    public void mostrar_informacion(){
        System.out.println(this.toString());
    }
}
