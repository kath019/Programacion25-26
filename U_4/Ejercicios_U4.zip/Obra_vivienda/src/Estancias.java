public enum Estancias {
    COCINA,
    DORMITORIO,
    BANIO,
    SALON,
    TERRAZA,
    VESTIBULO,
    COMEDOR,
    BALCON
}
