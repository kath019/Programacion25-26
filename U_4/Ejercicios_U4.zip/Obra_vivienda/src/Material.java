public class Material {
    private String descripcion;
    private String proveedor;
    private int unidades;
    private double precioXunidad;
    private static double iva = 21;

    public Material(String descripcion, String proveedor, int unidades, double precioXunidad, double iva) {
        if (precioXunidad >= 0 && precioXunidad <= 100000 ) {
            this.precioXunidad = precioXunidad;
        } else {
            System.out.println("Precio fuera del límite establecido");
        }

        if (unidades >= 1 && unidades <= 1000) {
            this.unidades = unidades;
        } else {
            System.out.println("Unidades fuera del límite establecido");
        }
        this.proveedor = proveedor;
        this.descripcion = descripcion;
        Material.iva = iva;
    }

    public static void setIva(double nuevoIva) {
        iva = nuevoIva;
    }

    public static double getIva() {
        return iva;
    }

    public Material(String descripcion, int unidades, double precioXunidad) {
        this.descripcion = descripcion;
        if (precioXunidad >= 0 && precioXunidad <= 100000 ) {
            this.precioXunidad = precioXunidad;
        } else {
            System.out.println("Precio fuera del límite establecido");
        }

        if (unidades >= 1 && unidades <= 1000) {
            this.unidades = unidades;
        } else {
            System.out.println("Unidades fuera del límite establecido");
        }
        this.proveedor = null;
    }

    @Override
    public String toString() {
        return "Material{" +
                "descripcion='" + descripcion + '\'' +
                ", proveedor='" + proveedor + '\'' +
                ", unidades=" + unidades +
                ", precioXunidad=" + precioXunidad +
                ", iva=" + iva +
                '}';
    }

    public void mostrar_informacion(){
        System.out.println(this);
    }
}
