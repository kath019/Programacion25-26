//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    Calendar fecha = Calendar.getInstance();
    Vivienda vivienda1 = new Vivienda("Calle Mayor 10", 120, 6);
    vivienda1.aniadirEstancia(Estancias.SALON);
    vivienda1.aniadirEstancia(Estancias.COCINA);
    vivienda1.aniadirEstancia(Estancias.BANIO);
    vivienda1.aniadirEstancia(Estancias.BANIO);
    vivienda1.aniadirEstancia(Estancias.DORMITORIO);

    Vivienda vivienda2 = new Vivienda("AV. de la Palmera", 130, 5);
    vivienda2.aniadirEstancia(Estancias.SALON);
    vivienda2.aniadirEstancia(Estancias.COCINA);
    vivienda2.aniadirEstancia(Estancias.BANIO);
    vivienda2.aniadirEstancia(Estancias.DORMITORIO);

    Vivienda vivienda3 = new Vivienda("Plaza España 2", 150, 4);
    vivienda2.aniadirEstancia(Estancias.SALON);
    vivienda2.aniadirEstancia(Estancias.COCINA);
    vivienda2.aniadirEstancia(Estancias.DORMITORIO);
    vivienda2.aniadirEstancia(Estancias.TERRAZA);


    ManoDeObra manoDeObra1 = new ManoDeObra("Construcciones felices", "Reforma baño", 30, 2);
    ManoDeObra manoDeObra2 = new ManoDeObra("Reformas García", "Cambio suelo", 20, 5);
    ManoDeObra manoDeObra3 = new ManoDeObra("Obras Madrid", "Pintura General", 25, 2);


    Obra obra1 = new Obra(vivienda1, manoDeObra1,
            Estancias.BANIO, fecha, 5);

    Obra obra2 = new Obra(vivienda2, manoDeObra2,
            Estancias.SALON, fecha, 5);

    Obra obra3 = new Obra(vivienda3, manoDeObra3,
            Estancias.COCINA, fecha, 5);

    Material m1 = new Material("Azulejos", "Proveedor A", 50, 20);
    Material m2 = new Material("Cemento", "Proveedor B", 30, 10);
    Material m3 = new Material("Pintura Blanca", "Proveedor C", 15, 25);

    Material m4 = new Material("Tarima", 40, 35); // sin proveedor




    obra1.aniadirMaterial();
    obra1.aniadirMaterial();
    obra1.aniadirMaterial();

    obra1.eliminarMaterial();


    obra2.aniadirMaterial();
    obra2.aniadirMaterial();
    obra2.aniadirMaterial();

    obra2.eliminarMaterial();
    obra2.eliminarMaterial();


    obra3.aniadirMaterial();
    obra3.aniadirMaterial();
    obra3.aniadirMaterial();

    obra3.eliminarMaterial();

}
