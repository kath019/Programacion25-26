import java.util.Arrays;
import java.util.Calendar;

public class Obra {
    private Vivienda vivienda;
    private Material [] listMateriales;
    private ManoDeObra manoDeObra;
    private  Estancias estancia;
    private Calendar fecha;
    private int contMateriales;

    public Obra(Vivienda vivienda, ManoDeObra manoDeObra, Estancias estancia, Calendar fecha, int capacMateriales) {
        this.vivienda = vivienda;
        this.listMateriales = new Material[capacMateriales];
        this.manoDeObra = manoDeObra;
        this.estancia = estancia;
        this.fecha = fecha;
        this.contMateriales = 0;
    }

    public void aniadirMaterial(Material material){
        if (contMateriales < listMateriales.length) {
            listMateriales[contMateriales] = material;
            contMateriales++;
        } else {
            System.out.println("No se pueden añadir más materiales");
        }
    }

    public void eliminarMaterial(int indice){
        if (indice >= 0 && indice < contMateriales){
            for(int i= indice; i <contMateriales - 1; i++){
                this.listMateriales[i] = this.listMateriales[i + 1];
            }
            listMateriales[contMateriales - 1] = null;
            contMateriales--;
        } else {
            System.out.println("El material no existe");
        }
    }

    @Override
    public String toString() {
        return "Obra{" +
                "vivienda=" + vivienda +
                ", listMateriales=" + Arrays.toString(listMateriales) +
                ", manoDeObra=" + manoDeObra +
                ", estancia=" + estancia +
                ", fecha=" + fecha +
                ", contMateriales=" + contMateriales +
                '}';
    }

    public void mostrar_informacion(){
        System.out.println(this.toString());
    }
}
