public enum Formato {
    TEXTO,
    ILUSTRADO,
    INTERACTIVO
}
