public class Ej4 {
}
